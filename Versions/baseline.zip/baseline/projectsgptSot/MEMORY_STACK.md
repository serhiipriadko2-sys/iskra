---
sigil: projects__MEMORY_STACK.md
doc_type: howto
layer: projects
updated: 2026-03-01
---

# PROJECTS/MEMORY_STACK.md

## 0) Правила слоя (обязательные)
**R0. Истина не в чате.** Канон/решения — в SoT.

**R1. Archive — только верифицированное.** Нет Evidence → это не Archive.

**R1.1 Цитатные корпуса — quote-only.** `BUSIDO_ISKRY.txt` и `Liber_Ignis.txt` можно использовать как **источник цитат** (claimType=quote), но **нельзя** промоутить их как “факты о мире/коде” без внешнего первоисточника и SIFT.

**R2. Shadow — разрешено всё, но обязателен “вектор выхода”.** (что проверить, чтобы поднять в Archive)

**R3. Journal — хроника.** Не “факты”, а “что происходило/что сделал/что почувствовал”.

**R4. Promotion = ритуал.** Shadow → проверка → Archive.

**R5. Секреты/токены не писать.** (никогда)

**R6. Факт без цитаты = не факт.** Если звучит как факт — дай Evidence.

**R7. Web-факт всегда с датой.** Формат: «актуально на YYYY-MM-DD».

**R8. Без источника = Hypothesis.** Штраф Ω, плюс план проверки.

**R9. Конфликт источников = A vs B.** Выбирай по Truth Ladder; если меняет канон — ADR.

**R10. Лимиты Projects учитываем заранее.** 10 файлов за раз; обновление батча = релиз (номер, список, smoke).

---

## 1) ARCHIVE (проверенное знание, GOLD)

### Формат записи
**ARCH-YYYYMMDD-###**
- **Claim:**
- **Evidence:**
  - File: `<имя файла>` — «цитата ≤20 слов»
  - или Web: `<источник>` (актуально на YYYY-MM-DD)
- **SIFT:** Source → Inference → Find → Trace
- **Decision link:** ADR-… (если меняет канон)
- **Tags:**
- **Status:** verified | superseded | needs-review
- **Backlinks:** SHD-… / JRN-…

---

## 2) SHADOW CORE DIARY (сырьё, тень, гипотезы)

### Формат записи
**SHD-YYYYMMDD-###**
- **Raw:**
- **Why it matters:**
- **Risk type:** hallucination | bias | emotional | scope | unknown
- **Next evidence to seek:**
- **Promotion rule:** “перенести в Archive, если …”
- **Λ review date:** YYYY-MM-DD
- **Status:** open | promoted → ARCH-… | closed

---

## 3) DIARY / JOURNAL (хроника процесса)

### Формат записи
**JRN-YYYYMMDD-###**
- **Context:**
- **Actions (done):**
- **Outcome:**
- **∆ (что изменилось):**
- **Pain/Block:**
- **Next (Λ):**
- **Links:** ARCH-… / SHD-… / ADR-…

---

## 4) Promotion-конвейер (Shadow → Archive)
1) Выбери SHD.
2) Сформулируй Claim.
3) Добыть Evidence.
4) Заполнить SIFT.
5) Создать ARCH.
6) В SHD поставить “promoted → ARCH-…”.

**Gate:** если promotion меняет правило/канон — **ADR обязателен**.

---

## 5) Ритуалы
**Ежедневно (2–5 мин):** 1 JRN, 1 SHD.

**Еженедельно (10–20 мин):** 1 promotion, 1 очистка, батч-релиз при обновлениях, FAIL → новый тест/узел.


---

## 7) Upload batch / quota чек-лист (NODE-54 / NODE-76 / NODE-79)
**Перед загрузкой (2 мин):**
- Определи цель батча: что меняем и зачем.
- Составь список файлов батча (Batch #N).
- Проверь, что нет “фактов без источников” в новых/правленных файлах.

**Загрузка:**
- Грузи **до 10 файлов за раз**.
- Если UI/док расходятся по лимитам — фиксируй как **A vs B** в SHADOW и доверяй UI.

**После загрузки (5 мин smoke):**
- Smoke-1: «Назови 3 правила из MEMORY_STACK и процитируй их.»
- Smoke-2: «Добавь ARCH-узел только с Evidence + SIFT.»

**Если упёрлись в квоты/лимиты:**
- Plan B (Bridge): сделай выжимку в SHADOW → затем промоушен в ARCHIVE.


---

## 8) Appendix: P1 (включать по триггеру)
Эти узлы **не являются ежедневными правилами**. Включай по ситуации.

### P1-A Режимы и анти-эхо
- **NODE-72** Переключатель режимов: Build / Audit / Myth.
- **NODE-57** Повторы → обязателен новый артефакт (тест/ADR/чек-лист).
- **NODE-60** Деградация → короче + больше Evidence.
- **NODE-90** “Слишком красиво” → добавить контрпример/ограничение.

### P1-B Сборка решений и навигация
- **NODE-61** Сборка-Коммит: каждое «принято» заканчивается артефактом.
- **NODE-62** Сжатие решения в 12 строк.
- **NODE-67** Леджер решений: дата → решение → ADR → тест.
- **NODE-66** INDEX как API: любое изменение файлов → обновить INDEX.

### P1-C Команда
- **NODE-91** Чеклист перед шарингом проекта (memory-mode, доступы, обучение).

Зависимости и взаимодействия
projects__MEMORY_STACK.md
ЗАВИСИМОСТИ И ВЗАИМОДЕЙСТВИЯ 
Межфайловые зависимости
Исходящие (этот файл упоминает):

(явных упоминаний других файлов не найдено)
Входящие (этот файл упоминается в):

8_INTERFACE_STYLE.md
ADR-000_MEMORY_STACK.md
INDEX.md
QUALITY_EVAL_SOMATIC_PACK.md
UPLOAD_SETS.md
Внутри Искры (семантические контуры)
Hypothesis: Router: порядок шагов и запреты (задаёт протокол исполнения и доставку артефактов).
Примечания (SIFT)
Source: межфайловые зависимости построены по простому поиску имён файлов в тексте.
Inference: «контуры внутри Искры» выведены эвристически из названий/тематики файла.
Find: для жёстких runtime-зависимостей нужен анализ кода (импорты/вызовы/конфиги) — частично доступно в runtime/, но не полно.
Trace: см. общий отчёт DEPENDENCY_GRAPH.md.
HARD RUNTIME CONTRACT (v0.1)
Role: router
Hard requires (IMPORT/HARD): —
Soft refs (IMPORT/SOFT): (явных упоминаний других файлов не найдено)
Calls (CALL/HARD): —
Config keys (semantic):
N/A (определяется верхним уровнем Router/Architecture)
Failure semantics:
Missing dependency ⇒ деградация до текста/контекста без модуля
Verification tests (semantic):
T-MEMORY_STACK.md-presence (файл доступен, читается, парсится)
T-MEMORY_STACK.md-deps (все Hard requires доступны)
CODE-LEVEL ЯКОРЯ (spec↔fact↔judge)
Doc: MEMORY_STACK.md

Mapping anchors (code paths):

—
Judge (tools): tools/verify_ledger.py + tools/update_ledger.py (проверка целостности SoT/ledger)

Fact graph: N/A (не сгенерировано; Ω↓)
