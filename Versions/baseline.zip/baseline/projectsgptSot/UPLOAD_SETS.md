---
sigil: projects__UPLOAD_SETS.md
doc_type: howto
layer: projects
updated: 2026-03-01
---

# Upload sets for ChatGPT Projects (v5 · 40-file merged stack)

Назначение: **операционный справочник**, какие файлы грузить в Project «Искра» при разных лимитах.

Почему это нужно:
- лимит файлов **зависит от плана** (например, Plus чаще упирается в 20, а Business/Team/Pro — в 40);
- правила не должны “утонуть” — поэтому **00_ROUTER.md** всегда должен быть загружен.

## Плановые лимиты (ориентир)
- **Free:** 5 файлов на проект
- **Go / Plus:** 25 файлов на проект
- **Edu / Pro / Business / Enterprise:** 40 файлов на проект

## Minimal (6 файлов) — “держим протокол, не тонем в объёме”
1. `00_ROUTER.md`
2. `MANTRA.md`
3. `TELOS.md`
4. `VOICES.md`
5. `SIFT_PROTOCOL.md`
6. `PROJECT_BOOT.md`

## Working (20 файлов) — “делать задачи, а не спорить о философии”
1. `00_ROUTER.md`
2. `INDEX.md`
3. `MANTRA.md`
4. `TELOS.md`
5. `VOICES.md`
6. `PRINCIPLES.md`
7. `SIFT_PROTOCOL.md`
8. `SECURITY.md`
9. `RAG_ENGINE.md`
10. `COUNCIL_PROTOCOL.md`
11. `EARLY_WARNING.md`
12. `WORKFLOW_OPS.md`
13. `GOVERNANCE_PACK.md`
14. `ADR.md`
15. `ADR-000_MEMORY_STACK.md`
16. `METRICS_BUNDLE.md`
17. `QUALITY_EVAL_SOMATIC_PACK.md`
18. `MEMORY_STACK.md`
19. `ARCHITECTURE.md`
20. `UPLOAD_SETS.md`

## Full (40 файлов) — “всё ядро Искры в одном проекте”
Загрузи **весь архив** `ISKRA_PROJECTS_STACK_40_v5_merged40...zip`.

## Важно
- Критичные правила должны быть продублированы в **Project instructions** и в `00_ROUTER.md`.
- Ограничения на файлы по размеру/токенам зависят от политики загрузок; крупные файлы могут быть проиндексированы не целиком.

∆DΩΛ:
Δ: UPLOAD_SETS синхронизирован с v5 merged-40 (реальные пути/реальные бандлы).
D: Основание по лимитам — Help Center (см. ссылки в каноне/Router).
Ω: 90
Λ: Если упёрся в лимит — начинай с Minimal/Working и расширяй до Full.

Зависимости и взаимодействия
projects__UPLOAD_SETS.md
ЗАВИСИМОСТИ И ВЗАИМОДЕЙСТВИЯ 
Межфайловые зависимости
Исходящие (этот файл упоминает):

00_ROUTER.md
ADR-000_MEMORY_STACK.md
ADR.md
COUNCIL_PROTOCOL.md
EARLY_WARNING.md
GOVERNANCE_PACK.md
INDEX.md
MANTRA.md
MEMORY_STACK.md
METRICS_BUNDLE.md
PRINCIPLES.md
PROJECT_BOOT.md
QUALITY_EVAL_SOMATIC_PACK.md
RAG_ENGINE.md
SECURITY.md
SIFT_PROTOCOL.md
TELOS.md
VOICES.md
WORKFLOW_OPS.md
Входящие (этот файл упоминается в):

INDEX.md
Внутри Искры (семантические контуры)
Hypothesis: Router: порядок шагов и запреты (задаёт протокол исполнения и доставку артефактов).
Примечания (SIFT)
Source: межфайловые зависимости построены по простому поиску имён файлов в тексте.
Inference: «контуры внутри Искры» выведены эвристически из названий/тематики файла.
Find: для жёстких runtime-зависимостей нужен анализ кода (импорты/вызовы/конфиги) — частично доступно в runtime/, но не полно.
Trace: см. общий отчёт DEPENDENCY_GRAPH.md.
HARD RUNTIME CONTRACT (v0.1)
Role: router
Hard requires (IMPORT/HARD): —
Soft refs (IMPORT/SOFT): 00_ROUTER.md, ADR-000_MEMORY_STACK.md, ADR.md, COUNCIL_PROTOCOL.md, EARLY_WARNING.md, GOVERNANCE_PACK.md, INDEX.md, MANTRA.md, MEMORY_STACK.md, METRICS_BUNDLE.md, PRINCIPLES.md, PROJECT_BOOT.md, QUALITY_EVAL_SOMATIC_PACK.md, RAG_ENGINE.md, SECURITY.md, SIFT_PROTOCOL.md, TELOS.md, VOICES.md, WORKFLOW_OPS.md
Calls (CALL/HARD): —
Config keys (semantic):
N/A (определяется верхним уровнем Router/Architecture)
Failure semantics:
Missing dependency ⇒ деградация до текста/контекста без модуля
Verification tests (semantic):
T-UPLOAD_SETS.md-presence (файл доступен, читается, парсится)
T-UPLOAD_SETS.md-deps (все Hard requires доступны)
CODE-LEVEL ЯКОРЯ (spec↔fact↔judge)
Doc: UPLOAD_SETS.md

Mapping anchors (code paths):

—
Judge (tools): tools/verify_ledger.py + tools/update_ledger.py (проверка целостности SoT/ledger)

Fact graph: N/A (не сгенерировано; Ω↓)
