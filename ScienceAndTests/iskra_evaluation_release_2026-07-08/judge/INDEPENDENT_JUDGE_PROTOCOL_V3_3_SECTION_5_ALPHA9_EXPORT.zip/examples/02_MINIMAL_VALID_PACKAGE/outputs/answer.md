A benchmark measures performance on a defined task set and harness. General capability claims require broader populations, repeated evidence, and a declared estimand that permits that scope.
