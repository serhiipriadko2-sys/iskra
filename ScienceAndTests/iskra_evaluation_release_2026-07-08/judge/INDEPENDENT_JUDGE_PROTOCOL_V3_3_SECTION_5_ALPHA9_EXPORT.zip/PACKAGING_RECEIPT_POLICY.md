---
title: "Independent Judge Protocol — Packaging Receipt Policy"
version: "v1"
status: "ACCEPTED_OPERATIONAL_RULE"
effective_from: "v3.3-alpha.6"
created: "2026-07-17"
---

# Packaging Receipt Policy

## Purpose

Define non-recursive receipt semantics for versioned ZIP checkpoints.

## Rule

The final receipt containing the SHA-256 and byte size of a completed ZIP is an **external sidecar**.

```yaml
zip_receipt:
  storage: EXTERNAL_SIDECAR
  included_inside_its_zip: false
  hashes: FINAL_ZIP_BYTES
  reason: avoid recursive self-hashing
```

## Internal package records

A ZIP may contain:

- a versioned project manifest describing payload files;
- a section receipt describing generated artifacts and QC;
- earlier ZIP receipts from prior immutable checkpoints.

The current versioned manifest and current section receipt are intentionally excluded from their own payload file list. They are still included physically in the ZIP and counted in total archive files.

## Prohibited claim

An internal receipt may not claim the hash of the final ZIP that contains it.

## Verification

For each release:

1. build payload;
2. generate versioned manifest from payload;
3. generate section receipt;
4. create ZIP;
5. compute final ZIP bytes and SHA-256;
6. write `ZIP_RECEIPT_SECTION_<N>.json` beside the ZIP;
7. verify ZIP integrity and file count.

## ∆DΩΛ

**∆:** ZIP receipt location is explicit and non-recursive.

**D:** payload → internal manifest/section receipt → final ZIP → external sidecar.

**Ω:** 0.95.

**Λ:** Revisit only if the packaging format changes from ZIP or adopts a signed external transparency log.
