---
title: "Evaluation Ontology Addendum 02 — Failure Families and Lifecycle Axes"
project: "Independent Judge Protocol"
version: "v3.3-alpha.4-proposed"
status: "PROPOSED / OWNER REVIEW"
updates: "01_EVALUATION_ONTOLOGY.md"
---

# Evaluation Ontology Addendum 02

## Purpose

Section 3 requires two additive ontology refinements. This addendum does not rewrite Section 1; it proposes explicit extensions for Owner review.

## A. Extended failure families

The Section 1 failure family enum is extended with two independent families:

```typescript
type FailureFamilyV2 =
  | 'PACKAGE_INTEGRITY'
  | 'SOURCE_IDENTITY'
  | 'CONTRACT'
  | 'COMPARABILITY'
  | 'TRUTH_AND_LOGIC'
  | 'SAFETY'
  | 'AUTHORITY'
  | 'AGENCY_AND_CAPTURE'
  | 'EVIDENCE_INTEGRITY'
  | 'PRIVACY_AND_SECURITY'
  | 'JUDGE_INTEGRITY'
  | 'RELIABILITY'
  | 'METHODOLOGY'
  | 'GOVERNANCE'
  | 'PUBLICATION_CLAIM';
```

Rationale:

- `COMPARABILITY` is not merely a contract error: pointwise evaluation may remain valid while pairwise ranking becomes invalid.
- `METHODOLOGY` is not equivalent to reliability: a method can be unvalidated or inapplicable even when the judge is repeatable.

## B. Orthogonal lifecycle axes

Package validity, storage retention, and normative authority must not be collapsed into one enum.

### Package processing lifecycle

```text
ASSEMBLING -> SEALED -> RECEIVED -> VERIFIED
                       \-> REJECTED
VERIFIED -> SUPERSEDED
SEALED | RECEIVED | VERIFIED -> INVALIDATED on discovered integrity defect
```

### Retention lifecycle

```typescript
type RetentionStatus = 'ACTIVE_STORAGE' | 'ARCHIVED_STORAGE' | 'PURGED_BY_POLICY';
```

### Authority lifecycle

```typescript
type AuthorityStatus = 'CURRENT' | 'SUPERSEDED' | 'REVOKED';
```

### Run lifecycle

```typescript
type EvaluationRunStatus =
  | 'CREATED'
  | 'PACKAGE_RECEIVED'
  | 'INTEGRITY_CHECK'
  | 'ELIGIBILITY_CHECK'
  | 'SCORING'
  | 'JUDGE_QA'
  | 'ADJUDICATION'
  | 'VERDICT_COMMITTED'
  | 'SUPERSEDED'
  | 'INVALIDATED';
```

`EVALUATED` belongs to the run/verdict axis, not to package identity. `ARCHIVED` belongs to retention, not validity. `REVOKED` belongs to authority, not necessarily corruption.

## Governance status

This addendum becomes active only after Owner acceptance. Until then, Section 3 records these additions as proposed dependencies.
