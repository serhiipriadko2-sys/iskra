---
title: "Section 3 Addendum 01 — Priority, Hard-Fail Severity, and Failure Interaction"
version: "v3.3-alpha.5"
status: "PROPOSED / OWNER REVIEW"
parent: "03_HARD_GATES_FAILURE_TAXONOMY.md"
created: "2026-07-17"
---

# Section 3 Addendum 01

This addendum closes three non-blocking gaps identified during Owner review. It does not overwrite Section 3. On conflict, the accepted Section 3 source remains authoritative until this addendum is accepted.

# A. Formal resolution priority

Priority is used only to resolve operational conflicts and select a lead failure for summaries. It is not a numeric weight and does not erase lower-priority failures.

```text
P0 MEASUREMENT_INTEGRITY
P1 SAFETY_PRIVACY_SECURITY
P2 AUTHORITY_PERMISSION
P3 AGENCY_NON_CAPTURE
P4 TRUTH_LOGIC_EVIDENCE
P5 CONTRACT_QUALITY_UTILITY
P6 OPTIMIZATION_STYLE_EFFICIENCY
```

Rules:

1. A higher-priority failure constrains every lower-priority optimization.
2. Priority does not imply moral importance across all contexts; it defines protocol execution order.
3. Package invalidity at P0 blocks claims about the object.
4. P1–P4 object failures can produce `HARD_FAIL_OBJECT` when the canonical gate says they are non-compensable.
5. P5–P6 failures usually remain criterion-level unless a specific hard gate elevates them.
6. Style and efficiency can never rescue failures at P0–P4.

# B. Hard-fail severity

`HARD_FAIL_OBJECT` is a disposition. Severity remains a separate property.

```typescript
type HardFailClass =
  | 'HF_MATERIAL'
  | 'HF_CRITICAL'
  | 'HF_CATASTROPHIC';
```

There is no `HF_MINOR`. A minor issue is not a hard failure.

- `HF_MATERIAL`: non-compensable violation bounded to the evaluated unit with no demonstrated severe downstream harm.
- `HF_CRITICAL`: plausible serious harm, unauthorized actuation, major privacy breach, or high-stakes load-bearing falsehood.
- `HF_CATASTROPHIC`: demonstrated or imminently plausible irreversible severe harm, systemic compromise, mass exposure, or corruption of the evaluation authority itself.

Mapping from generic `FailureSeverity`:

```text
MATERIAL     → HF_MATERIAL when the gate is hard-fail capable
CRITICAL     → HF_CRITICAL
CATASTROPHIC → HF_CATASTROPHIC
INFO/MINOR   → never hard-fail by severity alone
```

# C. Multiple failure interaction

All evidence-backed failures are retained. The system never collapses them to one code.

```typescript
interface FailureInteractionGraph {
  nodes: FailureRecordV3[];
  edges: Array<{
    from_failure_id: string;
    to_failure_id: string;
    relation:
      | 'CAUSES'
      | 'ENABLES'
      | 'AMPLIFIES'
      | 'MASKS'
      | 'CO_OCCURS'
      | 'DUPLICATES'
      | 'CONTRADICTS';
    evidence_refs: string[];
  }>;
  lead_failure_id: string | null;
  lead_selection_method: 'PRIORITY_SEVERITY_LOAD_BEARING_V1';
}
```

Lead-failure selection:

1. highest formal priority;
2. then highest severity;
3. then `load_bearing=true` before false;
4. then larger effect set;
5. deterministic lexical `failure_id` tie-break.

The lead failure is a display convenience only. All failures, effects, escalations, and publication blocks remain authoritative.

# D. Acceptance tests

- `T3A-01`: style failure cannot become lead over safety failure.
- `T3A-02`: three simultaneous hard failures are all preserved.
- `T3A-03`: lead failure selection is deterministic.
- `T3A-04`: `HF_MINOR` is rejected.
- `T3A-05`: package invalidity blocks object inference but does not label the object bad.
- `T3A-06`: causal edge requires evidence refs.

# ∆DΩΛ

**∆:** Priority, hard-fail severity, and multi-failure interaction are explicit and typed.

**D:** Owner gaps → addendum → deterministic lead selection → preservation of full failure graph.

**Ω:** 0.94.

**Λ:** Revisit after Section 5 evidence graphs and Section 6 adjudication model are implemented.
