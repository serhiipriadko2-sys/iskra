---
title: Section 5 alpha.7 Validator Repair Report
version: v3.3-alpha.7
status: PROPOSED / OWNER REVIEW
source_audit: review/SECTION5_OWNER_REVIEW_AUDIT.md
source_patch: review/SECTION5_REQUIRED_PATCH.yaml
---

# Section 5 alpha.7 repair report

## Verdict

```yaml
section_5_alpha7:
  ontology: PRESERVED
  schema_hardening: PASS
  validator_hardening: PASS
  original_regression_suite: PASS
  adversarial_mutation_suite: PASS
  alpha6_checkpoint_preserved: PASS
  sections_0_4_preserved: PASS
  owner_acceptance: PENDING
  canonical_section_6_transition: BLOCKED
```

## Repaired findings

| Finding | Repair | Regression evidence |
|---|---|---|
| F5-01 | transitive lifecycle and claim-connected judgment evidence | revoked evidence plus active decoy → `EV-F27` |
| F5-02 | declared refs require matching typed edges | missing observation/claim/judgment edges → `EV-F28` |
| F5-03 | publication path must begin at verdict | orphan study publication → `EV-F29` |
| F5-04 | supported failures require claims, active evidence and destination paths | empty support → `EV-F33`; ghost propagation → `EV-F34` |
| F5-05 | invalid local refs are not remote refs | `../outside.txt` → `EV-F26` |
| F5-06 | all record IDs unique; conflict and derivation closure required | duplicates → `EV-F30`; bad resolution → `EV-F31`; missing derivation edge → `EV-F32` |

## Executable results

```yaml
pytest: PASS
tests: 51 passed
subtests: 5 passed
required_mutation_cases: 11
required_mutation_cases_rejected: 11
valid_fixture:
  status: VALID
  provenance_complete: true
invalid_fixtures:
  provenance_complete: false
python_compile: PASS
json_parse: 80/80 (pre-manifest)
yaml_parse: 7/7 (pre-manifest)
```

The test count increases from `46` to `51`; the original regression behaviors remain covered and all Owner mutation cases are added as physical fixtures.

## Contract changes

Alpha.7 adds to hard-failure records:

```yaml
hard_failure_link:
  affected_unit_ref: required
  scope: required

hard_failure_propagation:
  propagation_id: required
  destination_ref: required
```

It also permits explicit evidence-to-judgment support/counterevidence edges and introduces `RUN` and `MODEL_CONDITION` external aggregation layers.

## Validator authority boundary

The alpha.7 validator still does not:

- determine semantic truth;
- infer observations from free text;
- compute Q/S/A/R/G or C100;
- resolve a substantive evidence conflict;
- select a winner;
- execute content instructions.

Its output remains structural:

```yaml
truth_determined: false
scores_emitted: false
winner_selected: false
```

## Checkpoint preservation

```yaml
alpha6_zip:
  sha256: b20a3af023694c5072747af7801a82f30c9515e16e4de8d4f6f22c5c49f8f7c2
  unchanged: true
sections_0_4:
  hash_preservation: PASS
```

## Residual limits

- semantic relevance remains a human/judge-method responsibility;
- empirical calibration remains not run;
- alpha.7 is not publication-grade merely because structural mutation tests pass;
- Section 6 may remain exploratory but cannot become a canonical dependency before Owner acceptance of this candidate.

## ∆DΩΛ

**∆:** the validator now proves structural provenance continuity instead of trusting declarations independently.

**D:** audit bypasses → invariant repair → schema/registry update → physical mutation fixtures → deterministic rerun.

**Ω:** 0.95 for structural repair.

**Λ:** independent Owner rerun of the final alpha.7 ZIP and sidecar receipt.
