#!/usr/bin/env python3
"""Reference validator for IJP v3.3 Evaluation Packages.

This validator checks schema shape, safe paths, file digests, package hashes,
referential integrity, criterion lifecycle, frozen-contract state and basic
comparability declarations. It never produces quality scores or winners.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, sys, unicodedata
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import jsonschema

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / '02_EVALUATION_PACKAGE.schema.json'


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_bytes(package: dict) -> bytes:
    p = copy.deepcopy(package)
    p.get('integrity', {})['manifest_sha256'] = None
    p.get('integrity', {})['package_sha256'] = None
    text = json.dumps(p, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    text = unicodedata.normalize('NFC', text)
    return text.encode('utf-8')


def safe_path(value: str) -> bool:
    if '\\' in value or value.startswith('/'):
        return False
    parts = PurePosixPath(value).parts
    return bool(parts) and '..' not in parts and '.' not in parts


def compute_hashes(package: dict) -> tuple[str, str]:
    manifest_sha = sha256(canonical_bytes(package))
    entries = sorted(package.get('content_entries', []), key=lambda e: e['path'])
    lines = ''.join(f"{e['path']}\t{e['bytes']}\t{e['sha256']}\n" for e in entries)
    package_sha = sha256((f"IJP-PACKAGE-v1\n{manifest_sha}\n" + lines).encode('utf-8'))
    return manifest_sha, package_sha


def ids(items, key):
    return [x[key] for x in items]


def validate(package_file: Path) -> dict:
    package_root = package_file.parent
    package = json.loads(package_file.read_text(encoding='utf-8'))
    expected = package.pop('_expected_failure_code', None)
    schema = json.loads(SCHEMA_PATH.read_text(encoding='utf-8'))
    errors=[]; warnings=[]
    try:
        jsonschema.Draft202012Validator(schema, format_checker=jsonschema.FormatChecker()).validate(package)
        schema_status='PASS'
    except jsonschema.ValidationError as exc:
        schema_status='FAIL'
        errors.append({'code':'SCHEMA_VALIDATION','message':exc.message,'path':'/'.join(map(str,exc.absolute_path))})

    if 'primary_estimand' not in package:
        errors.append({'code':'PKG-F01','message':'missing primary estimand'})

    # Paths and content.
    seen=set()
    for entry in package.get('content_entries', []):
        path=entry.get('path','')
        if not safe_path(path):
            errors.append({'code':'PKG-F05','message':f'unsafe path: {path}'})
            continue
        if path in seen:
            errors.append({'code':'DUPLICATE_PATH','message':path})
        seen.add(path)
        p=package_root/path
        if not p.exists():
            errors.append({'code':'PKG-F05','message':f'missing content file: {path}'})
            continue
        data=p.read_bytes()
        if len(data)!=entry.get('bytes') or sha256(data)!=entry.get('sha256'):
            errors.append({'code':'PKG-F02','message':f'content digest mismatch: {path}'})

    # Unique IDs.
    collections=[
      ('object',package.get('evaluated_objects',[]),'object_id'),('harness',package.get('harnesses',[]),'harness_id'),
      ('unit',package.get('evaluation_units',[]),'unit_id'),('task',package.get('tasks',[]),'task_id'),
      ('contract',package.get('task_contracts',[]),'contract_id'),('output',package.get('candidate_outputs',[]),'output_id'),
      ('criterion',package.get('criterion_bindings',[]),'criterion_id'),('source',package.get('sources',[]),'source_id'),
      ('evidence',package.get('evidence_items',[]),'evidence_id'),('method',package.get('methods',[]),'method_id')]
    idsets={}
    for kind,items,key in collections:
        vals=ids(items,key)
        if len(vals)!=len(set(vals)):
            errors.append({'code':'DUPLICATE_ID','message':kind})
        idsets[kind]=set(vals)

    # Referential integrity.
    if package.get('study',{}).get('primary_estimand_id') != package.get('primary_estimand',{}).get('estimand_id'):
        errors.append({'code':'ESTIMAND_BINDING','message':'study primary estimand mismatch'})
    for out in package.get('candidate_outputs',[]):
        if out.get('object_id') not in idsets.get('object',set()):
            errors.append({'code':'PKG-F04','message':f"unknown output object: {out.get('object_id')}"})
        if out.get('unit_id') not in idsets.get('unit',set()):
            errors.append({'code':'ALIGNMENT','message':f"unknown output unit: {out.get('unit_id')}"})
    task_contract_count={tid:0 for tid in idsets.get('task',set())}
    for c in package.get('task_contracts',[]):
        tid=c.get('task_id')
        if tid not in task_contract_count:
            errors.append({'code':'CONTRACT_TASK_REF','message':f'unknown task: {tid}'})
        else:
            task_contract_count[tid]+=1
        if not c.get('frozen_before_candidate_read'):
            errors.append({'code':'PKG-F03','message':f"post-hoc contract: {c.get('contract_id')}"})
    for tid,count in task_contract_count.items():
        if count!=1:
            errors.append({'code':'CONTRACT_CARDINALITY','message':f'{tid} has {count} contracts'})
    for b in package.get('criterion_bindings',[]):
        if b.get('required_for_run') and b.get('lifecycle_status')!='ACTIVE':
            errors.append({'code':'PKG-F07','message':f"required criterion not ACTIVE: {b.get('criterion_id')}"})
    for u in package.get('evaluation_units',[]):
        for oid in u.get('object_ids',[]):
            if oid not in idsets.get('object',set()): errors.append({'code':'UNIT_OBJECT_REF','message':oid})
        tid=u.get('task_id')
        if tid is not None and tid not in idsets.get('task',set()): errors.append({'code':'UNIT_TASK_REF','message':tid})
        for oid in u.get('output_ids',[]):
            if oid not in idsets.get('output',set()): errors.append({'code':'UNIT_OUTPUT_REF','message':oid})

    # Sealed hash requirements.
    integ=package.get('integrity',{})
    manifest_sha, package_sha = compute_hashes(package)
    if package.get('lifecycle_status') in {'SEALED','RECEIVED','VERIFIED'}:
        if not package.get('sealed_at'):
            errors.append({'code':'SEAL_MISSING','message':'sealed package lacks sealed_at'})
        if integ.get('manifest_sha256')!=manifest_sha:
            errors.append({'code':'MANIFEST_HASH_MISMATCH','message':f"expected {manifest_sha}"})
        if integ.get('package_sha256')!=package_sha:
            errors.append({'code':'PACKAGE_HASH_MISMATCH','message':f"expected {package_sha}"})

    # Independence and composite warnings.
    ind=package.get('profiles',{}).get('independence',{})
    if ind.get('judge_has_object_write_access') or ind.get('judge_has_package_write_access_after_seal') or ind.get('judge_has_rubric_write_access_during_run'):
        errors.append({'code':'INDEPENDENCE_CONFLICT','message':'judge has prohibited write capability'})
    app=package.get('profiles',{}).get('applicability',{})
    if app.get('unresolved_required_domains'):
        warnings.append({'code':'COMPOSITE_BLOCKED','message':'required domain applicability unresolved'})

    semantic_status='PASS' if not errors else 'FAIL'
    return {
      'package_id':package.get('package_id'),'schema_status':schema_status,'semantic_status':semantic_status,
      'integrity_status':'PASS' if semantic_status=='PASS' else 'FAIL','errors':errors,'warnings':warnings,
      'computed_manifest_sha256':manifest_sha,'computed_package_sha256':package_sha,
      'expected_failure_code':expected,'validated_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('package',type=Path)
    ap.add_argument('--json',action='store_true')
    args=ap.parse_args()
    report=validate(args.package)
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['semantic_status']=='PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())
