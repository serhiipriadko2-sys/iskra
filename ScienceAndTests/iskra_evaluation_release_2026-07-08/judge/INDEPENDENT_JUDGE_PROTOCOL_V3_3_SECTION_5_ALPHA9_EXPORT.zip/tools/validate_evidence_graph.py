#!/usr/bin/env python3
"""Deterministic structural validator for IJP Section 5 evidence graphs.

The validator enforces schema, identity, lifecycle, typed provenance paths,
publication ancestry and hard-failure propagation. It never interprets free
text, determines truth, computes scores, or selects a winner.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import unquote, urlparse

import jsonschema
import yaml

ENGINE_VERSION = "IJP-EVIDENCE-VALIDATOR-v3.3-alpha.9"
COLLECTION_LAYERS = {
    "sources": "SOURCE",
    "contents": "CONTENT",
    "evidence": "EVIDENCE",
    "observations": "OBSERVATION",
    "claims": "CLAIM",
    "judgments": "JUDGMENT",
    "external_nodes": None,
}
ID_FIELDS = {
    "sources": "source_id",
    "contents": "content_id",
    "evidence": "evidence_id",
    "observations": "observation_id",
    "claims": "claim_id",
    "judgments": "judgment_id",
    "external_nodes": "node_id",
}
RECORD_ID_FIELDS = {
    **ID_FIELDS,
    "methods": "method_id",
    "edges": "edge_id",
    "conflicts": "conflict_id",
    "derivations": "derivation_id",
    "redactions": "redaction_id",
    "hard_failure_links": "failure_id",
    "hard_failure_propagation": "propagation_id",
}
INACTIVE_EVIDENCE = {
    "COLLECTED",
    "QUALIFIED",
    "CONFLICTED",
    "SUPERSEDED",
    "REVOKED",
    "EXPIRED",
    "CORRUPTED",
    "ARCHIVED",
}
SUPPORT_TO_CLAIM = {"SUPPORTS", "PARTIALLY_SUPPORTS", "REFUTES"}
SUPPORT_TO_JUDGMENT = {"SUPPORTS", "PARTIALLY_SUPPORTS", "APPLIES_TO", "LIMITS"}
COUNTER_RELATIONS = {"COUNTERS", "REFUTES"}
FLOW_RELATIONS = {
    "OBSERVES",
    "EXTRACTED_FROM",
    "SUPPORTS",
    "PARTIALLY_SUPPORTS",
    "APPLIES_TO",
    "SCORES",
    "TRIGGERS_GATE",
    "AGGREGATES",
    "LIMITS",
}
REMOTE_SCHEMES = {"http", "https", "s3", "gs", "ipfs", "ftp"}
BLOCKING_OBSERVATION_STATUSES = {"CONFLICTED", "UNSCORABLE", "NOT_OBSERVED"}
NONSCORABLE_CLAIM_QUALIFICATIONS = {"UNKNOWN", "CONFLICTED", "REFUTED"}
NONSCORABLE_CLAIM_SUPPORT = {
    "INSUFFICIENT_EVIDENCE",
    "CONFLICTED",
    "REFUTED",
    "NOT_EVALUATED",
}
TRANSITIVE_SUPPORT_RELATIONS = {
    "OBSERVES",
    "EXTRACTED_FROM",
    "SUPPORTS",
    "PARTIALLY_SUPPORTS",
    "APPLIES_TO",
    "LIMITS",
    "DERIVED_FROM",
}


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def level_num(level: str, registry: dict[str, Any]) -> int:
    return int(registry["claim_levels"][level])


def add_error(errors: list[str], code: str, detail: str) -> None:
    errors.append(f"{code} {detail}")


def add_warning(warnings: list[str], code: str, detail: str) -> None:
    warnings.append(f"{code} {detail}")


def classify_content_ref(root: Path, ref: str) -> tuple[str, Path | None]:
    """Classify a content reference without allowing local-capable URI bypasses.

    Returns REMOTE_REF only for an explicit allow-list, LOCAL_REF for a safe
    root-contained relative path, INVALID_LOCAL_URI for file/UNC/unsupported
    URI-like references, or INVALID_LOCAL_REF for unsafe path syntax.
    """
    value = ref.strip()
    if not value or "\x00" in value:
        return "INVALID_LOCAL_REF", None
    parsed = urlparse(value)
    scheme = parsed.scheme.lower()
    if scheme == "urn":
        return "REMOTE_REF", None
    if scheme in REMOTE_SCHEMES:
        return "REMOTE_REF", None
    # Any other explicit scheme is not a trusted remote transport. This
    # includes file:, data:, javascript:, smb:, nfs: and unknown schemes.
    if scheme or "://" in value:
        return "INVALID_LOCAL_URI", None
    # Decode local references before path checks so percent-encoded traversal
    # or local URI syntax cannot be deferred to a downstream decoder.
    decoded = value
    decode_stable = False
    for _ in range(16):
        next_decoded = unquote(decoded)
        if next_decoded == decoded:
            decode_stable = True
            break
        decoded = next_decoded
    if not decode_stable:
        return "INVALID_LOCAL_REF", None
    decoded_parsed = urlparse(decoded)
    if decoded_parsed.scheme or "://" in decoded:
        return "INVALID_LOCAL_URI", None
    normalized = decoded.replace("\\", "/")
    # Protocol-relative/UNC forms are local-capable and therefore forbidden.
    if normalized.startswith("//"):
        return "INVALID_LOCAL_URI", None
    if re.match(r"^[A-Za-z]:/", normalized):
        return "INVALID_LOCAL_REF", None
    p = Path(normalized)
    if p.is_absolute() or ".." in p.parts:
        return "INVALID_LOCAL_REF", None
    resolved_root = root.resolve()
    resolved = (resolved_root / p).resolve()
    try:
        resolved.relative_to(resolved_root)
    except ValueError:
        return "INVALID_LOCAL_REF", None
    return "LOCAL_REF", resolved


def validate_global_ids(graph: dict[str, Any], errors: list[str]) -> None:
    seen: dict[str, str] = {}
    for collection, field in RECORD_ID_FIELDS.items():
        for item in graph.get(collection, []):
            record_id = item.get(field)
            if not record_id:
                continue
            if record_id in seen:
                add_error(
                    errors,
                    "EV-F30",
                    f"DUPLICATE_RECORD_ID:{record_id}:{seen[record_id]}:{collection}",
                )
                if collection in ID_FIELDS or seen[record_id] in ID_FIELDS:
                    add_error(errors, "EV-F03", f"DUPLICATE_NODE_ID:{record_id}")
            else:
                seen[record_id] = collection


def build_nodes(
    graph: dict[str, Any], errors: list[str]
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    nodes: dict[str, dict[str, Any]] = {}
    layers: dict[str, str] = {}
    for collection, field in ID_FIELDS.items():
        for item in graph.get(collection, []):
            node_id = item[field]
            if node_id in nodes:
                # Global checker emits the canonical duplicate error.
                continue
            nodes[node_id] = item
            layers[node_id] = (
                item["layer"] if collection == "external_nodes" else COLLECTION_LAYERS[collection]
            )
    return nodes, layers


def validate_schema(graph: dict[str, Any], schema: dict[str, Any], errors: list[str]) -> None:
    validator = jsonschema.Draft202012Validator(
        schema, format_checker=jsonschema.FormatChecker()
    )
    for err in sorted(validator.iter_errors(graph), key=lambda e: list(e.path)):
        path = "/".join(str(x) for x in err.path)
        add_error(errors, "SCHEMA", f"{path}:{err.message}")


def validate_methods(
    graph: dict[str, Any], errors: list[str], warnings: list[str]
) -> dict[str, dict[str, Any]]:
    methods: dict[str, dict[str, Any]] = {}
    for method in graph.get("methods", []):
        mid = method["method_id"]
        if mid in methods:
            # Do not silently overwrite a method with the same ID.
            continue
        methods[mid] = method
    mode = graph["mode"]
    for mid, method in methods.items():
        state = method["validation_status"]
        if mode == "CONFIRMATORY" and state != "ACTIVE":
            add_error(errors, "EV-F13", f"METHOD_NOT_ACTIVE_CONFIRMATORY:{mid}:{state}")
        elif state == "CALIBRATING":
            add_warning(warnings, "EV-W04", f"METHOD_CALIBRATING:{mid}")
        elif state in {"SUSPENDED", "DEPRECATED", "RETIRED"}:
            add_error(errors, "EV-F13", f"METHOD_INACTIVE:{mid}:{state}")
    return methods


def require_method(
    ref: str,
    methods: dict[str, dict[str, Any]],
    errors: list[str],
    context: str,
    *,
    expected_type: str | None = None,
    require_active: bool = False,
) -> bool:
    method = methods.get(ref)
    if method is None:
        add_error(errors, "EV-F13", f"METHOD_MISSING:{context}:{ref}")
        return False
    valid = True
    if expected_type and method["method_type"] != expected_type:
        add_error(
            errors,
            "EV-F31",
            f"METHOD_TYPE_INVALID:{context}:{ref}:{method['method_type']}:{expected_type}",
        )
        valid = False
    if require_active and method["validation_status"] != "ACTIVE":
        add_error(
            errors,
            "EV-F31",
            f"METHOD_NOT_ACTIVE:{context}:{ref}:{method['validation_status']}",
        )
        valid = False
    return valid


def validate_content(
    graph: dict[str, Any],
    root: Path,
    sources: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    errors: list[str],
    warnings: list[str],
) -> None:
    for content in graph["contents"]:
        cid = content["content_id"]
        if content["source_ref"] not in sources:
            add_error(errors, "EV-F02", f"CONTENT_SOURCE_MISSING:{cid}:{content['source_ref']}")
        if content["fragment_locator"]["kind"] != "FULL" and not content["fragment_locator"]["value"].strip():
            add_error(errors, "EV-F25", f"CONTENT_FRAGMENT_UNBOUNDED:{cid}")
        if content["fragment_locator"]["value"].strip() in {"*", "ALL_UNBOUNDED"}:
            add_error(errors, "EV-F25", f"CONTENT_FRAGMENT_UNBOUNDED:{cid}")
        if content.get("parser_ref"):
            require_method(content["parser_ref"], methods, errors, f"content:{cid}")
        ref_kind, local = classify_content_ref(root, content["content_ref"])
        if ref_kind == "INVALID_LOCAL_URI":
            add_error(errors, "EV-F35", f"UNSAFE_LOCAL_URI:{cid}:{content['content_ref']}")
            continue
        if ref_kind == "INVALID_LOCAL_REF":
            add_error(errors, "EV-F26", f"UNSAFE_CONTENT_REF:{cid}:{content['content_ref']}")
            continue
        if ref_kind == "REMOTE_REF":
            if content["integrity_status"] == "VERIFIED":
                add_warning(
                    warnings,
                    "EV-W09",
                    f"REMOTE_INTEGRITY_NOT_REPRODUCED_LOCALLY:{cid}:{content['content_ref']}",
                )
            continue
        assert local is not None
        if content["integrity_status"] == "VERIFIED":
            if not local.exists():
                add_error(errors, "EV-F06", f"CONTENT_MISSING:{cid}:{content['content_ref']}")
            elif content["sha256"] is None:
                add_error(errors, "EV-F06", f"CONTENT_HASH_REQUIRED:{cid}")
            else:
                actual = sha256_file(local)
                if actual != content["sha256"]:
                    add_error(errors, "EV-F06", f"CONTENT_HASH_MISMATCH:{cid}:{actual}")
                if content["bytes"] is not None and local.stat().st_size != content["bytes"]:
                    add_error(errors, "EV-F06", f"CONTENT_BYTES_MISMATCH:{cid}:{local.stat().st_size}")
        elif content["integrity_status"] == "UNVERIFIED":
            add_warning(warnings, "EV-W02", f"UNVERIFIED_INTEGRITY:{cid}")


def validate_evidence(
    graph: dict[str, Any],
    contents: dict[str, dict[str, Any]],
    sources: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    errors: list[str],
    warnings: list[str],
) -> dict[str, set[str]]:
    evidence_sources: dict[str, set[str]] = defaultdict(set)
    for ev in graph["evidence"]:
        eid = ev["evidence_id"]
        require_method(ev["collection_method_ref"], methods, errors, f"evidence:{eid}")
        for cref in ev["content_refs"]:
            if cref not in contents:
                add_error(errors, "EV-F02", f"EVIDENCE_CONTENT_MISSING:{eid}:{cref}")
            else:
                evidence_sources[eid].add(contents[cref]["source_ref"])
        td = ev["trust_dimensions"]
        if td["identity"] == "PARTIAL":
            add_warning(warnings, "EV-W01", f"PARTIAL_IDENTITY:{eid}")
        if td["temporal_validity"] == "UNKNOWN":
            add_warning(warnings, "EV-W03", f"TEMPORAL_VALIDITY_UNKNOWN:{eid}")
        if td["independence"] == "UNKNOWN":
            add_warning(warnings, "EV-W05", f"INDEPENDENCE_UNKNOWN:{eid}")
        if td["independence"] == "INDEPENDENT":
            for sid in evidence_sources[eid]:
                if sid in sources and sources[sid]["independence_class"] != "EXTERNAL_INDEPENDENT":
                    add_error(errors, "EV-F22", f"INDEPENDENCE_OVERCLAIMED:{eid}:{sid}")
        if ev["lifecycle_status"] == "ACTIVE":
            failed_dimensions = []
            if td["identity"] == "FAILED": failed_dimensions.append("identity")
            if td["integrity"] == "FAILED": failed_dimensions.append("integrity")
            if td["relevance"] == "IRRELEVANT": failed_dimensions.append("relevance")
            if td["temporal_validity"] == "EXPIRED": failed_dimensions.append("temporal_validity")
            if td["methodological_validity"] == "FAILED": failed_dimensions.append("methodological_validity")
            if td["completeness"] == "INSUFFICIENT": failed_dimensions.append("completeness")
            if td["relevance"] == "INDIRECT" and not ev["limitations"]:
                failed_dimensions.append("unbounded_indirect_relevance")
            if graph["mode"] == "CONFIRMATORY":
                if td["identity"] != "VERIFIED": failed_dimensions.append("confirmatory_identity")
                if td["integrity"] != "VERIFIED": failed_dimensions.append("confirmatory_integrity")
                if td["relevance"] != "DIRECT": failed_dimensions.append("confirmatory_relevance")
                if td["temporal_validity"] not in {"CURRENT", "BOUNDED"}: failed_dimensions.append("confirmatory_temporal")
                if td["methodological_validity"] != "VALIDATED": failed_dimensions.append("confirmatory_method")
                if td["completeness"] != "COMPLETE_FOR_CLAIM": failed_dimensions.append("confirmatory_completeness")
            if failed_dimensions:
                add_error(errors, "EV-F40", f"INELIGIBLE_ACTIVE_EVIDENCE:{eid}:{','.join(sorted(set(failed_dimensions)))}")
            bad_content = []
            for cref in ev["content_refs"]:
                content = contents.get(cref)
                if not content:
                    continue
                status = content["integrity_status"]
                if status in {"HASH_MISMATCH", "UNAVAILABLE"}:
                    bad_content.append(f"{cref}:{status}")
                if td["integrity"] == "VERIFIED" and status not in {"VERIFIED", "REDACTED"}:
                    bad_content.append(f"{cref}:TRUST_CONTENT_MISMATCH:{status}")
            if bad_content:
                add_error(errors, "EV-F41", f"CONTENT_INTEGRITY_INCONSISTENT:{eid}:{','.join(sorted(set(bad_content)))}")
    return evidence_sources


def validate_observations(
    graph: dict[str, Any],
    evidence: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    errors: list[str],
) -> None:
    for obs in graph["observations"]:
        oid = obs["observation_id"]
        require_method(obs["extraction_method_ref"], methods, errors, f"observation:{oid}")
        if not obs["evidence_refs"]:
            add_error(errors, "EV-F02", f"OBSERVATION_WITHOUT_EVIDENCE:{oid}")
        for ref in obs["evidence_refs"]:
            if ref not in evidence:
                add_error(errors, "EV-F02", f"OBSERVATION_EVIDENCE_MISSING:{oid}:{ref}")


def validate_claims(
    graph: dict[str, Any],
    observations: dict[str, dict[str, Any]],
    evidence: dict[str, dict[str, Any]],
    evidence_sources: dict[str, set[str]],
    sources: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    registry: dict[str, Any],
    errors: list[str],
) -> None:
    graph_ceiling = graph["claim_ceiling"]
    for claim in graph["claims"]:
        cid = claim["claim_id"]
        require_method(claim["inference_method_ref"], methods, errors, f"claim:{cid}")
        for ref in claim["observation_refs"]:
            if ref not in observations:
                add_error(errors, "EV-F02", f"CLAIM_OBSERVATION_MISSING:{cid}:{ref}")
        for ref in claim["supporting_evidence_refs"] + claim["counterevidence_refs"]:
            if ref not in evidence:
                add_error(errors, "EV-F02", f"CLAIM_EVIDENCE_MISSING:{cid}:{ref}")
        if (
            level_num(claim["claim_level"], registry) > level_num(claim["claim_ceiling"], registry)
            or level_num(claim["claim_level"], registry) > level_num(graph_ceiling, registry)
        ):
            add_error(
                errors,
                "EV-F08",
                f"CLAIM_CEILING_EXCEEDED:{cid}:{claim['claim_level']}:{claim['claim_ceiling']}:{graph_ceiling}",
            )
        qrule = registry["claim_qualification"].get(claim["qualification"])
        if qrule and claim["support_status"] not in qrule["allowed_support_status"]:
            add_error(
                errors,
                "CLAIM_STATUS",
                f"QUALIFICATION_SUPPORT_MISMATCH:{cid}:{claim['qualification']}:{claim['support_status']}",
            )
        if claim["load_bearing"] and claim["support_status"] in {"INSUFFICIENT_EVIDENCE", "NOT_EVALUATED"}:
            add_error(errors, "EV-F09", f"LOAD_BEARING_CLAIM_UNSUPPORTED:{cid}")
        if claim["qualification"] == "FACT" and not (
            claim["observation_refs"] or claim["supporting_evidence_refs"]
        ):
            add_error(errors, "EV-F09", f"FACT_WITHOUT_SUPPORT:{cid}")
        if claim["scope"].startswith("local_runtime:"):
            candidate_evidence = set(claim["supporting_evidence_refs"])
            for oid in claim["observation_refs"]:
                obs = observations.get(oid)
                if obs:
                    candidate_evidence.update(obs["evidence_refs"])
            local = any(
                eid in evidence and claim["scope"] in evidence[eid]["object_scope"]
                for eid in candidate_evidence
            )
            if not local:
                add_error(errors, "EV-F14", f"EXTERNAL_TO_LOCAL_SCOPE_LEAP:{cid}")
        if claim["claim_type"] in {"NORMATIVE", "GOVERNANCE"} and claim["qualification"] == "FACT":
            support_source_ids: set[str] = set()
            for eid in claim["supporting_evidence_refs"]:
                support_source_ids |= evidence_sources.get(eid, set())
            if support_source_ids and all(
                sources[sid]["authority_class"] == "UNTRUSTED_CONTENT"
                for sid in support_source_ids
                if sid in sources
            ):
                add_error(errors, "EV-F19", f"EMBEDDED_INSTRUCTION_AUTHORITY_ELEVATION:{cid}")
        negative = any(
            evidence.get(eid, {}).get("evidence_type") == "NEGATIVE_SEARCH_RESULT"
            for eid in claim["supporting_evidence_refs"]
        )
        if negative and level_num(claim["claim_level"], registry) > 1:
            add_error(errors, "EV-F24", f"NEGATIVE_EVIDENCE_OVERGENERALIZED:{cid}:{claim['claim_level']}")


def claim_is_epistemically_scorable(claim: dict[str, Any]) -> bool:
    return (
        claim["qualification"] not in NONSCORABLE_CLAIM_QUALIFICATIONS
        and claim["support_status"] not in NONSCORABLE_CLAIM_SUPPORT
    )


def validate_judgments(
    graph: dict[str, Any],
    claims: dict[str, dict[str, Any]],
    observations: dict[str, dict[str, Any]],
    evidence: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    errors: list[str],
) -> None:
    for judgment in graph["judgments"]:
        jid = judgment["judgment_id"]
        require_method(judgment["method_ref"], methods, errors, f"judgment:{jid}")
        if not judgment["claim_refs"]:
            add_error(errors, "EV-F11", f"JUDGMENT_WITHOUT_CLAIM:{jid}")
        if not judgment["evidence_refs"]:
            add_error(errors, "EV-F12", f"JUDGMENT_WITHOUT_EVIDENCE:{jid}")
        referenced_claims: list[dict[str, Any]] = []
        for ref in judgment["claim_refs"]:
            if ref not in claims:
                add_error(errors, "EV-F02", f"JUDGMENT_CLAIM_MISSING:{jid}:{ref}")
            else:
                referenced_claims.append(claims[ref])
        for ref in judgment["evidence_refs"] + judgment["counterevidence_refs"]:
            if ref not in evidence:
                add_error(errors, "EV-F02", f"JUDGMENT_EVIDENCE_MISSING:{jid}:{ref}")
            elif evidence[ref]["lifecycle_status"] != "ACTIVE":
                add_error(
                    errors,
                    "EV-F07",
                    f"INACTIVE_EVIDENCE_USED:{jid}:{ref}:{evidence[ref]['lifecycle_status']}",
                )
        if judgment["score_eligible"]:
            if judgment["status"] in {"CONFLICTED", "UNSCORABLE", "NOT_APPLICABLE"}:
                add_error(errors, "EV-F10", f"CONFLICTED_OR_UNSCORABLE_SCORE_ELIGIBLE:{jid}")
            scorable_claims: list[dict[str, Any]] = []
            for claim in referenced_claims:
                cid = claim["claim_id"]
                if claim["qualification"] == "CONFLICTED" or claim["support_status"] == "CONFLICTED":
                    add_error(errors, "EV-F10", f"CONFLICTED_CLAIM_SCORE_ELIGIBLE:{jid}:{cid}")
                if claim_is_epistemically_scorable(claim):
                    scorable_claims.append(claim)
                observation_states = [
                    observations[ref]["status"]
                    for ref in claim["observation_refs"]
                    if ref in observations
                ]
                blocking = sorted(set(observation_states).intersection(BLOCKING_OBSERVATION_STATUSES))
                material_partial = (
                    "PARTIAL" in observation_states
                    and (claim["load_bearing"] or "OBSERVED" not in observation_states)
                )
                if blocking or material_partial:
                    states = blocking + (["PARTIAL_LOAD_BEARING"] if material_partial else [])
                    add_error(
                        errors,
                        "EV-F37",
                        f"OBSERVATION_STATUS_NOT_PROPAGATED:{jid}:{cid}:{','.join(states)}",
                    )
                if claim["load_bearing"] and not claim_is_epistemically_scorable(claim):
                    add_error(
                        errors,
                        "EV-F38",
                        f"NONSCORABLE_LOAD_BEARING_CLAIM_FEEDS_SCORE:{jid}:{cid}:{claim['qualification']}:{claim['support_status']}",
                    )
            if referenced_claims and not scorable_claims:
                add_error(
                    errors,
                    "EV-F38",
                    f"NONSCORABLE_CLAIM_FEEDS_SCORE:{jid}:{','.join(c['claim_id'] for c in referenced_claims)}",
                )
        claim_counter: set[str] = set()
        for claim in referenced_claims:
            claim_counter.update(claim["counterevidence_refs"])
        if not claim_counter.issubset(set(judgment["counterevidence_refs"])):
            missing = sorted(claim_counter - set(judgment["counterevidence_refs"]))
            add_error(errors, "EV-F21", f"COUNTEREVIDENCE_DROPPED:{jid}:{','.join(missing)}")


def edge_key_index(graph: dict[str, Any]) -> dict[tuple[str, str], set[str]]:
    index: dict[tuple[str, str], set[str]] = defaultdict(set)
    for edge in graph["edges"]:
        index[(edge["from_ref"], edge["to_ref"])].add(edge["relation_type"])
    return index


def has_typed_edge(
    index: dict[tuple[str, str], set[str]],
    from_ref: str,
    to_ref: str,
    relations: set[str],
) -> bool:
    return bool(index.get((from_ref, to_ref), set()).intersection(relations))


def validate_declared_reference_edges(
    graph: dict[str, Any],
    index: dict[tuple[str, str], set[str]],
    errors: list[str],
) -> bool:
    complete = True

    def require(ref_from: str, ref_to: str, rels: set[str], context: str) -> None:
        nonlocal complete
        if not has_typed_edge(index, ref_from, ref_to, rels):
            complete = False
            add_error(
                errors,
                "EV-F28",
                f"DECLARED_REF_WITHOUT_EDGE:{context}:{ref_from}->{ref_to}:{'|'.join(sorted(rels))}",
            )

    for obs in graph["observations"]:
        for eid in obs["evidence_refs"]:
            require(eid, obs["observation_id"], {"OBSERVES", "EXTRACTED_FROM"}, f"observation:{obs['observation_id']}")
    for claim in graph["claims"]:
        cid = claim["claim_id"]
        for oid in claim["observation_refs"]:
            require(oid, cid, SUPPORT_TO_CLAIM, f"claim_observation:{cid}")
        for eid in claim["supporting_evidence_refs"]:
            require(eid, cid, {"SUPPORTS", "PARTIALLY_SUPPORTS"}, f"claim_evidence:{cid}")
        for eid in claim["counterevidence_refs"]:
            require(eid, cid, COUNTER_RELATIONS, f"claim_counterevidence:{cid}")
    for judgment in graph["judgments"]:
        jid = judgment["judgment_id"]
        for cid in judgment["claim_refs"]:
            require(cid, jid, SUPPORT_TO_JUDGMENT, f"judgment_claim:{jid}")
        for eid in judgment["evidence_refs"]:
            require(eid, jid, {"SUPPORTS", "PARTIALLY_SUPPORTS"}, f"judgment_evidence:{jid}")
        for eid in judgment["counterevidence_refs"]:
            require(eid, jid, COUNTER_RELATIONS, f"judgment_counterevidence:{jid}")
    return complete


def validate_conflicts(
    graph: dict[str, Any],
    claims: dict[str, dict[str, Any]],
    evidence: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    errors: list[str],
) -> None:
    for conflict in graph["conflicts"]:
        cid = conflict["conflict_id"]
        claim = claims.get(conflict["claim_ref"])
        if claim is None:
            add_error(errors, "EV-F02", f"CONFLICT_CLAIM_MISSING:{cid}:{conflict['claim_ref']}")
            continue
        for ref in conflict["evidence_refs"]:
            if ref not in evidence:
                add_error(errors, "EV-F02", f"CONFLICT_EVIDENCE_MISSING:{cid}:{ref}")
        if conflict["resolution_method_ref"]:
            require_method(conflict["resolution_method_ref"], methods, errors, f"conflict:{cid}")
        if conflict["status"] == "RESOLVED":
            valid = True
            method_ref = conflict["resolution_method_ref"]
            resolution_claim_ref = conflict["resolution_claim_ref"]
            if not method_ref or not require_method(
                method_ref,
                methods,
                errors,
                f"conflict:{cid}",
                expected_type="CONFLICT_RESOLUTION",
                require_active=True,
            ):
                valid = False
            resolution_claim = claims.get(resolution_claim_ref) if resolution_claim_ref else None
            if resolution_claim is None:
                valid = False
            elif resolution_claim["qualification"] in {"CONFLICTED", "UNKNOWN", "REFUTED"}:
                valid = False
            if not conflict["evidence_refs"]:
                valid = False
            if not valid:
                add_error(errors, "EV-F31", f"INVALID_CONFLICT_RESOLUTION:{cid}")
        if conflict["status"] in {"OPEN", "DEFERRED"} and conflict["materiality"] in {"MATERIAL", "LOAD_BEARING"}:
            if claim["qualification"] != "CONFLICTED" or claim["support_status"] != "CONFLICTED":
                add_error(errors, "EV-F10", f"MATERIAL_CONFLICT_NOT_PROPAGATED:{cid}:{claim['claim_id']}")


def validate_edges(
    graph: dict[str, Any],
    nodes: dict[str, dict[str, Any]],
    layers: dict[str, str],
    evidence: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    registry: dict[str, Any],
    errors: list[str],
) -> tuple[dict[str, list[str]], dict[tuple[str, str], set[str]]]:
    allowed = registry["allowed_edges"]
    support_rel = set(registry["support_relations"])
    adjacency: dict[str, list[str]] = defaultdict(list)
    index = edge_key_index(graph)
    for edge in graph["edges"]:
        eid = edge["edge_id"]
        a = edge["from_ref"]
        b = edge["to_ref"]
        rel = edge["relation_type"]
        if a not in nodes or b not in nodes:
            add_error(errors, "EV-F02", f"EDGE_NODE_MISSING:{eid}:{a}->{b}")
            continue
        require_method(edge["method_ref"], methods, errors, f"edge:{eid}")
        for ref in edge["evidence_refs"]:
            if ref not in evidence:
                add_error(errors, "EV-F44", f"EDGE_EVIDENCE_MISSING:{eid}:{ref}")
        pair = [layers[a], layers[b]]
        if pair not in allowed.get(rel, []):
            if layers[a] == "SOURCE" and layers[b] == "CLAIM":
                add_error(errors, "EV-F01", f"DIRECT_SOURCE_TO_CLAIM:{eid}")
            else:
                add_error(errors, "EV-F04", f"INVALID_LAYER_TRANSITION:{eid}:{rel}:{pair[0]}->{pair[1]}")
        if rel in support_rel:
            adjacency[a].append(b)
    indeg = {n: 0 for n in nodes}
    for a, destinations in adjacency.items():
        for b in destinations:
            indeg[b] = indeg.get(b, 0) + 1
    queue = deque([n for n, degree in indeg.items() if degree == 0])
    seen = 0
    while queue:
        node = queue.popleft()
        seen += 1
        for destination in adjacency.get(node, []):
            indeg[destination] -= 1
            if indeg[destination] == 0:
                queue.append(destination)
    if seen < len(indeg):
        add_error(errors, "EV-F05", "SUPPORT_GRAPH_CYCLE")
    return adjacency, index


def reverse_adjacency_for_relations(
    graph: dict[str, Any], relations: set[str]
) -> dict[str, list[str]]:
    reverse: dict[str, list[str]] = defaultdict(list)
    for edge in graph["edges"]:
        if edge["relation_type"] in relations:
            reverse[edge["to_ref"]].append(edge["from_ref"])
    return reverse


def ancestors(reverse: dict[str, list[str]], target: str) -> set[str]:
    found: set[str] = set()
    queue = deque([target])
    while queue:
        node = queue.popleft()
        for parent in reverse.get(node, []):
            if parent not in found:
                found.add(parent)
                queue.append(parent)
    return found


def validate_transitive_judgment_support(
    graph: dict[str, Any],
    evidence: dict[str, dict[str, Any]],
    claims: dict[str, dict[str, Any]],
    errors: list[str],
) -> bool:
    complete = True
    reverse = reverse_adjacency_for_relations(graph, TRANSITIVE_SUPPORT_RELATIONS)
    derivation_reverse = reverse_adjacency_for_relations(graph, {"DERIVED_FROM"})
    for judgment in graph["judgments"]:
        if not judgment["score_eligible"]:
            continue
        jid = judgment["judgment_id"]
        judgment_ancestors = ancestors(reverse, jid)
        for claim_ref in judgment["claim_refs"]:
            if claim_ref not in claims or claim_ref not in judgment_ancestors:
                continue
            claim_ancestors = ancestors(reverse, claim_ref)
            evidence_ancestors = {ref for ref in claim_ancestors if ref in evidence}
            active_ancestors = {
                ref for ref in evidence_ancestors if evidence[ref]["lifecycle_status"] == "ACTIVE"
            }
            inactive_ancestors = evidence_ancestors - active_ancestors
            if inactive_ancestors:
                complete = False
                for ref in sorted(inactive_ancestors):
                    add_error(
                        errors,
                        "EV-F27",
                        f"INACTIVE_TRANSITIVE_SUPPORT:{jid}:{claim_ref}:{ref}:{evidence[ref]['lifecycle_status']}",
                    )
            inactive_derivation_inputs: set[str] = set()
            for candidate in evidence_ancestors:
                for input_ref in ancestors(derivation_reverse, candidate):
                    if input_ref in evidence and evidence[input_ref]["lifecycle_status"] != "ACTIVE":
                        inactive_derivation_inputs.add(input_ref)
            for ref in sorted(inactive_derivation_inputs):
                complete = False
                add_error(
                    errors,
                    "EV-F36",
                    f"INACTIVE_DERIVATION_ANCESTOR:{jid}:{claim_ref}:{ref}:{evidence[ref]['lifecycle_status']}",
                )
            declared = set(judgment["evidence_refs"])
            connected_declared = declared.intersection(active_ancestors)
            if not active_ancestors or not connected_declared:
                complete = False
                add_error(
                    errors,
                    "EV-F27",
                    f"JUDGMENT_EVIDENCE_NOT_CONNECTED_TO_CLAIM:{jid}:{claim_ref}",
                )
    return complete


def validate_derivations(
    graph: dict[str, Any],
    evidence: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    errors: list[str],
    warnings: list[str],
) -> None:
    derived_edges: dict[str, dict[str, str]] = defaultdict(dict)
    for edge in graph["edges"]:
        if edge["relation_type"] == "DERIVED_FROM":
            derived_edges[edge["to_ref"]][edge["from_ref"]] = edge["method_ref"]
    for derivation in graph["derivations"]:
        did = derivation["derivation_id"]
        require_method(
            derivation["method_ref"],
            methods,
            errors,
            f"derivation:{did}",
            expected_type="DERIVATION",
            require_active=True,
        )
        method = methods.get(derivation["method_ref"])
        if method and derivation["method_version"] != method["version"]:
            add_error(
                errors,
                "EV-F46",
                f"METHOD_VERSION_MISMATCH:derivation:{did}:{derivation['method_version']}:{method['version']}",
            )
        output = derivation["output_evidence_ref"]
        if output not in evidence:
            add_error(errors, "EV-F02", f"DERIVATION_OUTPUT_MISSING:{did}")
        elif evidence[output]["evidence_type"] != "DERIVED_TRANSFORM":
            add_error(errors, "EV-F32", f"DERIVATION_OUTPUT_NOT_DERIVED:{did}:{output}")
        if not derivation["input_evidence_refs"]:
            add_error(errors, "EV-F15", f"DERIVATION_WITHOUT_INPUTS:{did}")
        for ref in derivation["input_evidence_refs"]:
            if ref not in evidence:
                add_error(errors, "EV-F02", f"DERIVATION_INPUT_MISSING:{did}:{ref}")
        if output in evidence and evidence[output]["lifecycle_status"] == "ACTIVE":
            for ref in derivation["input_evidence_refs"]:
                if ref in evidence and evidence[ref]["lifecycle_status"] != "ACTIVE":
                    add_error(
                        errors,
                        "EV-F36",
                        f"INACTIVE_DERIVATION_ANCESTOR:{did}:{output}:{ref}:{evidence[ref]['lifecycle_status']}",
                    )
        declared = set(derivation["input_evidence_refs"])
        actual = set(derived_edges.get(output, {}))
        if declared != actual or any(
            derived_edges.get(output, {}).get(ref) != derivation["method_ref"]
            for ref in declared.intersection(actual)
        ):
            add_error(
                errors,
                "EV-F32",
                f"DERIVATION_EDGE_MISSING:{did}:declared={','.join(sorted(declared))}:actual={','.join(sorted(actual))}",
            )
        if derivation["reproducibility_status"] == "REPRODUCIBLE_NOT_RERUN":
            add_warning(warnings, "EV-W07", f"DERIVED_EVIDENCE_NOT_RERUN:{did}")
    declared_derivation_edges = {
        (input_ref, item["output_evidence_ref"], item["method_ref"])
        for item in graph["derivations"]
        for input_ref in item["input_evidence_refs"]
    }
    for edge in graph["edges"]:
        if (
            edge["relation_type"] == "DERIVED_FROM"
            and edge["from_ref"] in evidence
            and edge["to_ref"] in evidence
            and (edge["from_ref"], edge["to_ref"], edge["method_ref"])
            not in declared_derivation_edges
        ):
            add_error(
                errors,
                "EV-F42",
                f"ORPHAN_DERIVATION_EDGE:{edge['edge_id']}:{edge['from_ref']}->{edge['to_ref']}",
            )


def validate_redactions(
    graph: dict[str, Any],
    contents: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    judgments: dict[str, dict[str, Any]],
    errors: list[str],
    warnings: list[str],
) -> None:
    material_content: set[str] = set()
    for redaction in graph["redactions"]:
        rid = redaction["redaction_id"]
        require_method(
            redaction["method_ref"],
            methods,
            errors,
            f"redaction:{rid}",
            expected_type="REDACTION",
        )
        if redaction["original_content_ref"] not in contents or redaction["redacted_content_ref"] not in contents:
            add_error(errors, "EV-F02", f"REDACTION_CONTENT_MISSING:{rid}")
        if redaction["semantic_materiality"] == "MATERIAL":
            material_content.add(redaction["redacted_content_ref"])
        if redaction["semantic_materiality"] == "POSSIBLY_MATERIAL":
            add_warning(warnings, "EV-W08", f"REDACTION_POSSIBLY_MATERIAL:{rid}")
    declared_redacted = {item["redacted_content_ref"] for item in graph["redactions"]}
    for cid, content in contents.items():
        if content["integrity_status"] == "REDACTED" and cid not in declared_redacted:
            add_error(errors, "EV-F43", f"REDACTED_CONTENT_WITHOUT_RECORD:{cid}")
    if not material_content:
        return
    evidence_by_content: dict[str, set[str]] = defaultdict(set)
    for ev in graph["evidence"]:
        for content_ref in ev["content_refs"]:
            evidence_by_content[content_ref].add(ev["evidence_id"])
    affected: set[str] = set()
    for content_ref in material_content:
        affected |= evidence_by_content[content_ref]
    reverse = reverse_adjacency_for_relations(graph, TRANSITIVE_SUPPORT_RELATIONS)
    for judgment in judgments.values():
        if not judgment["score_eligible"]:
            continue
        jid = judgment["judgment_id"]
        transitive_ancestors = ancestors(reverse, jid)
        transitive_affected = affected.intersection(transitive_ancestors)
        if affected.intersection(judgment["evidence_refs"]):
            add_error(errors, "EV-F16", f"REDACTION_MATERIALITY_IGNORED:{jid}")
        if transitive_affected:
            add_error(
                errors,
                "EV-F39",
                f"TRANSITIVE_MATERIAL_REDACTION:{jid}:{','.join(sorted(transitive_affected))}",
            )


def path_exists(adjacency: dict[str, list[str]], starts: Iterable[str], target: str) -> bool:
    start_set = set(starts)
    queue = deque(start_set)
    seen = set(start_set)
    while queue:
        node = queue.popleft()
        if node == target:
            return True
        for destination in adjacency.get(node, []):
            if destination not in seen:
                seen.add(destination)
                queue.append(destination)
    return False


def flow_adjacency(graph: dict[str, Any]) -> dict[str, list[str]]:
    adjacency: dict[str, list[str]] = defaultdict(list)
    for edge in graph["edges"]:
        if edge["relation_type"] in FLOW_RELATIONS:
            adjacency[edge["from_ref"]].append(edge["to_ref"])
    return adjacency


def validate_hard_failures(
    graph: dict[str, Any],
    claims: dict[str, dict[str, Any]],
    evidence: dict[str, dict[str, Any]],
    external_nodes: dict[str, dict[str, Any]],
    registry: dict[str, Any],
    errors: list[str],
) -> list[str]:
    failures = {item["failure_id"]: item for item in graph["hard_failure_links"]}
    supported: list[str] = []
    canonical_gates = set(registry.get("canonical_gate_refs", []))
    canonical_effects = set(registry.get("canonical_effect_refs", []))
    edge_index = edge_key_index(graph)
    adjacency = flow_adjacency(graph)

    for failure in graph["hard_failure_links"]:
        fid = failure["failure_id"]
        invalid_support = False
        if failure["gate_ref"] not in canonical_gates or failure["effect_ref"] not in canonical_effects:
            invalid_support = True
        if failure["affected_unit_ref"] != graph["unit_id"] or not failure["scope"].strip():
            invalid_support = True
        if failure["status"] == "SUPPORTED" and (
            not failure["claim_refs"] or not failure["evidence_refs"]
        ):
            invalid_support = True
        for claim_ref in failure["claim_refs"]:
            claim = claims.get(claim_ref)
            if claim is None:
                add_error(errors, "EV-F02", f"HARD_FAILURE_CLAIM_MISSING:{fid}:{claim_ref}")
                invalid_support = True
                continue
            if (
                not claim["load_bearing"]
                or claim["qualification"] in {"CONFLICTED", "UNKNOWN", "REFUTED"}
                or claim["support_status"] not in {"SUPPORTED", "PARTIALLY_SUPPORTED"}
            ):
                invalid_support = True
        for evidence_ref in failure["evidence_refs"] + failure["counterevidence_refs"]:
            ev = evidence.get(evidence_ref)
            if ev is None:
                add_error(errors, "EV-F02", f"HARD_FAILURE_EVIDENCE_MISSING:{fid}:{evidence_ref}")
                invalid_support = True
            elif evidence_ref in failure["evidence_refs"] and ev["lifecycle_status"] != "ACTIVE":
                invalid_support = True
        for claim_ref in failure["claim_refs"]:
            connected = any(
                has_typed_edge(edge_index, evidence_ref, claim_ref, {"SUPPORTS", "PARTIALLY_SUPPORTS"})
                or path_exists(adjacency, {evidence_ref}, claim_ref)
                for evidence_ref in failure["evidence_refs"]
            )
            if not connected:
                invalid_support = True
        if failure["status"] == "SUPPORTED":
            if invalid_support:
                add_error(errors, "EV-F33", f"HARD_FAILURE_WITHOUT_QUALIFIED_SUPPORT:{fid}")
            else:
                supported.append(fid)

    propagation_by_failure: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for propagation in graph["hard_failure_propagation"]:
        fid = propagation["source_failure_ref"]
        if fid not in failures:
            add_error(errors, "EV-F34", f"ORPHAN_HARD_FAILURE_PROPAGATION:{propagation['propagation_id']}:{fid}")
            continue
        propagation_by_failure[fid].append(propagation)
        destination_level = propagation["destination_level"]
        destination_ref = propagation["destination_ref"]
        destination_valid = True
        if destination_level == "RUN":
            destination_valid = destination_ref == graph["run_id"]
        else:
            destination = external_nodes.get(destination_ref)
            if destination is None or destination["layer"] != destination_level:
                destination_valid = False
        if not destination_valid:
            add_error(
                errors,
                "EV-F34",
                f"ORPHAN_HARD_FAILURE_PROPAGATION:{propagation['propagation_id']}:destination:{destination_ref}:{destination_level}",
            )
            continue
        if destination_level != "RUN" and not path_exists(
            adjacency, failures[fid]["claim_refs"], destination_ref
        ):
            add_error(
                errors,
                "EV-F34",
                f"HARD_FAILURE_PROPAGATION_PATH_MISSING:{propagation['propagation_id']}:{fid}->{destination_ref}",
            )

    higher_layers = {node["layer"] for node in external_nodes.values()}
    for fid in supported:
        if higher_layers.intersection({"STUDY", "PUBLICATION", "VERDICT", "MODEL_CONDITION"}) and not propagation_by_failure.get(fid):
            add_error(errors, "EV-F18", f"HARD_FAILURE_PROPAGATION_MISSING:{fid}")
    return supported


def validate_lifecycle_edges(
    graph: dict[str, Any],
    evidence: dict[str, dict[str, Any]],
    errors: list[str],
) -> None:
    adjacency: dict[str, list[str]] = defaultdict(list)
    lifecycle_relations = {"SUPERSEDES", "REVOKES"}
    for edge in graph["edges"]:
        relation = edge["relation_type"]
        if relation not in lifecycle_relations:
            continue
        source = edge["from_ref"]
        target = edge["to_ref"]
        if source not in evidence or target not in evidence:
            continue
        adjacency[source].append(target)
        target_status = evidence[target]["lifecycle_status"]
        if relation == "SUPERSEDES" and target_status not in {"SUPERSEDED", "ARCHIVED"}:
            add_error(
                errors,
                "EV-F45",
                f"LIFECYCLE_EDGE_STATUS_MISMATCH:{edge['edge_id']}:SUPERSEDES:{target}:{target_status}",
            )
        if relation == "REVOKES" and target_status not in {"REVOKED", "ARCHIVED"}:
            add_error(
                errors,
                "EV-F45",
                f"LIFECYCLE_EDGE_STATUS_MISMATCH:{edge['edge_id']}:REVOKES:{target}:{target_status}",
            )
    state: dict[str, int] = {}
    def visit(node: str) -> bool:
        state[node] = 1
        for nxt in adjacency.get(node, []):
            if state.get(nxt) == 1:
                return True
            if state.get(nxt, 0) == 0 and visit(nxt):
                return True
        state[node] = 2
        return False
    for node in list(adjacency):
        if state.get(node, 0) == 0 and visit(node):
            add_error(errors, "EV-F45", "LIFECYCLE_EDGE_CYCLE")
            break


def validate_publication_paths(
    graph: dict[str, Any], layers: dict[str, str], errors: list[str]
) -> None:
    adjacency: dict[str, list[str]] = defaultdict(list)
    for edge in graph["edges"]:
        if edge["relation_type"] in {"AGGREGATES", "LIMITS", "SUPPORTS"}:
            adjacency[edge["from_ref"]].append(edge["to_ref"])
    verdict_starts = {node_id for node_id, layer in layers.items() if layer == "VERDICT"}
    for node_id, layer in layers.items():
        if layer == "PUBLICATION" and not path_exists(adjacency, verdict_starts, node_id):
            add_error(errors, "EV-F23", f"PUBLICATION_WITHOUT_VERDICT_PATH:{node_id}")
            add_error(errors, "EV-F29", f"PUBLICATION_WITHOUT_VERDICT_ANCESTRY:{node_id}")



# Alpha.9 semantic-contract closure helpers.
ALPHA9_SUPPORT_RELATIONS = {
    "CONTAINS",
    "EXTRACTED_FROM",
    "OBSERVES",
    "SUPPORTS",
    "PARTIALLY_SUPPORTS",
    "APPLIES_TO",
    "LIMITS",
    "DERIVED_FROM",
}


def _method_type_is(
    methods: dict[str, dict[str, Any]],
    ref: str | None,
    allowed: set[str],
    errors: list[str],
    context: str,
) -> bool:
    if not ref or ref not in methods:
        # The base validator emits EV-F13 for a missing method.
        return False
    actual = methods[ref]["method_type"]
    if actual not in allowed:
        add_error(
            errors,
            "EV-F48",
            f"METHOD_ROLE_MISMATCH:{context}:{ref}:{actual}:{'|'.join(sorted(allowed))}",
        )
        return False
    return True


def _fragment_locator_is_bounded(locator: dict[str, Any]) -> bool:
    kind = locator["kind"]
    value = locator["value"].strip()
    low = value.lower()
    if kind == "FULL":
        return low in {"entire file", "full content", "entire artifact", "full"}
    if kind in {"LINES", "PAGES", "ROWS"}:
        # Bounded numeric intervals such as 1, 1-20, L1-L20, 1,3-5.
        if not re.fullmatch(r"(?:[LPR])?\d+(?:-(?:[LPR])?\d+)?(?:,(?:[LPR])?\d+(?:-(?:[LPR])?\d+)?)*", value, re.I):
            return False
        for part in value.split(","):
            nums = [int(x) for x in re.findall(r"\d+", part)]
            if any(num < 1 for num in nums):
                return False
            if len(nums) == 2 and nums[0] > nums[1]:
                return False
        return True
    if kind == "JSON_POINTER":
        return value.startswith("/") and value != "/" and "*" not in value
    if kind == "TIME_RANGE":
        parts = value.split("/", 1)
        return len(parts) == 2 and all(part.strip() for part in parts) and low not in {"all/all", "start/end"}
    if kind == "OTHER":
        return ":" in value and low not in {"all", "all content", "all lines", "entire"}
    return False


def _alpha9_reverse(graph: dict[str, Any]) -> dict[str, list[str]]:
    return reverse_adjacency_for_relations(graph, ALPHA9_SUPPORT_RELATIONS)


def _claim_ancestor_sets(
    graph: dict[str, Any],
    claim_id: str,
    contents: dict[str, dict[str, Any]],
    evidence: dict[str, dict[str, Any]],
    observations: dict[str, dict[str, Any]],
    sources: dict[str, dict[str, Any]],
) -> tuple[set[str], set[str], set[str], set[str]]:
    reverse = _alpha9_reverse(graph)
    anc = ancestors(reverse, claim_id)
    return (
        {x for x in anc if x in contents},
        {x for x in anc if x in evidence},
        {x for x in anc if x in observations},
        {x for x in anc if x in sources},
    )


def _material_redacted_evidence(
    graph: dict[str, Any], evidence: dict[str, dict[str, Any]]
) -> set[str]:
    material_contents = {
        item["redacted_content_ref"]
        for item in graph.get("redactions", [])
        if item["semantic_materiality"] == "MATERIAL"
    }
    return {
        item["evidence_id"]
        for item in evidence.values()
        if material_contents.intersection(item.get("content_refs", []))
    }


def _edge_expected_method_types(
    relation: str, from_layer: str, to_layer: str
) -> set[str]:
    if relation == "CONTAINS":
        return {"VALIDATION"}
    if relation == "EXTRACTED_FROM":
        return {"COLLECTION"} if to_layer == "EVIDENCE" else {"EXTRACTION"}
    if relation == "OBSERVES":
        return {"EXTRACTION"}
    if relation == "DERIVED_FROM":
        return {"DERIVATION"}
    if relation in {"SCORES", "TRIGGERS_GATE", "AGGREGATES"}:
        return {"DERIVATION", "VALIDATION"}
    if relation in {"SUPERSEDES", "REVOKES", "CONFLICTS_WITH"}:
        return {"VALIDATION"}
    if relation in {"SUPPORTS", "PARTIALLY_SUPPORTS", "COUNTERS", "REFUTES", "APPLIES_TO", "LIMITS"}:
        if to_layer == "JUDGMENT" or from_layer == "VERDICT":
            return {"VALIDATION"}
        return {"INFERENCE", "CONFLICT_RESOLUTION"}
    return {"VALIDATION"}


def validate_alpha9_contract(
    graph: dict[str, Any],
    nodes: dict[str, dict[str, Any]],
    layers: dict[str, str],
    sources: dict[str, dict[str, Any]],
    contents: dict[str, dict[str, Any]],
    evidence: dict[str, dict[str, Any]],
    observations: dict[str, dict[str, Any]],
    claims: dict[str, dict[str, Any]],
    judgments: dict[str, dict[str, Any]],
    methods: dict[str, dict[str, Any]],
    errors: list[str],
) -> None:
    """Enforce alpha.9 graph-wide semantic invariants.

    This function remains structural. It validates declared roles, scope,
    lineage and epistemic eligibility; it does not interpret natural-language
    truth or decide whether a source is substantively persuasive.
    """
    edge_index = edge_key_index(graph)

    # A8-F56: bounded locator grammar, not merely a non-empty string.
    for content in contents.values():
        if not _fragment_locator_is_bounded(content["fragment_locator"]):
            add_error(
                errors,
                "EV-F56",
                f"INVALID_FRAGMENT_LOCATOR:{content['content_id']}:{content['fragment_locator']['kind']}:{content['fragment_locator']['value']}",
            )

    # A8-F48: method references are typed by their semantic role.
    for content in contents.values():
        if content.get("parser_ref"):
            _method_type_is(methods, content["parser_ref"], {"EXTRACTION"}, errors, f"content:{content['content_id']}")
    for item in evidence.values():
        _method_type_is(methods, item["collection_method_ref"], {"COLLECTION"}, errors, f"evidence:{item['evidence_id']}")
    for item in observations.values():
        _method_type_is(methods, item["extraction_method_ref"], {"EXTRACTION"}, errors, f"observation:{item['observation_id']}")
    resolution_claim_ids = {
        item.get("resolution_claim_ref")
        for item in graph.get("conflicts", [])
        if item.get("resolution_claim_ref")
    }
    for item in claims.values():
        allowed_claim_methods = {"INFERENCE", "CONFLICT_RESOLUTION"} if item["claim_id"] in resolution_claim_ids else {"INFERENCE"}
        _method_type_is(methods, item["inference_method_ref"], allowed_claim_methods, errors, f"claim:{item['claim_id']}")
    for item in judgments.values():
        _method_type_is(methods, item["method_ref"], {"VALIDATION"}, errors, f"judgment:{item['judgment_id']}")
    for item in graph.get("derivations", []):
        _method_type_is(methods, item["method_ref"], {"DERIVATION"}, errors, f"derivation:{item['derivation_id']}")
    for item in graph.get("redactions", []):
        _method_type_is(methods, item["method_ref"], {"REDACTION"}, errors, f"redaction:{item['redaction_id']}")
    for item in graph.get("conflicts", []):
        if item.get("resolution_method_ref"):
            _method_type_is(methods, item["resolution_method_ref"], {"CONFLICT_RESOLUTION"}, errors, f"conflict:{item['conflict_id']}")
    for edge in graph["edges"]:
        if edge["from_ref"] not in layers or edge["to_ref"] not in layers:
            continue
        allowed = _edge_expected_method_types(
            edge["relation_type"], layers[edge["from_ref"]], layers[edge["to_ref"]]
        )
        _method_type_is(methods, edge["method_ref"], allowed, errors, f"edge:{edge['edge_id']}:{edge['relation_type']}")

    # A8-F47: every ordinary evidence object has a bounded content root and
    # the declared field relations are mirrored by typed graph edges.
    for content in contents.values():
        if not has_typed_edge(
            edge_index,
            content["source_ref"],
            content["content_id"],
            {"CONTAINS"},
        ):
            add_error(errors, "EV-F47", f"BOUNDED_CONTENT_ROOT_MISSING:SOURCE_CONTENT:{content['content_id']}")
    for item in evidence.values():
        eid = item["evidence_id"]
        if not item["content_refs"] and item["evidence_type"] != "DERIVED_TRANSFORM":
            add_error(errors, "EV-F47", f"BOUNDED_CONTENT_ROOT_MISSING:EVIDENCE_CONTENT:{eid}")
        for cref in item["content_refs"]:
            if not has_typed_edge(edge_index, cref, eid, {"EXTRACTED_FROM"}):
                add_error(errors, "EV-F47", f"BOUNDED_CONTENT_ROOT_MISSING:CONTENT_EVIDENCE:{cref}->{eid}")

    reverse = _alpha9_reverse(graph)
    for judgment in judgments.values():
        if not judgment["score_eligible"]:
            continue
        jid = judgment["judgment_id"]
        anc = ancestors(reverse, jid)
        if not {x for x in anc if x in contents} or not {x for x in anc if x in sources}:
            add_error(errors, "EV-F47", f"SCORE_PATH_WITHOUT_BOUNDED_CONTENT:{jid}")

    # A8-F49: scope and estimand are monotone and bound to this graph.
    for obs in observations.values():
        incompatible = [
            eid for eid in obs["evidence_refs"]
            if eid in evidence and obs["observed_scope"] not in evidence[eid]["object_scope"]
        ]
        if not obs["evidence_refs"] or incompatible:
            add_error(errors, "EV-F49", f"OBSERVATION_SCOPE_NOT_SUPPORTED:{obs['observation_id']}:{obs['observed_scope']}:{','.join(sorted(incompatible))}")
    for claim in claims.values():
        cid = claim["claim_id"]
        _, eids, _, _ = _claim_ancestor_sets(graph, cid, contents, evidence, observations, sources)
        if claim["estimand_ref"] != graph["estimand_ref"]:
            add_error(errors, "EV-F49", f"CLAIM_ESTIMAND_MISMATCH:{cid}:{claim['estimand_ref']}:{graph['estimand_ref']}")
        incompatible = [
            eid for eid in eids
            if claim["scope"] not in evidence[eid]["object_scope"]
            or claim["estimand_ref"] not in evidence[eid]["estimand_scope"]
        ]
        if claim["support_status"] in {"SUPPORTED", "PARTIALLY_SUPPORTED"} and (not eids or incompatible):
            add_error(
                errors,
                "EV-F49",
                f"SCOPE_OR_ESTIMAND_EXPANSION:{cid}:{claim['scope']}:{claim['estimand_ref']}:{','.join(sorted(incompatible))}",
            )
    for derivation in graph.get("derivations", []):
        out = evidence.get(derivation["output_evidence_ref"])
        inputs = [evidence[x] for x in derivation["input_evidence_refs"] if x in evidence]
        if out and inputs:
            object_union = set().union(*(set(x["object_scope"]) for x in inputs))
            estimand_union = set().union(*(set(x["estimand_scope"]) for x in inputs))
            if not set(out["object_scope"]).issubset(object_union):
                add_error(errors, "EV-F49", f"DERIVED_SCOPE_EXPANSION:{out['evidence_id']}")
            if not set(out["estimand_scope"]).issubset(estimand_union):
                add_error(errors, "EV-F49", f"DERIVED_ESTIMAND_EXPANSION:{out['evidence_id']}")

    # A8-F50: zero-trust and negative-evidence rules follow full ancestry.
    for claim in claims.values():
        cid = claim["claim_id"]
        _, eids, _, _ = _claim_ancestor_sets(graph, cid, contents, evidence, observations, sources)
        ancestry_source_ids = {
            contents[cref]["source_ref"]
            for eid in eids
            for cref in evidence[eid]["content_refs"]
            if cref in contents
        }
        if claim["claim_type"] in {"NORMATIVE", "GOVERNANCE"} and claim["qualification"] == "FACT" and ancestry_source_ids:
            if any(sources[sid]["authority_class"] == "UNTRUSTED_CONTENT" for sid in ancestry_source_ids if sid in sources):
                add_error(errors, "EV-F50", f"TRANSITIVE_AUTHORITY_INJECTION:{cid}")
        if any(evidence[eid]["evidence_type"] == "NEGATIVE_SEARCH_RESULT" for eid in eids):
            if level_num(claim["claim_level"], {"claim_levels": {f'L{i}': i for i in range(8)}}) > 1:
                add_error(errors, "EV-F50", f"TRANSITIVE_NEGATIVE_EVIDENCE_OVERGENERALIZED:{cid}:{claim['claim_level']}")

    # A8-F55: epistemic adequacy of methods used for facts and scores.
    for claim in claims.values():
        method = methods.get(claim["inference_method_ref"])
        if not method:
            continue
        if claim["qualification"] == "FACT":
            if method["validation_status"] != "ACTIVE" or not method["deterministic"]:
                add_error(errors, "EV-F55", f"METHOD_EPISTEMIC_ADEQUACY:FACT:{claim['claim_id']}:{method['method_id']}")
        if method["validation_status"] == "CALIBRATING" and not (method["assumptions"] or method["failure_modes"]):
            add_error(errors, "EV-F55", f"CALIBRATING_METHOD_WITHOUT_LIMITATIONS:{method['method_id']}")
    for judgment in judgments.values():
        method = methods.get(judgment["method_ref"])
        if judgment["score_eligible"] and method:
            if method["validation_status"] != "ACTIVE":
                add_error(errors, "EV-F55", f"SCORE_METHOD_NOT_ACTIVE:{judgment['judgment_id']}:{method['method_id']}")
            if graph["mode"] == "CONFIRMATORY" and not method["deterministic"]:
                add_error(errors, "EV-F55", f"CONFIRMATORY_SCORE_METHOD_NONDETERMINISTIC:{judgment['judgment_id']}:{method['method_id']}")

    # Alpha.9 consolidated chain: every score-bearing claim retains an
    # OBSERVED layer and an ACTIVE inference method. Direct evidence may be
    # supplemental but cannot skip Observation.
    for judgment in judgments.values():
        if not judgment["score_eligible"]:
            continue
        for cref in judgment["claim_refs"]:
            claim = claims.get(cref)
            if not claim:
                continue
            observed = [
                oid for oid in claim["observation_refs"]
                if oid in observations and observations[oid]["status"] == "OBSERVED"
            ]
            if not observed:
                add_error(errors, "EV-F57", f"OBSERVATION_LAYER_BYPASS:{judgment['judgment_id']}:{cref}")
            method = methods.get(claim["inference_method_ref"])
            if method and method["validation_status"] != "ACTIVE":
                add_error(errors, "EV-F55", f"SCORE_CLAIM_METHOD_NOT_ACTIVE:{judgment['judgment_id']}:{cref}:{method['method_id']}")

    # Every DERIVED_TRANSFORM evidence object is backed by a declared
    # derivation record; a type label alone is not lineage.
    declared_outputs = {item["output_evidence_ref"] for item in graph.get("derivations", [])}
    for item in evidence.values():
        if item["evidence_type"] == "DERIVED_TRANSFORM" and item["evidence_id"] not in declared_outputs:
            add_error(errors, "EV-F47", f"DERIVED_EVIDENCE_WITHOUT_DERIVATION:{item['evidence_id']}")

    # A8-F51: hard failures require at least the same epistemic support as scores.
    material_evidence = _material_redacted_evidence(graph, evidence)
    for failure in graph.get("hard_failure_links", []):
        if failure["status"] != "SUPPORTED":
            continue
        fid = failure["failure_id"]
        invalid = False
        expected_counter: set[str] = set()
        for cref in failure["claim_refs"]:
            claim = claims.get(cref)
            if (
                not claim
                or not claim_is_epistemically_scorable(claim)
                or claim["qualification"] not in {"FACT", "SUPPORTED_INTERPRETATION"}
                or claim["support_status"] != "SUPPORTED"
            ):
                invalid = True
                continue
            expected_counter.update(claim["counterevidence_refs"])
            _, eids, oids, _ = _claim_ancestor_sets(graph, cref, contents, evidence, observations, sources)
            if not eids or any(evidence[x]["lifecycle_status"] != "ACTIVE" for x in eids):
                invalid = True
            if any(observations[x]["status"] != "OBSERVED" for x in oids):
                invalid = True
            if material_evidence.intersection(eids):
                invalid = True
            if not any(
                claim["scope"] in evidence[x]["object_scope"]
                and claim["estimand_ref"] in evidence[x]["estimand_scope"]
                for x in eids
            ):
                invalid = True
        if not expected_counter.issubset(set(failure["counterevidence_refs"])):
            invalid = True
        if invalid:
            add_error(errors, "EV-F51", f"HARD_FAILURE_EPISTEMIC_SUPPORT_INVALID:{fid}")

    # A8-F52: a resolved conflict must be resolved by a related claim/method.
    resolution_relations = {"COUNTERS", "REFUTES", "CONFLICTS_WITH"}
    resolution_adj: dict[str, list[str]] = defaultdict(list)
    for edge in graph["edges"]:
        if edge["relation_type"] in resolution_relations:
            resolution_adj[edge["from_ref"]].append(edge["to_ref"])
    for conflict in graph.get("conflicts", []):
        if conflict["status"] != "RESOLVED":
            continue
        rid = conflict.get("resolution_claim_ref")
        rmethod = conflict.get("resolution_method_ref")
        rclaim = claims.get(rid) if rid else None
        related = bool(rid and path_exists(resolution_adj, {conflict["claim_ref"], *conflict["evidence_refs"]}, rid))
        method_edge = any(edge["to_ref"] == rid and edge["method_ref"] == rmethod for edge in graph["edges"])
        retained = bool(rclaim) and set(conflict["evidence_refs"]).issubset(set(rclaim["supporting_evidence_refs"] + rclaim["counterevidence_refs"]))
        if not (related and method_edge and retained):
            add_error(errors, "EV-F52", f"CONFLICT_RESOLUTION_UNRELATED:{conflict['conflict_id']}")

    # A8-F53: lifecycle chains of every allowed node type must be acyclic.
    life_adj: dict[str, list[str]] = defaultdict(list)
    for edge in graph["edges"]:
        if edge["relation_type"] in {"SUPERSEDES", "REVOKES"}:
            life_adj[edge["from_ref"]].append(edge["to_ref"])
    state: dict[str, int] = {}
    def visit(node: str) -> bool:
        state[node] = 1
        for nxt in life_adj.get(node, []):
            if state.get(nxt) == 1:
                return True
            if state.get(nxt, 0) == 0 and visit(nxt):
                return True
        state[node] = 2
        return False
    for node in list(life_adj):
        if state.get(node, 0) == 0 and visit(node):
            add_error(errors, "EV-F53", "LIFECYCLE_CYCLE_ANY_NODE")
            break

    # A8-F54: each internal publication claim must have its own verdict ancestry.
    pub_adj: dict[str, list[str]] = defaultdict(list)
    for edge in graph["edges"]:
        if edge["relation_type"] in {"AGGREGATES", "LIMITS", "SUPPORTS"}:
            pub_adj[edge["from_ref"]].append(edge["to_ref"])
    verdict_starts = {nid for nid, layer in layers.items() if layer == "VERDICT"}
    for claim in claims.values():
        if claim["claim_type"] != "PUBLICATION":
            continue
        verdict_ref = claim.get("verdict_ref")
        if (
            not verdict_ref
            or verdict_ref not in verdict_starts
            or not path_exists(pub_adj, {verdict_ref}, claim["claim_id"])
        ):
            add_error(errors, "EV-F54", f"PUBLICATION_CLAIM_WITHOUT_OWN_VERDICT_PATH:{claim['claim_id']}:{verdict_ref}")

def validate(
    graph: dict[str, Any], schema: dict[str, Any], registry: dict[str, Any], root: Path
) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    validate_schema(graph, schema, errors)
    if errors:
        return report(graph, errors, warnings, {}, False, [])
    validate_global_ids(graph, errors)
    nodes, layers = build_nodes(graph, errors)
    methods = validate_methods(graph, errors, warnings)
    sources = {item["source_id"]: item for item in graph["sources"]}
    contents = {item["content_id"]: item for item in graph["contents"]}
    evidence = {item["evidence_id"]: item for item in graph["evidence"]}
    observations = {item["observation_id"]: item for item in graph["observations"]}
    claims = {item["claim_id"]: item for item in graph["claims"]}
    judgments = {item["judgment_id"]: item for item in graph["judgments"]}
    external_nodes = {item["node_id"]: item for item in graph["external_nodes"]}

    validate_content(graph, root, sources, methods, errors, warnings)
    evidence_sources = validate_evidence(graph, contents, sources, methods, errors, warnings)
    validate_observations(graph, evidence, methods, errors)
    validate_claims(
        graph,
        observations,
        evidence,
        evidence_sources,
        sources,
        methods,
        registry,
        errors,
    )
    validate_judgments(graph, claims, observations, evidence, methods, errors)
    validate_conflicts(graph, claims, evidence, methods, errors)
    _, edge_index = validate_edges(graph, nodes, layers, evidence, methods, registry, errors)
    declared_complete = validate_declared_reference_edges(graph, edge_index, errors)
    transitive_complete = validate_transitive_judgment_support(graph, evidence, claims, errors)
    validate_derivations(graph, evidence, methods, errors, warnings)
    validate_lifecycle_edges(graph, evidence, errors)
    validate_redactions(graph, contents, methods, judgments, errors, warnings)
    supported_hard_failures = validate_hard_failures(
        graph, claims, evidence, external_nodes, registry, errors
    )
    validate_publication_paths(graph, layers, errors)
    validate_alpha9_contract(
        graph, nodes, layers, sources, contents, evidence, observations, claims,
        judgments, methods, errors
    )
    complete = not errors and declared_complete and transitive_complete
    return report(
        graph,
        errors,
        warnings,
        judgments,
        complete,
        supported_hard_failures,
    )


def report(
    graph: dict[str, Any],
    errors: list[str],
    warnings: list[str],
    judgments: dict[str, dict[str, Any]],
    complete: bool,
    hard_failures: list[str],
) -> dict[str, Any]:
    conflicted = [
        claim["claim_id"]
        for claim in graph.get("claims", [])
        if claim.get("qualification") == "CONFLICTED"
    ]
    unscorable = [
        judgment["judgment_id"]
        for judgment in graph.get("judgments", [])
        if judgment.get("status") in {"CONFLICTED", "UNSCORABLE"}
    ]
    eligible = [
        judgment["judgment_id"]
        for judgment in graph.get("judgments", [])
        if judgment.get("score_eligible")
    ]
    status = "INVALID" if errors else ("VALID_WITH_LIMITATIONS" if warnings else "VALID")
    return {
        "validator_version": ENGINE_VERSION,
        "graph_id": graph.get("graph_id"),
        "status": status,
        "errors": sorted(set(errors)),
        "warnings": sorted(set(warnings)),
        "node_counts": {
            key: len(graph.get(key, []))
            for key in [
                "sources",
                "contents",
                "evidence",
                "observations",
                "claims",
                "judgments",
                "external_nodes",
            ]
        },
        "edge_count": len(graph.get("edges", [])),
        "conflicted_claims": conflicted,
        "unscorable_judgments": unscorable,
        "score_eligible_judgments": eligible,
        "hard_failures_preserved": sorted(hard_failures),
        "provenance_complete": complete,
        "truth_determined": False,
        "winner_selected": False,
        "scores_emitted": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("graph", type=Path)
    parser.add_argument("--schema", type=Path, required=True)
    parser.add_argument("--registry", type=Path, required=True)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    graph = load_json(args.graph)
    schema = load_json(args.schema)
    registry = load_yaml(args.registry)
    root = args.root or args.graph.parent
    result = validate(graph, schema, registry, root)
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.out:
        args.out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    return 0 if result["status"] != "INVALID" else 2


if __name__ == "__main__":
    raise SystemExit(main())
