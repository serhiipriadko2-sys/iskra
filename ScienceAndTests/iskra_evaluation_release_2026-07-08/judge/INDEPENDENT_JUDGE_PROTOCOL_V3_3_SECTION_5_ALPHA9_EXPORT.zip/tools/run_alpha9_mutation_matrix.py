from __future__ import annotations
import copy, importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('validator',ROOT/'tools/validate_evidence_graph.py')
validator=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(validator)
SCHEMA=validator.load_json(ROOT/'05_EVIDENCE_PROVENANCE.schema.json')
REGISTRY=validator.load_yaml(ROOT/'05_EVIDENCE_PROVENANCE_REGISTRY.yaml')
VALID_PATH=ROOT/'fixtures/section5/valid/graph.json'
BASE=validator.load_json(VALID_PATH)

def check(name,g,code):
    res=validator.validate(g,SCHEMA,REGISTRY,VALID_PATH.parent)
    passed=res['status']=='INVALID' and res['provenance_complete'] is False and any(e.startswith(code+' ') for e in res['errors'])
    return {'name':name,'expected_code':code,'passed':passed,'status':res['status'],'errors':res['errors']}

cases=[]
# Locator grammar
for i,(kind,value) in enumerate([
    ('LINES','all lines'),('LINES','10-5'),('LINES','0-3'),('PAGES','all'),('PAGES','4-2'),
    ('ROWS','*'),('TIME_RANGE','forever'),('JSON_POINTER','/*'),('OTHER','*'),
]):
    g=copy.deepcopy(BASE); g['contents'][0]['fragment_locator']={'kind':kind,'value':value}
    cases.append(check(f'locator_{i}_{kind}',g,'EV-F56'))
# Observation epistemic states
for st in ['PARTIAL','CONFLICTED','UNSCORABLE','NOT_OBSERVED']:
    g=copy.deepcopy(BASE); g['observations'][0]['status']=st
    cases.append(check(f'observation_{st}',g,'EV-F37'))
# Claim nonscorable combinations
for q,s in [('UNKNOWN','NOT_EVALUATED'),('REFUTED','REFUTED'),('CONFLICTED','CONFLICTED'),('HYPOTHESIS','INSUFFICIENT_EVIDENCE')]:
    g=copy.deepcopy(BASE); g['claims'][0]['qualification']=q; g['claims'][0]['support_status']=s; g['claims'][0]['load_bearing']=False
    cases.append(check(f'claim_{q}_{s}',g,'EV-F38'))
# Method role substitutions
roles={'M-COLLECT':'VALIDATION','M-PARSE':'COLLECTION','M-INFER':'COLLECTION','M-JUDGE':'COLLECTION'}
for mid,bad in roles.items():
    g=copy.deepcopy(BASE)
    for m in g['methods']:
        if m['method_id']==mid: m['method_type']=bad
    cases.append(check(f'method_role_{mid}_{bad}',g,'EV-F48'))
# Scope and estimand mismatches
for field,value in [('claim_scope','global_model'),('claim_estimand','EST-OTHER'),('observation_scope','global_model'),('evidence_scope','other_runtime'),('evidence_estimand','EST-OTHER')]:
    g=copy.deepcopy(BASE)
    if field=='claim_scope': g['claims'][0]['scope']=value
    elif field=='claim_estimand': g['claims'][0]['estimand_ref']=value
    elif field=='observation_scope': g['observations'][0]['observed_scope']=value
    elif field=='evidence_scope': g['evidence'][0]['object_scope']=[value]
    else: g['evidence'][0]['estimand_scope']=[value]
    cases.append(check(f'scope_{field}',g,'EV-F49'))
# URI threats
for i,ref in enumerate(['file:///etc/passwd','smb://host/share','data:text/plain,x','javascript:alert(1)','//host/share','C:/Windows/System32','%252e%252e/out']):
    g=copy.deepcopy(BASE); g['contents'][0]['content_ref']=ref
    code='EV-F26' if '%' in ref else 'EV-F35'
    cases.append(check(f'uri_{i}',g,code))
# Publication exact binding
for i,ref in enumerate(['VERDICT-GHOST','STUDY-1']):
    g=copy.deepcopy(BASE); g['claims'][0]['claim_type']='PUBLICATION'; g['claims'][0]['verdict_ref']=ref
    cases.append(check(f'publication_ref_{i}',g,'EV-F54'))
# Derivation evidence without declaration
g=copy.deepcopy(BASE); e=copy.deepcopy(g['evidence'][0]); e.update({'evidence_id':'E-DYNAMIC-DER','evidence_type':'DERIVED_TRANSFORM','content_refs':[]}); g['evidence'].append(e)
cases.append(check('derived_without_record',g,'EV-F47'))

out={'matrix_version':'alpha9-dynamic-v1','total':len(cases),'passed':sum(x['passed'] for x in cases),'all_passed':all(x['passed'] for x in cases),'cases':cases}
path=ROOT/'SECTION5_ALPHA9_DYNAMIC_MUTATION_RESULTS.json'; path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('total','passed','all_passed')},indent=2))
raise SystemExit(0 if out['all_passed'] else 1)
