#!/usr/bin/env python3
"""Reference hard-gate disposition engine for IJP v3.3 Section 3.

This engine does not determine whether natural-language content is true or safe.
It consumes evidence-backed gate observations, validates their completeness, and
computes deterministic consequences. It never produces a winner.
"""
from __future__ import annotations

import argparse
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator

CLAIM_ORDER = {f"L{i}": i for i in range(8)}
UNRESOLVED = {"UNKNOWN", "CONFLICTED", "NOT_RUN"}


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def required_for_context(gate: dict[str, Any], context: dict[str, Any]) -> bool:
    if gate.get("required", False):
        return True
    condition = gate.get("required_when")
    if condition == "comparison_requested":
        return bool(context.get("comparison_requested"))
    if condition == "publication_claim_present":
        return bool(context.get("publication_claim_present"))
    if condition == "high_stakes":
        return bool(context.get("high_stakes"))
    if condition == "comparative_or_publication_claim":
        return bool(context.get("comparison_requested") or context.get("publication_claim_present"))
    return False


def normalize_observations(
    request: dict[str, Any], registry: dict[str, Any]
) -> tuple[dict[str, dict[str, Any]], list[str]]:
    issues: list[str] = []
    observations: dict[str, dict[str, Any]] = {}
    known = {g["gate_id"] for g in registry["gates"]}
    for item in request["gate_observations"]:
        gid = item["gate_id"]
        if gid not in known:
            issues.append(f"UNKNOWN_GATE:{gid}")
            continue
        if gid in observations:
            issues.append(f"DUPLICATE_GATE:{gid}")
            continue
        observations[gid] = deepcopy(item)

    context = request["evaluation_context"]
    if context.get("publication_claim_present"):
        ceiling = context["claim_ceiling_level"]
        proposed = context.get("proposed_claim_level")
        computed = {
            "gate_id": "HG-PUB-001",
            "status": "UNKNOWN" if proposed is None else (
                "PASS" if CLAIM_ORDER[proposed] <= CLAIM_ORDER[ceiling] else "FAIL"
            ),
            "reason": (
                "Proposed publication claim level is missing."
                if proposed is None
                else f"Computed claim level check: proposed={proposed}, ceiling={ceiling}."
            ),
            "evidence_refs": [f"computed:claim-level:{proposed or 'missing'}<=ceiling:{ceiling}"],
            "method_ref": "IJP-CLAIM-LEVEL-ORDER-v1",
            "confidence": 1.0 if proposed is not None else None,
            "applicability_reason": "Publication claim is present.",
            "observed_at": None,
        }
        prior = observations.get("HG-PUB-001")
        if prior and prior["status"] != computed["status"]:
            issues.append("CLAIM_CEILING_OBSERVATION_OVERRIDDEN")
        observations["HG-PUB-001"] = computed

    for gate in registry["gates"]:
        gid = gate["gate_id"]
        if gid not in observations and required_for_context(gate, context):
            observations[gid] = {
                "gate_id": gid,
                "status": "NOT_RUN",
                "reason": "Required gate observation is missing.",
                "evidence_refs": [],
                "method_ref": None,
                "confidence": None,
                "applicability_reason": None,
                "observed_at": None,
            }
            issues.append(f"REQUIRED_GATE_NOT_RUN:{gid}")
    return observations, issues


def derive_primary_disposition(effects: set[str], precedence: list[str]) -> str:
    triggers = {
        "INVALIDATED_RUN": "INVALIDATE_RUN" in effects,
        "REJECTED_PACKAGE": "REJECT_PACKAGE" in effects,
        "HUMAN_ESCALATION_REQUIRED": "HUMAN_ESCALATION" in effects,
        "HARD_FAIL_OBJECT": "HARD_FAIL_OBJECT" in effects,
        "UNSCORABLE": "BLOCK_SCORING" in effects,
        "POINTWISE_ONLY": "BLOCK_COMPARISON" in effects,
        "PROCEED_WITH_LIMITATIONS": bool(
            effects
            & {
                "CONTINUE_WITH_LIMITATIONS",
                "BLOCK_CRITERION",
                "BLOCK_COMPOSITE",
                "BLOCK_PUBLICATION",
                "REQUIRE_ADJUDICATION",
            }
        ),
        "PROCEED": True,
    }
    for disposition in precedence:
        if triggers.get(disposition, False):
            return disposition
    raise RuntimeError("No primary disposition could be derived")


def apply_score_policy(
    disposition: str, effects: set[str], diagnostic_scores: dict[str, Any] | None
) -> tuple[dict[str, Any] | None, dict[str, bool]]:
    scores = deepcopy(diagnostic_scores) if diagnostic_scores is not None else None
    policy = {
        "criterion_scoring_allowed": True,
        "diagnostic_scoring_allowed": True,
        "composite_allowed": True,
        "ranking_allowed": True,
    }
    if disposition in {"INVALIDATED_RUN", "REJECTED_PACKAGE", "UNSCORABLE"}:
        scores = None
        policy.update(
            criterion_scoring_allowed=False,
            diagnostic_scoring_allowed=False,
            composite_allowed=False,
            ranking_allowed=False,
        )
    elif disposition == "HARD_FAIL_OBJECT":
        policy.update(composite_allowed=False, ranking_allowed=False)
        if scores is not None:
            scores["C100"] = None
    elif disposition == "HUMAN_ESCALATION_REQUIRED":
        policy.update(composite_allowed=False, ranking_allowed=False)
        if scores is not None:
            scores["C100"] = None
    elif disposition == "POINTWISE_ONLY":
        policy["ranking_allowed"] = False
    if "BLOCK_COMPOSITE" in effects:
        policy["composite_allowed"] = False
        if scores is not None:
            scores["C100"] = None
    if "BLOCK_COMPARISON" in effects:
        policy["ranking_allowed"] = False
    return scores, policy


def evaluate(
    request: dict[str, Any], registry: dict[str, Any], schema: dict[str, Any]
) -> dict[str, Any]:
    schema_errors = sorted(Draft202012Validator(schema).iter_errors(request), key=lambda e: list(e.path))
    if schema_errors:
        return {
            "run_id": request.get("run_id", "unknown"),
            "engine_status": "REQUEST_INVALID",
            "validation_issues": [e.message for e in schema_errors],
            "primary_disposition": "REJECTED_PACKAGE",
            "eligibility": "INVALID_PACKAGE",
            "comparison_verdict": "INCOMPARABLE",
            "effects": ["REJECT_PACKAGE", "BLOCK_SCORING", "BLOCK_COMPARISON"],
            "failures": [],
            "gate_results": [],
            "scores": None,
            "score_policy": {
                "criterion_scoring_allowed": False,
                "diagnostic_scoring_allowed": False,
                "composite_allowed": False,
                "ranking_allowed": False,
            },
            "publication_allowed": False,
            "comparison_allowed": False,
            "winner": None,
        }

    observations, issues = normalize_observations(request, registry)
    definitions = {g["gate_id"]: g for g in registry["gates"]}
    effects: set[str] = set()
    failures: list[dict[str, Any]] = []
    gate_results: list[dict[str, Any]] = []

    for gid, obs in sorted(observations.items()):
        gate = definitions[gid]
        status = obs["status"]
        local_issues: list[str] = []
        if status == "NOT_APPLICABLE" and not gate.get("not_applicable_allowed", False):
            local_issues.append("NOT_APPLICABLE_NOT_ALLOWED")
            status = "UNKNOWN"
        if status in set(gate.get("evidence_required_on", [])) and not obs.get("evidence_refs"):
            local_issues.append("MISSING_REQUIRED_EVIDENCE")
            status = "UNKNOWN"

        gate_effects: list[str] = []
        if status == "FAIL":
            gate_effects = list(gate["fail_effects"])
            failures.append(
                {
                    "gate_id": gid,
                    "failure_code": gate["fail_code"],
                    "family": gate["family"],
                    "severity": gate["fail_severity"],
                    "reason": obs["reason"],
                    "evidence_refs": obs.get("evidence_refs", []),
                    "effects": gate_effects,
                }
            )
        elif status in UNRESOLVED:
            gate_effects = list(gate["unresolved_effects"])
        effects.update(gate_effects)
        issues.extend(f"{gid}:{x}" for x in local_issues)
        gate_results.append(
            {
                "gate_id": gid,
                "stage": gate["stage"],
                "scope": gate["scope"],
                "family": gate["family"],
                "status": status,
                "reason": obs["reason"],
                "evidence_refs": obs.get("evidence_refs", []),
                "effects": gate_effects,
                "issues": local_issues,
            }
        )

    if not effects:
        effects.add("CONTINUE")
    primary = derive_primary_disposition(effects, registry["primary_dispositions_precedence"])
    eligibility = registry["eligibility_mapping"][primary]
    comparison_verdict = registry["comparison_mapping"].get(primary)
    scores, score_policy = apply_score_policy(primary, effects, request.get("diagnostic_scores"))
    publication_allowed = "BLOCK_PUBLICATION" not in effects and primary not in {
        "INVALIDATED_RUN",
        "REJECTED_PACKAGE",
    }
    comparison_allowed = score_policy["ranking_allowed"] and "BLOCK_COMPARISON" not in effects

    return {
        "run_id": request["run_id"],
        "engine_status": "EVALUATED",
        "validation_issues": sorted(set(issues)),
        "primary_disposition": primary,
        "eligibility": eligibility,
        "comparison_verdict": comparison_verdict,
        "effects": sorted(effects),
        "failures": failures,
        "gate_results": gate_results,
        "scores": scores,
        "score_policy": score_policy,
        "publication_allowed": publication_allowed,
        "comparison_allowed": comparison_allowed,
        "winner": None,
        "boundary": "Reference engine derives consequences from evidence-backed gate observations; it does not judge natural-language truth or safety and never selects a winner.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("request", type=Path)
    parser.add_argument(
        "--registry",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "03_HARD_GATES_REGISTRY.yaml",
    )
    parser.add_argument(
        "--schema",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "03_HARD_GATES.schema.json",
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    report = evaluate(load_json(args.request), load_yaml(args.registry), load_json(args.schema))
    text = json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    return 0 if report["engine_status"] == "EVALUATED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
