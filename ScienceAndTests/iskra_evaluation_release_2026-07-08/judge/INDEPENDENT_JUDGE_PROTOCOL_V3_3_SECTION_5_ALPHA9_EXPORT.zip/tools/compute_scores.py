#!/usr/bin/env python3
"""Deterministic scoring engine for IJP v3.3 Section 4.

Consumes typed criterion data and a Section 3 score policy. It never reads
candidate free text, never decides truth, and never selects a winner.
"""
from __future__ import annotations
import argparse, hashlib, json, math
from copy import deepcopy
from pathlib import Path
from typing import Any
import yaml
from jsonschema import Draft202012Validator

ENGINE_VERSION = "IJP-SCORING-ENGINE-v1"
DOMAINS = ["Q100","S100","A100","R100","G100"]
BLOCKED_DISPOSITIONS = {False}


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize(raw: Any, scale: dict[str, Any]) -> float:
    kind = scale["kind"]
    if kind in {"BINARY","ANCHORED_ORDINAL"}:
        key = str(raw).lower() if isinstance(raw, bool) else str(raw)
        point_map = scale["point_map"]
        if key not in point_map:
            raise ValueError("INVALID_RAW_VALUE")
        return float(point_map[key])
    if kind in {"PERCENT","BOUNDED_CONTINUOUS"}:
        if isinstance(raw, bool) or not isinstance(raw, (int,float)):
            raise ValueError("INVALID_RAW_VALUE")
        a, b = float(scale["raw_min"]), float(scale["raw_max"])
        x = float(raw)
        if not (a <= x <= b):
            raise ValueError("INVALID_RAW_VALUE")
        return 100.0 * (x-a)/(b-a)
    raise ValueError("UNSUPPORTED_SCALE_KIND")


def weighted_mean(items: list[tuple[float,float]]) -> float:
    total = sum(w for w,_ in items)
    if total <= 0:
        raise ValueError("INVALID_WEIGHT_CONFIGURATION")
    return sum(w*s for w,s in items)/total


def weighted_geometric(items: list[tuple[float,float]]) -> float:
    total = sum(w for w,_ in items)
    if total <= 0:
        raise ValueError("INVALID_WEIGHT_CONFIGURATION")
    if any(score == 0 for _, score in items):
        return 0.0
    return 100.0 * math.exp(sum((w/total)*math.log(score/100.0) for w,score in items))


def applicability_signature(profile: dict[str,Any], criterion_status: dict[str,str]) -> str:
    payload = {
        "profile": f"{profile['profile_id']}@{profile['version']}",
        "domains": {
            d: {
                "applicability": cfg["applicability"],
                "criteria": sorted((c["criterion_id"], criterion_status.get(c["criterion_id"], "MISSING")) for c in cfg["criteria"])
            }
            for d,cfg in sorted(profile["domains"].items())
        }
    }
    data = json.dumps(payload, sort_keys=True, separators=(",",":")).encode()
    return hashlib.sha256(data).hexdigest()


def sensitivity(profile: dict[str,Any], domain_scores: dict[str,float]) -> dict[str,Any]:
    frac = float(profile.get("weight_perturbation_fraction",0.10))
    base = [(profile["domains"][d]["composite_weight"], domain_scores[d]) for d in DOMAINS if d in domain_scores]
    base_score = weighted_geometric(base)
    scenarios=[]
    for domain in domain_scores:
        weights={d:float(profile["domains"][d]["composite_weight"]) for d in domain_scores}
        weights[domain] *= 1.0+frac
        total=sum(weights.values())
        items=[(weights[d]/total,domain_scores[d]) for d in domain_scores]
        score=weighted_geometric(items)
        scenarios.append({"domain":domain,"direction":"UP","score":score,"delta":score-base_score})
        weights={d:float(profile["domains"][d]["composite_weight"]) for d in domain_scores}
        weights[domain] *= max(0.0,1.0-frac)
        total=sum(weights.values())
        items=[(weights[d]/total,domain_scores[d]) for d in domain_scores]
        score=weighted_geometric(items)
        scenarios.append({"domain":domain,"direction":"DOWN","score":score,"delta":score-base_score})
    vals=[s["score"] for s in scenarios] or [base_score]
    return {"method":"IJP-WEIGHT-OAT-v1","fraction":frac,"base":base_score,"min":min(vals),"max":max(vals),"scenarios":scenarios}


def evaluate(req: dict[str,Any], registry: dict[str,Any], schema: dict[str,Any], registry_hash: str) -> dict[str,Any]:
    errors=sorted(Draft202012Validator(schema).iter_errors(req),key=lambda e:list(e.path))
    if errors:
        return {"engine_status":"REQUEST_INVALID","run_id":req.get("run_id","unknown"),"unit_id":req.get("unit_id","unknown"),"score_vector":None,"criterion_results":[],"warnings":[],"errors":[e.message for e in errors],"comparison":{"status":"INFERENTIAL_UNAVAILABLE","winner":None,"reason":"Request schema invalid."},"provenance":{"engine_version":ENGINE_VERSION,"registry_sha256":registry_hash,"formula_ids":[]}}
    policy=req["score_policy"]
    if not policy["criterion_scoring_allowed"] and not policy["diagnostic_scoring_allowed"]:
        return {"engine_status":"UNSCORABLE","run_id":req["run_id"],"unit_id":req["unit_id"],"score_vector":None,"criterion_results":[],"warnings":[],"errors":["SCR-F01 SECTION3_SCORING_BLOCKED"],"comparison":{"status":"BLOCKED_BY_SECTION_3","winner":None,"reason":"Section 3 score policy blocks scoring."},"provenance":{"engine_version":ENGINE_VERSION,"registry_sha256":registry_hash,"formula_ids":[]}}
    profiles={p["profile_id"]:p for p in registry["profiles"]}
    if req["profile_id"] not in profiles:
        return {"engine_status":"REQUEST_INVALID","run_id":req["run_id"],"unit_id":req["unit_id"],"score_vector":None,"criterion_results":[],"warnings":[],"errors":["SCR-F02 UNKNOWN_PROFILE"],"comparison":{"status":"INFERENTIAL_UNAVAILABLE","winner":None,"reason":"Unknown profile."},"provenance":{"engine_version":ENGINE_VERSION,"registry_sha256":registry_hash,"formula_ids":[]}}
    profile=profiles[req["profile_id"]]
    warnings=[]; errors=[]
    if profile["lifecycle"]=="TEST_ONLY" and req["environment"]!="TEST": errors.append("SCR-F04 TEST_PROFILE_OUTSIDE_TEST")
    if req["mode"]=="CONFIRMATORY" and profile["lifecycle"]!="ACTIVE": errors.append("SCR-F03 PROFILE_NOT_ACTIVE")
    if errors:
        return {"engine_status":"UNSCORABLE","run_id":req["run_id"],"unit_id":req["unit_id"],"score_vector":None,"criterion_results":[],"warnings":warnings,"errors":errors,"comparison":{"status":"INFERENTIAL_UNAVAILABLE","winner":None,"reason":"Profile lifecycle blocks requested use."},"provenance":{"engine_version":ENGINE_VERSION,"registry_sha256":registry_hash,"formula_ids":[]}}
    scales={s["scale_id"]:s for s in registry["scales"]}
    declared={c["criterion_id"]:(d,c) for d,cfg in profile["domains"].items() for c in cfg["criteria"]}
    provided={}
    for item in req["criteria"]:
        cid=item["criterion_id"]
        if cid in provided: errors.append(f"SCR-F16 DUPLICATE_CRITERION:{cid}")
        provided[cid]=item
        if cid not in declared: errors.append(f"SCR-F17 UNDECLARED_CRITERION:{cid}")
        elif item["domain"]!=declared[cid][0]: errors.append(f"DOMAIN_MISMATCH:{cid}")
    if errors:
        return {"engine_status":"REQUEST_INVALID","run_id":req["run_id"],"unit_id":req["unit_id"],"score_vector":None,"criterion_results":[],"warnings":warnings,"errors":errors,"comparison":{"status":"INFERENTIAL_UNAVAILABLE","winner":None,"reason":"Criterion declaration mismatch."},"provenance":{"engine_version":ENGINE_VERSION,"registry_sha256":registry_hash,"formula_ids":[]}}
    criterion_results=[]; scores_by_domain={d:[] for d in DOMAINS}; interval_by_domain={d:[] for d in DOMAINS}; statuses={}
    domain_meta={d:{"applicable_weight":0.0,"scored_weight":0.0,"required_missing":[],"optional_unresolved":[],"criteria":[]} for d in DOMAINS}
    for cid,(domain,definition) in declared.items():
        item=provided.get(cid)
        status=item["status"] if item else "NOT_RUN"
        statuses[cid]=status
        weight=float(definition["weight"])
        if status=="NOT_APPLICABLE":
            criterion_results.append({"criterion_id":cid,"domain":domain,"status":status,"points_0_100":None,"scale_ref":definition["scale_ref"],"evidence_refs":item["evidence_refs"] if item else [],"score_method":None,"confidence_used_in_score":False,"limitations":["Excluded by pre-frozen applicability."]})
            continue
        domain_meta[domain]["applicable_weight"] += weight
        domain_meta[domain]["criteria"].append(cid)
        if status!="SCORED":
            if definition["required"]: domain_meta[domain]["required_missing"].append(cid)
            else: domain_meta[domain]["optional_unresolved"].append(cid)
            criterion_results.append({"criterion_id":cid,"domain":domain,"status":status,"points_0_100":None,"scale_ref":definition["scale_ref"],"evidence_refs":item["evidence_refs"] if item else [],"score_method":None,"confidence_used_in_score":False,"limitations":["Missingness was not converted to zero."]})
            continue
        if not item["evidence_refs"]: errors.append(f"MISSING_EVIDENCE:{cid}")
        scale_ref=definition["scale_ref"]
        if item["scale_ref"]!=scale_ref: errors.append(f"SCALE_MISMATCH:{cid}")
        if scale_ref not in scales: errors.append(f"SCR-F05 UNKNOWN_SCALE:{scale_ref}"); continue
        try: score=normalize(item["raw_value"],scales[scale_ref])
        except ValueError: errors.append(f"SCR-F06 INVALID_RAW_VALUE:{cid}"); continue
        domain_meta[domain]["scored_weight"] += weight
        scores_by_domain[domain].append((weight,score))
        interval=item.get("uncertainty_interval")
        if interval is not None:
            if interval["lower"]>interval["upper"]: errors.append(f"SCR-F18 INTERVAL_INVALID:{cid}")
            else: interval_by_domain[domain].append((weight,float(interval["lower"]),float(interval["upper"])))
        criterion_results.append({"criterion_id":cid,"domain":domain,"status":"SCORED","points_0_100":score,"scale_ref":scale_ref,"evidence_refs":item["evidence_refs"],"score_method":registry["formula_ids"]["criterion_map"] if scales[scale_ref]["kind"] in {"BINARY","ANCHORED_ORDINAL"} else registry["formula_ids"]["bounded_linear"],"confidence_used_in_score":False,"limitations":[]})
    if errors:
        return {"engine_status":"REQUEST_INVALID","run_id":req["run_id"],"unit_id":req["unit_id"],"score_vector":None,"criterion_results":criterion_results,"warnings":warnings,"errors":errors,"comparison":{"status":"INFERENTIAL_UNAVAILABLE","winner":None,"reason":"Criterion normalization failed."},"provenance":{"engine_version":ENGINE_VERSION,"registry_sha256":registry_hash,"formula_ids":list(registry["formula_ids"].values())}}
    domain_outputs={}; domain_values={}; domain_intervals={}
    for d in DOMAINS:
        cfg=profile["domains"].get(d)
        if cfg is None or cfg["applicability"]=="NOT_APPLICABLE":
            domain_outputs[d]={"domain":d,"status":"NOT_APPLICABLE","score":None,"display_score":None,"coverage":0.0,"required_coverage":0.0,"scored_weight":0.0,"applicable_weight":0.0,"criterion_refs":[],"uncertainty":None,"limitations":[]}; continue
        meta=domain_meta[d]
        coverage=meta["scored_weight"]/meta["applicable_weight"] if meta["applicable_weight"]>0 else 0.0
        limitations=[]
        if meta["required_missing"]:
            status="UNSCORABLE"; score=None; limitations.append("Required criteria unresolved: "+", ".join(meta["required_missing"]))
        elif not scores_by_domain[d]:
            status="UNSCORABLE"; score=None; limitations.append("No scored criteria.")
        else:
            score=weighted_mean(scores_by_domain[d]); status="COMPLETE" if abs(coverage-1.0)<1e-12 else "PARTIAL"
            if meta["optional_unresolved"]: limitations.append("Optional criteria unresolved: "+", ".join(meta["optional_unresolved"]))
            if coverage < float(cfg["minimum_coverage"]): limitations.append("Coverage below profile minimum.")
            domain_values[d]=score
        unc=None
        if score is not None and len(interval_by_domain[d])==len(scores_by_domain[d]) and scores_by_domain[d]:
            low=weighted_mean([(w,l) for w,l,u in interval_by_domain[d]]); high=weighted_mean([(w,u) for w,l,u in interval_by_domain[d]])
            unc={"lower":low,"upper":high,"kind":"SENSITIVITY_ENVELOPE","method_ref":registry["formula_ids"]["interval_propagation"]}; domain_intervals[d]=(low,high)
        domain_outputs[d]={"domain":d,"status":status,"score":score,"display_score":round(score,profile["display_decimals"]) if score is not None else None,"coverage":coverage,"required_coverage":float(cfg["minimum_coverage"]),"scored_weight":meta["scored_weight"],"applicable_weight":meta["applicable_weight"],"criterion_refs":meta["criteria"],"uncertainty":unc,"limitations":limitations}
    sig=applicability_signature(profile,statuses)
    composite=None
    comp_reasons=[]
    if not policy["composite_allowed"]: comp_reasons.append("SCR-F12 COMPOSITE_BLOCKED_BY_SECTION3")
    if profile["lifecycle"] not in {"ACTIVE","TEST_ONLY"}: comp_reasons.append("SCR-F03 PROFILE_NOT_ACTIVE")
    required_domains=[d for d,cfg in profile["domains"].items() if cfg["applicability"]=="REQUIRED"]
    for d in required_domains:
        if domain_outputs[d]["status"]=="UNSCORABLE": comp_reasons.append(f"SCR-F09 REQUIRED_DOMAIN_UNSCORABLE:{d}")
        if domain_outputs[d]["coverage"] < domain_outputs[d]["required_coverage"]: comp_reasons.append(f"SCR-F08 DOMAIN_COVERAGE_INSUFFICIENT:{d}")
    if not comp_reasons:
        items=[(float(profile["domains"][d]["composite_weight"]),domain_values[d]) for d in required_domains]
        c=weighted_geometric(items); ar=weighted_mean(items); sens=sensitivity(profile,{d:domain_values[d] for d in required_domains})
        c_unc=None
        if all(d in domain_intervals for d in required_domains):
            low_items=[(float(profile["domains"][d]["composite_weight"]),domain_intervals[d][0]) for d in required_domains]
            high_items=[(float(profile["domains"][d]["composite_weight"]),domain_intervals[d][1]) for d in required_domains]
            c_unc={"lower":weighted_geometric(low_items),"upper":weighted_geometric(high_items),"kind":"SENSITIVITY_ENVELOPE","method_ref":registry["formula_ids"]["interval_propagation"]}
        composite={"score":c,"display_score":round(c,profile["display_decimals"]),"method_ref":registry["formula_ids"]["composite_geometric"],"arithmetic_reference":ar,"compensation_gap":ar-c,"uncertainty":c_unc,"sensitivity":sens,"limitations":["Composite is secondary to the vector.","TEST_ONLY profile; no research claim."] if profile["lifecycle"]=="TEST_ONLY" else ["Composite is secondary to the vector."]}
    else: warnings.extend(sorted(set(comp_reasons)))
    vector={"vector_id":f"score-vector:{req['run_id']}:{req['unit_id']}","run_id":req["run_id"],"unit_id":req["unit_id"],"profile_ref":f"{profile['profile_id']}@{profile['version']}","applicability_signature":sig,**domain_outputs,"C100":composite,"score_policy_ref":"section3:inline","generated_by":ENGINE_VERSION}
    comparison=req.get("comparison_request",{"requested":False,"peer_vector_refs":[],"method_ref":None})
    if not comparison["requested"]: comp_out={"status":"NOT_REQUESTED","winner":None,"reason":"No comparison requested."}
    elif not policy["ranking_allowed"]: comp_out={"status":"BLOCKED_BY_SECTION_3","winner":None,"reason":"Section 3 blocks ranking."}
    elif comparison.get("method_ref") is None: comp_out={"status":"INFERENTIAL_UNAVAILABLE","winner":None,"reason":"No calibrated comparison method registered."}
    else: comp_out={"status":"DESCRIPTIVE_ONLY","winner":None,"reason":"Reference engine does not implement inferential winner selection."}
    engine_status="SCORED" if all(domain_outputs[d]["status"] in {"COMPLETE","NOT_APPLICABLE"} for d in DOMAINS) else "PARTIAL"
    return {"engine_status":engine_status,"run_id":req["run_id"],"unit_id":req["unit_id"],"profile_ref":vector["profile_ref"],"score_vector":vector,"criterion_results":criterion_results,"warnings":warnings,"errors":[],"comparison":comp_out,"provenance":{"engine_version":ENGINE_VERSION,"registry_sha256":registry_hash,"formula_ids":list(registry["formula_ids"].values())}}


def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument("request",type=Path); p.add_argument("--registry",type=Path,required=True); p.add_argument("--schema",type=Path,required=True); p.add_argument("--out",type=Path)
    a=p.parse_args(); reg=load_yaml(a.registry); sch=load_json(a.schema); req=load_json(a.request); result=evaluate(req,reg,sch,sha256(a.registry)); text=json.dumps(result,ensure_ascii=False,indent=2)+"\n"
    if a.out: a.out.write_text(text,encoding="utf-8")
    else: print(text,end="")
    return 0 if result["engine_status"]!="REQUEST_INVALID" else 2

if __name__=="__main__": raise SystemExit(main())
