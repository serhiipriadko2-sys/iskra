---
title: "Section 5 Addendum 03 — Alpha.9 Evidence-Path Contract Closure"
version: "v3.3-alpha.9"
status: "PROPOSED / OWNER REVIEW"
parent: "05_EVIDENCE_PROVENANCE.md"
supersedes_enforcement:
  - "05_EVIDENCE_PROVENANCE_ADDENDUM_01.md"
  - "05_EVIDENCE_PROVENANCE_ADDENDUM_02.md"
created: "2026-07-18"
---

# Section 5 Addendum 03

## 1. Decision context

Alpha.8 passed its declared repair suite but an independent Owner review demonstrated that `provenance_complete=true` could still be emitted without a complete bounded, role-correct, scope-compatible and epistemically eligible path. The reported classes were A8-F47 through A8-F57.

Alpha.9 treats those findings as one graph-contract problem rather than eleven unrelated fixtures.

## 2. Canonical alpha.9 path

For ordinary score-bearing judgments:

```text
Source --CONTAINS--> bounded Content
Content --EXTRACTED_FROM--> Evidence
Evidence --OBSERVES--> Observation(status=OBSERVED)
Observation --SUPPORTS--> Claim(epistemically scorable)
Claim --SUPPORTS|APPLIES_TO--> Judgment(score_eligible=true)
Judgment --SCORES|TRIGGERS_GATE--> Result
```

Direct evidence-to-claim or evidence-to-judgment edges may provide supplemental trace, but they never authorize skipping the Observation layer.

For publication claims:

```text
exact declared Verdict --LIMITS|SUPPORTS--> Publication Claim
```

The claim must store `verdict_ref`; another verdict, study or external publication node cannot satisfy the claim's ancestry.

## 3. Method-role matrix

| Use | Required method type |
|---|---|
| Source/content containment | `VALIDATION` |
| Content/evidence collection | `COLLECTION` |
| Evidence/observation extraction | `EXTRACTION` |
| Observation/claim inference | `INFERENCE` |
| Claim/judgment support | `VALIDATION` |
| Derivation | `DERIVATION` |
| Redaction | `REDACTION` |
| Conflict resolution | `CONFLICT_RESOLUTION` |

An existing method ID with an incorrect role is invalid.

## 4. Scope and estimand policy

Alpha.9 uses conservative exact compatibility until a calibrated scope lattice is introduced:

```text
claim.scope ∈ every positive ancestor evidence.object_scope
claim.estimand_ref ∈ every positive ancestor evidence.estimand_scope
claim.estimand_ref = graph.estimand_ref
observation.observed_scope ∈ every referenced evidence.object_scope
```

Derived evidence may narrow scope but may not widen beyond declared inputs.

## 5. Epistemic eligibility

Score-bearing and supported hard-failure claims require:

- at least one `OBSERVED` observation;
- `ACTIVE` evidence ancestry;
- no material-redaction ancestor;
- no unresolved material conflict;
- scorable claim qualification/status;
- an `ACTIVE` inference method;
- deterministic inference for `FACT`;
- retained counterevidence.

Hard-failure support is never weaker than ordinary score support.

## 6. Conflict and lifecycle closure

A `RESOLVED` conflict requires a related resolution claim connected by `COUNTERS`, `REFUTES` or `CONFLICTS_WITH`, using the declared active conflict-resolution method and retaining the conflict evidence.

`SUPERSEDES` and `REVOKES` chains are acyclic across every allowed node type. Their target lifecycle state must be compatible with the relation.

## 7. Bounded fragment grammar

- `FULL`: explicit full-artifact locator only.
- `LINES`, `PAGES`, `ROWS`: positive numeric singleton/range lists, no reversed or zero ranges.
- `JSON_POINTER`: non-root pointer without wildcard.
- `TIME_RANGE`: explicit nonempty start/end.
- `OTHER`: declared typed locator, never wildcard/all-content aliases.

## 8. Canonical alpha.9 diagnostics

```text
EV-F47 BOUNDED_CONTENT_ROOT_MISSING
EV-F48 METHOD_ROLE_MISMATCH
EV-F49 SCOPE_OR_ESTIMAND_EXPANSION
EV-F50 TRANSITIVE_ZERO_TRUST_OR_NEGATIVE_EVIDENCE_BYPASS
EV-F51 HARD_FAILURE_EPISTEMIC_SUPPORT_INVALID
EV-F52 CONFLICT_RESOLUTION_UNRELATED
EV-F53 LIFECYCLE_CYCLE_ANY_NODE
EV-F54 PUBLICATION_CLAIM_WITHOUT_OWN_VERDICT_PATH
EV-F55 METHOD_EPISTEMIC_ADEQUACY
EV-F56 INVALID_FRAGMENT_LOCATOR
EV-F57 OBSERVATION_LAYER_BYPASS
```

Historical codes remain stable.

## 9. Validator authority boundary

`provenance_complete=true` proves only that the supplied graph passes implemented structural rules. It does not establish semantic truth, evidence-universe completeness, source relevance by meaning, remote-content immutability, signer authority, empirical calibration or publication validity.

## 10. Acceptance gate

Alpha.9 may be accepted only after:

1. all historical tests pass;
2. all physical invalid fixtures are rejected;
3. the contract-derived A8-F47…F57 matrix passes;
4. the dynamic mutation matrix passes;
5. Sections 0–4 remain byte-identical;
6. fresh-ZIP tests and manifest read-back pass;
7. Owner reviews the exact ZIP hash.

## ∆DΩΛ

**∆:** evidence-path validity becomes a per-claim graph property rooted in bounded content.

**D:** Owner findings → consolidated graph predicate → schema/registry/validator synchronization → adversarial fixtures.

**Ω:** 0.95 for the defined structural contract; semantic completeness remains unclaimed.

**Λ:** revisit after exact Owner mutation corpus and future Section 7 poisoning/omission tests.
