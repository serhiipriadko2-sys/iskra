---
title: Section 5 Evidence Enforcement Repair Decision
record_id: IJP-DR-20260717-05
version: v3.3-alpha.7
status: PROPOSED / OWNER REVIEW
scope: Section 5 evidence and provenance enforcement
---

# Decision Record — Section 5 alpha.7 repair

## Context

The Section 5 Owner review accepted the ontology and archive integrity but withheld acceptance after 11 adversarial mutations were accepted by the alpha.6 validator. The load-bearing issue was enforcement incompleteness, not the conceptual evidence model.

## Decision

Adopt the alpha.7 enforcement model defined in `05_EVIDENCE_PROVENANCE_ADDENDUM_01.md`:

1. preserve alpha.6 as an immutable proposed checkpoint;
2. reject unsafe local references rather than treating them as remote;
3. require declared references and typed edges to agree;
4. enforce active evidence lifecycle transitively;
5. require verdict ancestry for publication;
6. enforce global record ID uniqueness;
7. require conflict-resolution and derivation closure;
8. require qualified hard-failure support and concrete propagation destinations;
9. keep semantic truth, score computation and winner selection outside the validator.

## Alternatives considered

### A. Patch only the 11 fixtures

Rejected. It would overfit known examples without establishing reusable invariants.

### B. Remove reference arrays and rely only on edges

Deferred. It would simplify consistency but break the current package contract and reduce human readability.

### C. Remove graph edges and rely only on arrays

Rejected. It would make path, ancestry and cycle validation materially weaker.

### D. Keep alpha.6 and document limitations

Rejected for acceptance. The gaps affect load-bearing provenance and publication boundaries.

## Consequences

### Benefits

- mutation bypasses become deterministic failures;
- `provenance_complete` is tied to actual path checks;
- hard failures cannot be invented or orphaned;
- publication claims require verdict ancestry;
- duplicate records cannot silently overwrite indexes.

### Costs

- alpha.6 evidence graphs require migration;
- schema and validator are stricter;
- more edges must be explicitly recorded;
- Section 6 canonical work remains blocked until Owner acceptance.

## Tests / QA

Required:

- full project pytest;
- 11 mutation fixtures with `EV-F26…EV-F34`;
- Python compile;
- JSON/YAML parse;
- manifest hash verification;
- alpha.6 ZIP hash re-check;
- Sections 0–4 preservation check;
- ZIP integrity and external sidecar receipt.

## Diff scope

```text
05_EVIDENCE_PROVENANCE.schema.json
05_EVIDENCE_PROVENANCE_REGISTRY.yaml
tools/validate_evidence_graph.py
tests/test_evidence_provenance.py
fixtures/section5/**
05_EVIDENCE_PROVENANCE_ADDENDUM_01.md
05_SECTION_5_DECISION_RECORD.md
alpha.7 manifest / receipts / reports
```

## Rollback

Rollback target is the immutable alpha.6 ZIP:

```text
sha256=b20a3af023694c5072747af7801a82f30c9515e16e4de8d4f6f22c5c49f8f7c2
```

Rollback restores proposed Section 5 status and keeps canonical Section 6 blocked.

## Lifecycle

```yaml
alpha6: PROPOSED_CHECKPOINT_IMMUTABLE
alpha7: PROPOSED_OWNER_REVIEW
section5_owner_acceptance: PENDING
section6_exploratory_draft: ALLOWED
section6_canonical_commit: BLOCKED
```

## ∆DΩΛ

**∆:** executable enforcement is repaired without rewriting the historical alpha.6 checkpoint.

**D:** Owner audit → invariant-level patch → schema/validator/tests → new checkpoint.

**Ω:** 0.95 for the repair design.

**Λ:** accept or revise after independent alpha.7 mutation rerun.
