---
title: Independent Judge Protocol v3.3 — Section 5 Enforcement Addendum 01
version: v3.3-alpha.7
section: 5
status: PROPOSED / OWNER REVIEW
doc_type: enforcement_addendum
source_checkpoint: v3.3-alpha.6
source_zip_sha256: b20a3af023694c5072747af7801a82f30c9515e16e4de8d4f6f22c5c49f8f7c2
---

# Section 5 Enforcement Addendum 01

## 0. Scope

This addendum hardens the executable enforcement of `05_EVIDENCE_PROVENANCE.md` after the Owner mutation audit. It does not replace the evidence ontology. It closes the gap:

```text
written contract
!=
executable enforcement
```

The alpha.6 ZIP remains an immutable proposed checkpoint. Alpha.7 is a successor candidate.

## 1. Accepted findings for repair

| Finding | Severity | Alpha.7 decision |
|---|---:|---|
| F5-01 lifecycle bypass | HIGH | enforce lifecycle across the transitive evidence-to-claim-to-judgment path |
| F5-02 declared refs without edges | HIGH | require typed edge consistency for declared refs |
| F5-03 orphan study publication | HIGH | publication ancestry must begin at a verdict |
| F5-04 unsupported/orphan hard failure | HIGH | require qualified support and concrete destination path |
| F5-05 unsafe local path | MEDIUM-HIGH | distinguish remote refs from invalid local refs |
| F5-06 duplicate/resolution/derivation gaps | MEDIUM | enforce global IDs and closure rules |

## 2. New invariants

### INV-5A — Content reference classification

Every content reference is classified as exactly one of:

```text
LOCAL_REF
REMOTE_REF
INVALID_LOCAL_REF
```

`INVALID_LOCAL_REF` is rejected. It cannot be treated as remote merely because local validation failed.

### INV-5B — Declared-reference and edge agreement

For score-bearing provenance, declared references and graph edges are two representations of one relationship. They must agree.

Required mappings include:

```text
observation.evidence_refs
  => EVIDENCE --OBSERVES|EXTRACTED_FROM--> OBSERVATION

claim.observation_refs
  => OBSERVATION --SUPPORTS|PARTIALLY_SUPPORTS|REFUTES--> CLAIM

claim.supporting_evidence_refs
  => EVIDENCE --SUPPORTS|PARTIALLY_SUPPORTS--> CLAIM

judgment.claim_refs
  => CLAIM --SUPPORTS|PARTIALLY_SUPPORTS|APPLIES_TO|LIMITS--> JUDGMENT

judgment.evidence_refs
  => EVIDENCE --SUPPORTS|PARTIALLY_SUPPORTS--> JUDGMENT
```

Missing typed edges invalidate the graph.

### INV-5C — Transitive lifecycle closure

For every score-eligible judgment:

1. each referenced claim must have an actual typed path to the judgment;
2. each load-bearing claim must have active evidence ancestry;
3. direct judgment evidence must intersect the active ancestry of the claim;
4. any `REVOKED`, `EXPIRED`, `CORRUPTED`, `SUPERSEDED`, `CONFLICTED`, `ARCHIVED`, `COLLECTED` or `QUALIFIED` load-bearing ancestor blocks scoring.

An unrelated active decoy cannot cleanse inactive ancestry.

### INV-5D — Publication verdict ancestry

A publication node is eligible only when there is a directed allowed path beginning at a `VERDICT` node:

```text
VERDICT
→ optional RUN / MODEL_CONDITION / STUDY
→ PUBLICATION
```

A `STUDY` node alone is not sufficient.

### INV-5E — Global record identity

IDs are unique across node and non-node records:

```text
source content evidence observation claim judgment external-node
method edge conflict derivation redaction failure propagation
```

No in-memory index may silently overwrite a duplicate record.

### INV-5F — Conflict resolution closure

`RESOLVED` requires:

- an existing active `CONFLICT_RESOLUTION` method;
- an existing non-conflicted resolution claim;
- retained conflict evidence.

A dangling resolution reference is invalid.

### INV-5G — Derivation closure

A derivation requires exact agreement among:

```text
declared input_evidence_refs
DERIVED_FROM edges
output evidence lineage
method_ref
```

The output evidence must be a `DERIVED_TRANSFORM`.

### INV-5H — Hard-failure support and propagation

A `SUPPORTED` hard failure requires:

- canonical Section 3 gate/failure reference;
- canonical Section 3 effect;
- affected unit and scope;
- at least one load-bearing qualified claim;
- at least one active evidence object connected to the claim;
- concrete propagation record when higher aggregation layers exist.

Alpha.7 adds:

```typescript
interface HardFailureEvidenceLinkV5_1 extends HardFailureEvidenceLinkV5 {
  affected_unit_ref: string;
  scope: string;
}

interface HardFailurePropagationV5_1 extends HardFailurePropagationV5 {
  propagation_id: string;
  destination_ref: string;
}
```

The destination must exist and match `destination_level`. For study/publication propagation, the failure claims must have a real graph path to the destination.

## 3. Canonical alpha.7 errors

```text
EV-F26 UNSAFE_CONTENT_REF
EV-F27 INACTIVE_TRANSITIVE_SUPPORT
EV-F28 DECLARED_REF_WITHOUT_EDGE
EV-F29 PUBLICATION_WITHOUT_VERDICT_ANCESTRY
EV-F30 DUPLICATE_RECORD_ID
EV-F31 INVALID_CONFLICT_RESOLUTION
EV-F32 DERIVATION_EDGE_MISSING
EV-F33 HARD_FAILURE_WITHOUT_QUALIFIED_SUPPORT
EV-F34 ORPHAN_HARD_FAILURE_PROPAGATION
```

Existing error codes remain valid for backward diagnostic compatibility.

## 4. Validator boundary

The validator may determine only structural eligibility. It still returns:

```yaml
truth_determined: false
scores_emitted: false
winner_selected: false
```

It does not infer semantic truth, resolve substantive conflicts or compute a score.

## 5. Acceptance gate

Alpha.7 may be accepted only if:

- original regression suite passes;
- all 11 Owner mutation fixtures are invalid;
- each mutation emits its canonical alpha.7 code;
- invalid graphs report `provenance_complete=false`;
- alpha.6 ZIP hash remains unchanged;
- Sections 0–4 remain byte-identical;
- decision record, manifest, receipt and external ZIP sidecar are present.

## 6. Migration

Alpha.6 graphs using hard-failure propagation must add:

```yaml
hard_failure_link:
  affected_unit_ref: <unit_id>
  scope: <declared scope>

hard_failure_propagation:
  propagation_id: <unique id>
  destination_ref: <run or external node id>
```

Graphs must also add typed evidence-to-claim and evidence-to-judgment edges where the corresponding reference arrays are populated.

## ∆DΩΛ

**∆:** provenance completeness becomes a proved path property rather than a no-error alias.

**D:** mutation findings → schema additions → deterministic validator repair → regression fixtures.

**Ω:** 0.95 for structural enforcement; semantic truth remains outside validator authority.

**Λ:** Owner acceptance after independent rerun of alpha.7 ZIP and all adversarial fixtures.
