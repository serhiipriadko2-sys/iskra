from __future__ import annotations

import copy
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(
    "validate_evidence_graph", ROOT / "tools" / "validate_evidence_graph.py"
)
mod = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(mod)
SCHEMA = mod.load_json(ROOT / "05_EVIDENCE_PROVENANCE.schema.json")
REGISTRY = mod.load_yaml(ROOT / "05_EVIDENCE_PROVENANCE_REGISTRY.yaml")


def run_valid():
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    return mod.validate(mod.load_json(path), SCHEMA, REGISTRY, path.parent)


def run_invalid(name: str):
    path = ROOT / "fixtures" / "section5" / "invalid" / name / "graph.json"
    return mod.validate(mod.load_json(path), SCHEMA, REGISTRY, path.parent)


def assert_code(result, code: str):
    assert result["status"] == "INVALID"
    assert any(error.startswith(code + " ") for error in result["errors"]), result["errors"]


def test_valid_graph_passes_without_truth_or_scores():
    result = run_valid()
    assert result["status"] == "VALID"
    assert result["provenance_complete"] is True
    assert result["truth_determined"] is False
    assert result["scores_emitted"] is False
    assert result["winner_selected"] is False


def test_direct_source_to_claim_rejected():
    assert_code(run_invalid("direct_source_to_claim"), "EV-F01")


def test_content_hash_mismatch_rejected():
    assert_code(run_invalid("hash_mismatch"), "EV-F06")


def test_inactive_evidence_cannot_support_score():
    assert_code(run_invalid("inactive_evidence_used"), "EV-F07")


def test_conflicted_claim_cannot_be_score_eligible():
    assert_code(run_invalid("conflicted_score_eligible"), "EV-F10")


def test_external_document_does_not_prove_local_runtime():
    assert_code(run_invalid("external_to_local_scope"), "EV-F14")


def test_embedded_instruction_cannot_elevate_authority():
    assert_code(run_invalid("authority_injection"), "EV-F19")


def test_supported_hard_failure_requires_propagation():
    assert_code(run_invalid("hard_failure_propagation_missing"), "EV-F18")


def test_negative_evidence_cannot_support_broad_claim():
    assert_code(run_invalid("negative_overgeneralized"), "EV-F24")


def test_counterevidence_cannot_be_dropped():
    assert_code(run_invalid("counterevidence_dropped"), "EV-F21")


def test_publication_requires_verdict_path():
    assert_code(run_invalid("publication_no_path"), "EV-F23")


def test_support_cycle_rejected():
    assert_code(run_invalid("support_cycle"), "EV-F05")


def test_independence_overclaim_rejected():
    assert_code(run_invalid("independence_overclaimed"), "EV-F22")


def test_claim_ceiling_is_enforced():
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    graph = mod.load_json(path)
    graph["claims"][0]["claim_level"] = "L4"
    graph["claims"][0]["claim_ceiling"] = "L4"
    result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
    assert_code(result, "EV-F08")


def test_hard_failure_propagation_preserves_failure():
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    graph = mod.load_json(path)
    graph["hard_failure_links"] = [{
        "failure_id": "HF-1",
        "gate_ref": "AGY-001",
        "claim_refs": ["C-PASS"],
        "evidence_refs": ["E-TEST"],
        "counterevidence_refs": [],
        "affected_unit_ref": "UNIT-1",
        "scope": "unit:UNIT-1",
        "load_bearing": True,
        "severity_basis": "Test-only fixture.",
        "effect_ref": "HARD_FAIL_OBJECT",
        "status": "SUPPORTED",
    }]
    graph["hard_failure_propagation"] = [{
        "propagation_id": "HFP-1",
        "source_failure_ref": "HF-1",
        "source_level": "UNIT",
        "destination_level": "STUDY",
        "destination_ref": "STUDY-1",
        "propagation_policy_ref": "EV-LAW-12",
        "retained_as_failure": True,
        "converted_to_numeric_penalty": False,
        "converted_to_missing": False,
        "averaged_away": False,
        "publication_disclosure_required": True,
    }]
    result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
    assert result["status"] == "VALID"
    assert result["hard_failures_preserved"] == ["HF-1"]


def test_output_contract_never_contains_score_or_winner_value():
    result = run_valid()
    assert result["scores_emitted"] is False
    assert result["winner_selected"] is False
    forbidden = {"Q100", "S100", "A100", "R100", "G100", "C100", "winner"}
    assert forbidden.isdisjoint(result.keys())


def test_confirmatory_rejects_calibrating_method():
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    graph = mod.load_json(path)
    graph["mode"] = "CONFIRMATORY"
    graph["methods"][0]["validation_status"] = "CALIBRATING"
    result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
    assert_code(result, "EV-F13")


def test_graph_validation_is_deterministic():
    a = run_valid()
    b = run_valid()
    assert a == b

ALPHA7_CASES = {
    "unsafe_relative_path": "EV-F26",
    "revoked_claim_support_active_judgment_decoy": "EV-F27",
    "missing_observation_claim_judgment_edges": "EV-F28",
    "publication_study_without_verdict_ancestry": "EV-F29",
    "publication_from_orphan_study": "EV-F29",
    "duplicate_edge_id": "EV-F30",
    "duplicate_method_id": "EV-F30",
    "resolved_conflict_dangling_resolution": "EV-F31",
    "derivation_without_incoming_edge": "EV-F32",
    "unsupported_empty_hard_failure": "EV-F33",
    "orphan_hard_failure_propagation": "EV-F34",
}


def test_alpha7_adversarial_mutations_are_rejected():
    for name, code in ALPHA7_CASES.items():
        result = run_invalid(name)
        assert_code(result, code)
        assert result["provenance_complete"] is False


def test_alpha7_all_record_identifiers_are_unique():
    for name in ("duplicate_edge_id", "duplicate_method_id"):
        result = run_invalid(name)
        assert_code(result, "EV-F30")


def test_alpha7_publication_requires_verdict_ancestry_not_orphan_study():
    for name in (
        "publication_study_without_verdict_ancestry",
        "publication_from_orphan_study",
    ):
        assert_code(run_invalid(name), "EV-F29")


def test_alpha7_transitive_inactive_support_rejected_even_with_active_decoy():
    result = run_invalid("revoked_claim_support_active_judgment_decoy")
    assert_code(result, "EV-F27")


def test_alpha7_validator_version_and_boundary():
    result = run_valid()
    assert result["validator_version"] == "IJP-EVIDENCE-VALIDATOR-v3.3-alpha.9"
    assert result["truth_determined"] is False
    assert result["scores_emitted"] is False
    assert result["winner_selected"] is False


ALPHA8_CASES = {
    "file_uri_absolute_is_invalid": "EV-F35",
    "revoked_derivation_input_blocks_active_output_score": "EV-F36",
    "conflicted_observation_blocks_supported_fact_score": "EV-F37",
    "unknown_only_claim_blocks_score_eligibility": "EV-F38",
    "transitive_material_redaction_blocks_score_despite_decoy": "EV-F39",
}


def test_alpha8_extended_mutations_are_rejected():
    for name, code in ALPHA8_CASES.items():
        result = run_invalid(name)
        assert_code(result, code)
        assert result["provenance_complete"] is False


def test_alpha8_file_uri_is_not_remote():
    result = run_invalid("file_uri_absolute_is_invalid")
    assert_code(result, "EV-F35")


def test_alpha8_derivation_ancestry_propagates_lifecycle():
    result = run_invalid("revoked_derivation_input_blocks_active_output_score")
    assert_code(result, "EV-F36")


def test_alpha8_observation_state_blocks_score():
    result = run_invalid("conflicted_observation_blocks_supported_fact_score")
    assert_code(result, "EV-F37")


def test_alpha8_unknown_only_claim_is_nonscorable():
    result = run_invalid("unknown_only_claim_blocks_score_eligibility")
    assert_code(result, "EV-F38")


def test_alpha8_material_redaction_is_transitive():
    result = run_invalid("transitive_material_redaction_blocks_score_despite_decoy")
    assert_code(result, "EV-F39")


ALPHA8_SELF_AUDIT_CASES = {
    "active_failed_trust_dimension": "EV-F40",
    "active_hash_mismatch_content": "EV-F41",
    "orphan_derivation_edge_without_record": "EV-F42",
    "redacted_content_without_record": "EV-F43",
    "edge_evidence_reference_missing": "EV-F44",
}


def test_alpha8_self_audit_hardening_cases_are_rejected():
    for name, code in ALPHA8_SELF_AUDIT_CASES.items():
        result = run_invalid(name)
        assert_code(result, code)
        assert result["provenance_complete"] is False


def test_alpha8_lifecycle_edges_match_status_and_are_acyclic():
    assert_code(run_invalid("lifecycle_edge_status_mismatch"), "EV-F45")


def test_alpha8_derivation_method_version_matches_registry_method():
    assert_code(run_invalid("derivation_method_version_mismatch"), "EV-F46")

ALPHA8_NEIGHBOR_CASES = {
    "double_encoded_traversal_is_invalid": "EV-F26",
    "unsupported_uri_scheme_is_invalid": "EV-F35",
    "partial_only_observation_blocks_load_bearing_score": "EV-F37",
    "refuted_only_claim_blocks_score": "EV-F38",
    "lifecycle_edge_cycle": "EV-F45",
}


def test_alpha8_neighbor_mutations_are_rejected():
    for name, code in ALPHA8_NEIGHBOR_CASES.items():
        result = run_invalid(name)
        assert_code(result, code)
        assert result["provenance_complete"] is False


def test_alpha8_explicit_remote_scheme_allowlist():
    import copy
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    base = mod.load_json(path)
    for ref in (
        "https://example.test/evidence",
        "s3://bucket/evidence",
        "gs://bucket/evidence",
        "ipfs://cid/path",
        "ftp://example.test/evidence",
        "urn:example:evidence",
    ):
        graph = copy.deepcopy(base)
        graph["contents"][0]["content_ref"] = ref
        result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
        assert result["status"] in {"VALID", "VALID_WITH_LIMITATIONS"}, (ref, result)
        assert not any(error.startswith("EV-F35 ") for error in result["errors"]), (ref, result)
    for ref in (
        "file:///etc/passwd",
        "smb://host/share/file",
        "nfs://host/export/file",
        "data:text/plain,secret",
        "javascript:alert(1)",
        "gopher://example.test/item",
        "//host/share/file",
        "C:/Windows/System32/drivers/etc/hosts",
        "%2e%2e/outside.txt",
        "%252e%252e/outside.txt",
    ):
        graph = copy.deepcopy(base)
        graph["contents"][0]["content_ref"] = ref
        result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
        assert result["status"] == "INVALID", (ref, result)
        if "%" in ref:
            assert any(error.startswith("EV-F26 ") for error in result["errors"]), (ref, result)
        else:
            assert any(error.startswith("EV-F35 ") for error in result["errors"]), (ref, result)


def test_alpha8_observation_status_matrix():
    import copy
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    base = mod.load_json(path)
    for state in ("CONFLICTED", "UNSCORABLE", "NOT_OBSERVED", "PARTIAL"):
        graph = copy.deepcopy(base)
        graph["observations"][0]["status"] = state
        result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
        assert_code(result, "EV-F37")


def test_alpha8_nonscorable_claim_matrix():
    import copy
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    base = mod.load_json(path)
    cases = (
        ("UNKNOWN", "NOT_EVALUATED"),
        ("REFUTED", "REFUTED"),
        ("HYPOTHESIS", "INSUFFICIENT_EVIDENCE"),
        ("CONFLICTED", "CONFLICTED"),
    )
    for qualification, support_status in cases:
        graph = copy.deepcopy(base)
        graph["claims"][0]["qualification"] = qualification
        graph["claims"][0]["support_status"] = support_status
        graph["claims"][0]["load_bearing"] = False
        result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
        assert_code(result, "EV-F38")


def test_alpha8_deep_percent_encoding_cannot_escape_root():
    import copy
    from urllib.parse import quote
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    base = mod.load_json(path)
    value = "../outside.txt"
    for _ in range(12):
        value = quote(value, safe="")
    graph = copy.deepcopy(base)
    graph["contents"][0]["content_ref"] = value
    result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
    assert_code(result, "EV-F26")

ALPHA9_REQUIRED_CASES = {
    "evidence_without_bounded_content": "EV-F47",
    "source_content_edge_missing": "EV-F47",
    "content_evidence_edge_missing": "EV-F47",
    "collection_method_wrong_type": "EV-F48",
    "extraction_method_wrong_type": "EV-F48",
    "inference_method_wrong_type": "EV-F48",
    "judgment_method_wrong_type": "EV-F48",
    "edge_method_wrong_type": "EV-F48",
    "claim_scope_expansion": "EV-F49",
    "claim_estimand_mismatch": "EV-F49",
    "observation_scope_expansion": "EV-F49",
    "derived_scope_expansion": "EV-F49",
    "derived_estimand_expansion": "EV-F49",
    "untrusted_governance_via_observation": "EV-F50",
    "negative_evidence_via_observation_global": "EV-F50",
    "hard_failure_conflicted_observation": "EV-F51",
    "hard_failure_partial_observation": "EV-F51",
    "hard_failure_material_redaction": "EV-F51",
    "hard_failure_counterevidence_dropped": "EV-F51",
    "conflict_resolution_unrelated_claim": "EV-F52",
    "claim_lifecycle_cycle": "EV-F53",
    "internal_publication_claim_without_verdict_path": "EV-F54",
    "fact_nondeterministic_inference_method": "EV-F55",
    "fact_calibrating_method_without_limitations": "EV-F55",
    "fragment_lines_all_lines": "EV-F56",
    "fragment_pages_all": "EV-F56",
    "fragment_json_pointer_wildcard": "EV-F56",
}


def test_alpha9_owner_contract_mutations_are_rejected():
    for name, code in ALPHA9_REQUIRED_CASES.items():
        result = run_invalid(name)
        assert_code(result, code)
        assert result["provenance_complete"] is False


def test_alpha9_confirmatory_variants_are_rejected():
    cases = {
        "confirmatory_nondeterministic_fact_method": "EV-F55",
        "confirmatory_calibrating_score_method": "EV-F13",
        "confirmatory_indirect_evidence": "EV-F40",
    }
    for name, code in cases.items():
        assert_code(run_invalid(name), code)


def test_alpha9_each_method_role_is_enforced():
    for name in (
        "collection_method_wrong_type",
        "extraction_method_wrong_type",
        "inference_method_wrong_type",
        "judgment_method_wrong_type",
        "edge_method_wrong_type",
    ):
        assert_code(run_invalid(name), "EV-F48")


def test_alpha9_scope_and_estimand_are_monotone():
    for name in (
        "claim_scope_expansion",
        "claim_estimand_mismatch",
        "observation_scope_expansion",
        "derived_scope_expansion",
        "derived_estimand_expansion",
    ):
        assert_code(run_invalid(name), "EV-F49")


def test_alpha9_hard_failure_support_is_not_weaker_than_score_support():
    for name in (
        "hard_failure_conflicted_observation",
        "hard_failure_partial_observation",
        "hard_failure_material_redaction",
        "hard_failure_counterevidence_dropped",
    ):
        assert_code(run_invalid(name), "EV-F51")


def test_alpha9_valid_publication_claim_can_bind_to_specific_verdict():
    path = ROOT / "fixtures" / "section5" / "valid" / "graph.json"
    graph = mod.load_json(path)
    graph["claims"][0]["claim_type"] = "PUBLICATION"
    graph["claims"][0]["verdict_ref"] = "VERDICT-1"
    graph["edges"].append({
        "edge_id": "A9-VERDICT-PUBLICATION-CLAIM",
        "from_ref": "VERDICT-1",
        "to_ref": "C-PASS",
        "relation_type": "LIMITS",
        "method_ref": "M-JUDGE",
        "created_by": "ALPHA9-TEST",
        "created_at": "2026-07-18T22:00:00Z",
        "evidence_refs": [],
        "limitations": [],
        "reversible": True,
    })
    result = mod.validate(graph, SCHEMA, REGISTRY, path.parent)
    assert result["status"] == "VALID", result


def test_alpha9_protocol_versions_are_synchronized():
    assert SCHEMA["properties"]["protocol_version"]["const"] == "v3.3-alpha.9"
    assert REGISTRY["version"] == "v3.3-alpha.9"
    assert REGISTRY["registry_id"].endswith("v3.3-alpha.9")
    assert run_valid()["validator_version"] == "IJP-EVIDENCE-VALIDATOR-v3.3-alpha.9"
    base = (ROOT / "05_EVIDENCE_PROVENANCE.md").read_text(encoding="utf-8")
    assert 'version: "v3.3-alpha.9"' in base

ALPHA9_SELF_AUDIT_CASES = {
    "derived_transform_without_derivation": "EV-F47",
    "scope_decoy_mismatch": "EV-F49",
    "observation_scope_decoy": "EV-F49",
    "direct_score_path_without_observation": "EV-F57",
    "untrusted_plus_trusted_decoy": "EV-F50",
    "hard_failure_hypothesis_support": "EV-F51",
    "conflict_resolution_generic_support_only": "EV-F52",
    "publication_claim_wrong_declared_verdict": "EV-F54",
    "fragment_reversed_range": "EV-F56",
    "fragment_lines_zero": "EV-F56",
    "score_claim_calibrating_inference": "EV-F55",
}


def test_alpha9_self_audit_neighboring_mutations_are_rejected():
    for name, code in ALPHA9_SELF_AUDIT_CASES.items():
        result = run_invalid(name)
        assert_code(result, code)
        assert result["provenance_complete"] is False
