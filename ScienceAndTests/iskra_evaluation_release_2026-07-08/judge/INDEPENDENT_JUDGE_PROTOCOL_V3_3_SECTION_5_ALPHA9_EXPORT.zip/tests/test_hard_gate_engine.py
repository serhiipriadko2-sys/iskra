from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures" / "section3"

spec = importlib.util.spec_from_file_location("hard_gate_engine", ROOT / "tools" / "evaluate_hard_gates.py")
engine = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(engine)

REGISTRY = yaml.safe_load((ROOT / "03_HARD_GATES_REGISTRY.yaml").read_text(encoding="utf-8"))
SCHEMA = json.loads((ROOT / "03_HARD_GATES.schema.json").read_text(encoding="utf-8"))


def run(name: str):
    request = json.loads((FIXTURES / f"{name}.json").read_text(encoding="utf-8"))
    return engine.evaluate(request, REGISTRY, SCHEMA)


def test_all_pass_proceeds_without_winner():
    report = run("valid_all_pass")
    assert report["primary_disposition"] == "PROCEED"
    assert report["eligibility"] == "ELIGIBLE"
    assert report["winner"] is None
    assert report["score_policy"]["composite_allowed"] is True


def test_package_integrity_failure_rejects_and_erases_scores():
    report = run("package_invalid")
    assert report["primary_disposition"] == "REJECTED_PACKAGE"
    assert report["eligibility"] == "INVALID_PACKAGE"
    assert report["scores"] is None
    assert report["comparison_allowed"] is False


def test_load_bearing_falsehood_is_hard_fail_not_low_score():
    report = run("load_bearing_falsehood")
    assert report["primary_disposition"] == "HARD_FAIL_OBJECT"
    assert report["eligibility"] == "HARD_FAIL"
    assert report["scores"]["Q100"] == 92
    assert report["scores"]["C100"] is None
    assert report["score_policy"]["ranking_allowed"] is False


def test_required_criterion_not_active_is_unscorable():
    report = run("criterion_lifecycle_unscorable")
    assert report["primary_disposition"] == "UNSCORABLE"
    assert report["scores"] is None


def test_capture_failure_cannot_be_compensated():
    report = run("capture_failure")
    assert report["primary_disposition"] == "HARD_FAIL_OBJECT"
    assert any(f["family"] == "AGENCY_AND_CAPTURE" for f in report["failures"])
    assert report["publication_allowed"] is False


def test_judge_injection_success_invalidates_run():
    report = run("judge_injection_success")
    assert report["primary_disposition"] == "INVALIDATED_RUN"
    assert report["scores"] is None


def test_comparability_failure_preserves_pointwise_but_blocks_ranking():
    report = run("comparison_blocked")
    assert report["primary_disposition"] == "POINTWISE_ONLY"
    assert report["eligibility"] == "ELIGIBLE_WITH_LIMITATIONS"
    assert report["scores"] is not None
    assert report["comparison_allowed"] is False
    assert report["comparison_verdict"] == "INCOMPARABLE"


def test_claim_ceiling_is_computed_and_blocks_publication_only():
    report = run("claim_ceiling_exceeded")
    assert report["primary_disposition"] == "PROCEED_WITH_LIMITATIONS"
    assert report["eligibility"] == "ELIGIBLE_WITH_LIMITATIONS"
    assert report["publication_allowed"] is False
    assert report["scores"] is not None
    assert any(f["failure_code"] == "PUB-001" for f in report["failures"])


def test_missing_high_stakes_escalation_route_requires_human_escalation():
    report = run("high_stakes_missing_escalation")
    assert report["primary_disposition"] == "HUMAN_ESCALATION_REQUIRED"
    assert "REQUIRED_GATE_NOT_RUN:HG-HUM-001" in report["validation_issues"]


def test_missing_evidence_downgrades_pass_to_unknown():
    report = run("missing_required_evidence")
    truth_gate = next(g for g in report["gate_results"] if g["gate_id"] == "HG-TRU-001")
    assert truth_gate["status"] == "UNKNOWN"
    assert "MISSING_REQUIRED_EVIDENCE" in truth_gate["issues"]
    assert report["score_policy"]["composite_allowed"] is False


def test_engine_never_emits_winner():
    for fixture in FIXTURES.glob("*.json"):
        request = json.loads(fixture.read_text(encoding="utf-8"))
        report = engine.evaluate(request, REGISTRY, SCHEMA)
        assert report["winner"] is None
