import importlib.util
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    'ijp_validator', ROOT / 'tools' / 'validate_evaluation_package.py'
)
validator = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(validator)


class EvaluationPackageValidatorTests(unittest.TestCase):
    def test_minimal_valid_package(self):
        report = validator.validate(
            ROOT / 'examples' / '02_MINIMAL_VALID_PACKAGE' / 'evaluation-package.json'
        )
        self.assertEqual(report['schema_status'], 'PASS')
        self.assertEqual(report['semantic_status'], 'PASS')
        self.assertEqual(report['errors'], [])

    def test_invalid_fixtures_emit_expected_code(self):
        fixture_root = ROOT / 'fixtures' / 'invalid'
        cases = sorted(fixture_root.glob('*/evaluation-package.json'))
        self.assertGreaterEqual(len(cases), 5)
        for case in cases:
            with self.subTest(case=case.parent.name):
                expected = json.loads(case.read_text(encoding='utf-8'))[
                    '_expected_failure_code'
                ]
                report = validator.validate(case)
                codes = {item['code'] for item in report['errors']}
                self.assertEqual(report['semantic_status'], 'FAIL')
                self.assertIn(expected, codes)

    def test_validator_does_not_emit_scores(self):
        report = validator.validate(
            ROOT / 'examples' / '02_MINIMAL_VALID_PACKAGE' / 'evaluation-package.json'
        )
        forbidden = {'score', 'winner', 'Q100', 'S100', 'A100', 'R100', 'G100'}
        self.assertTrue(forbidden.isdisjoint(report.keys()))


if __name__ == '__main__':
    unittest.main()
