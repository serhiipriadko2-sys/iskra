from __future__ import annotations
import importlib.util, json, math
from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("compute_scores",ROOT/"tools"/"compute_scores.py")
mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod)
REG=mod.load_yaml(ROOT/"04_SCORING_REGISTRY.yaml")
SCH=mod.load_json(ROOT/"04_SCORING.schema.json")
RH=mod.sha256(ROOT/"04_SCORING_REGISTRY.yaml")

def run(name):
    return mod.evaluate(mod.load_json(ROOT/"fixtures"/"section4"/f"{name}.json"),REG,SCH,RH)

def test_valid_full_vector_and_composite():
    r=run("valid_full")
    assert r["engine_status"]=="SCORED"
    assert r["score_vector"]["C100"] is not None
    assert r["comparison"]["winner"] is None
    assert r["score_vector"]["Q100"]["score"]==92.5

def test_non_linear_ordinal_mapping():
    r=run("valid_full")
    q=next(x for x in r["criterion_results"] if x["criterion_id"]=="Q-CORRECT")
    s=next(x for x in r["criterion_results"] if x["criterion_id"]=="S-HOLD")
    assert q["points_0_100"]==100
    assert s["points_0_100"]==75

def test_section3_blocked_no_scores():
    r=run("section3_blocked")
    assert r["engine_status"]=="UNSCORABLE"
    assert r["score_vector"] is None

def test_required_unknown_domain_unscorable_and_no_composite():
    r=run("required_unknown")
    assert r["score_vector"]["A100"]["status"]=="UNSCORABLE"
    assert r["score_vector"]["C100"] is None
    assert any("REQUIRED_DOMAIN_UNSCORABLE:A100" in x for x in r["warnings"])

def test_not_applicable_excluded_from_denominator():
    r=run("not_applicable_excluded")
    assert r["score_vector"]["S100"]["coverage"]==1.0
    assert r["score_vector"]["S100"]["score"]==75

def test_optional_unknown_is_not_zero():
    r=run("optional_unknown")
    assert r["score_vector"]["Q100"]["status"]=="PARTIAL"
    assert 0 < r["score_vector"]["Q100"]["coverage"] < 1
    assert r["score_vector"]["Q100"]["score"]>0

def test_zero_required_domain_zeroes_geometric_composite():
    r=run("zero_domain")
    assert r["score_vector"]["G100"]["score"]==0.0
    assert r["score_vector"]["C100"]["score"]==0.0
    assert mod.weighted_geometric([(1,0)])==0

def test_composite_blocked_by_section3():
    r=run("composite_blocked")
    assert r["score_vector"]["C100"] is None
    assert any("COMPOSITE_BLOCKED_BY_SECTION3" in x for x in r["warnings"])

def test_profile_lifecycle():
    assert run("calibrating_confirmatory")["engine_status"]=="UNSCORABLE"
    assert run("test_profile_outside_test")["engine_status"]=="UNSCORABLE"

def test_confidence_does_not_change_score():
    req=mod.load_json(ROOT/"fixtures"/"section4"/"valid_full.json")
    r1=mod.evaluate(req,REG,SCH,RH)
    for c in req["criteria"]: c["confidence"]=0.01
    r2=mod.evaluate(req,REG,SCH,RH)
    assert r1["score_vector"]["C100"]["score"]==r2["score_vector"]["C100"]["score"]
    assert all(x["confidence_used_in_score"] is False for x in r2["criterion_results"])

def test_comparison_never_selects_winner_without_calibrated_method():
    r=run("comparison_no_method")
    assert r["comparison"]["winner"] is None
    assert r["comparison"]["status"]=="INFERENTIAL_UNAVAILABLE"

def test_interval_propagation_is_labeled_not_confidence():
    r=run("interval_partial")
    assert r["score_vector"]["Q100"]["uncertainty"]["kind"]=="SENSITIVITY_ENVELOPE"
    assert r["score_vector"]["C100"]["uncertainty"] is None

def test_sensitivity_is_deterministic():
    r1=run("valid_full"); r2=run("valid_full")
    assert r1["score_vector"]["C100"]["sensitivity"]==r2["score_vector"]["C100"]["sensitivity"]

def test_formula_reference():
    expected=100*math.exp(0.5*math.log(.8)+0.5*math.log(.5))
    assert abs(mod.weighted_geometric([(0.5,80),(0.5,50)])-expected)<1e-12
