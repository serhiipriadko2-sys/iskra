---
title: "Section 5 alpha.8 Evidence Closure Repair Decision"
record_id: "IJP-DR-20260718-05A8"
version: "v3.3-alpha.8"
status: "PROPOSED / OWNER REVIEW"
scope: "Section 5 validator, schema, registry, fixtures and packaging"
created: "2026-07-18"
---

# Decision Record - Section 5 alpha.8 repair

## Context

The independent Owner review verified alpha.7 packaging and the declared repair suite but withheld acceptance after five novel mutations were accepted. The common defect was incomplete propagation of eligibility through URI classification, derivation ancestry, observation state, claim state and redaction ancestry.

## Decision

Adopt the alpha.8 enforcement model in `05_EVIDENCE_PROVENANCE_ADDENDUM_02.md` as a repair candidate:

1. use an explicit remote-scheme allowlist and reject local-capable or unsupported URI schemes;
2. include `DERIVED_FROM` in transitive lifecycle ancestry;
3. require ACTIVE derivation inputs for ACTIVE derived evidence used in scoring;
4. propagate observation eligibility into claims and judgments;
5. reject score-bearing judgments whose support is epistemically nonscorable;
6. enforce material redaction across full evidence ancestry;
7. enforce ACTIVE-evidence trust and content-integrity consistency;
8. require complete derivation, redaction, edge-evidence and lifecycle records;
9. preserve the validator boundary: no semantic truth, scores or winner;
10. preserve alpha.6 and alpha.7 as immutable historical checkpoints.

## Alternatives considered

### A. Add five fixture-specific conditions

Rejected. The alpha.7 review demonstrated that known-case closure is not invariant closure.

### B. Treat all URI schemes as remote

Rejected. `file:` and other local-capable schemes can access or describe local resources and must not bypass root/path controls.

### C. Trust ACTIVE derived outputs without input lifecycle checks

Rejected. Derivation cannot erase revoked, expired or corrupted ancestry.

### D. Leave observation/claim eligibility to the scoring engine

Rejected. Section 5 owns the right-to-assert provenance boundary. Section 4 must not receive a score-eligible judgment whose evidence semantics are already invalid.

### E. Accept alpha.7 with limitations

Rejected for canonical acceptance. The residual findings directly contradict the `provenance_complete` claim.

## Consequences

### Benefits

- transitive support includes derivation ancestry;
- score eligibility respects observation and claim states;
- material redaction cannot be hidden by a direct decoy;
- local URI and encoded path bypasses are rejected;
- active evidence cannot contradict its trust/content state;
- lifecycle and derivation histories are structurally coherent.

### Costs

- some previously accepted exploratory graphs become invalid;
- remote references remain structurally validated but not fetched;
- more explicit methods, edges and records are required;
- validator complexity increases and requires continued mutation testing;
- Section 6 canonical dependency remains blocked pending Owner acceptance.

## External standards alignment

The repair is compatible with:

- RFC 8089, which treats `file:` as a file-system URI with material security implications;
- RFC 3986, which requires careful URI component and percent-decoding security handling;
- W3C PROV, which models entities, activities, derivation and validation constraints;
- SLSA/in-toto provenance practices that bind artifacts to inputs, methods and digests.

These standards inform design; they do not prove this implementation correct.

## Tests and QA

Required:

- complete pytest suite;
- original invalid fixtures;
- 11 alpha.6 mutation fixtures;
- 5 alpha.7 residual fixtures;
- self-audit hardening fixtures;
- URI and epistemic-state mutation matrices;
- Python compile;
- JSON/YAML parse;
- manifest and ZIP integrity;
- alpha.6/alpha.7 hash preservation;
- Sections 0-4 byte preservation;
- no caches or symlinks.

## Diff scope

```text
05_EVIDENCE_PROVENANCE.schema.json
05_EVIDENCE_PROVENANCE_REGISTRY.yaml
05_EVIDENCE_PROVENANCE_ADDENDUM_02.md
05_SECTION_5_ALPHA8_DECISION_RECORD.md
05_SECTION_5_ALPHA8_REPAIR_REPORT.md
tools/validate_evidence_graph.py
tests/test_evidence_provenance.py
fixtures/section5/**
review/SECTION5_ALPHA7_OWNER_REVIEW_AUDIT.md
review/SECTION5_ALPHA8_REQUIRED_PATCH.yaml
alpha.8 manifest, receipts, matrices and audit
```

## Rollback

Rollback target is the immutable alpha.7 archive:

```text
sha256=466843467ab81141c63c530dfd45c8d7068f83b98ae0b688efba36427e7fa429
```

Rollback restores `PROPOSED_CHECKPOINT_WITH_RESIDUAL_FINDINGS`; it does not grant Section 5 acceptance.

## Lifecycle

```yaml
alpha6: PROPOSED_CHECKPOINT_IMMUTABLE
alpha7: PROPOSED_CHECKPOINT_WITH_RESIDUAL_FINDINGS
alpha8: PROPOSED_OWNER_REVIEW
section5_owner_acceptance: PENDING
section6_exploratory_draft: ALLOWED
section6_canonical_commit: BLOCKED
```

## Delta D Omega Lambda

Delta: The repair target is the general evidence-eligibility closure, not the five observed examples alone.

D: independent audit -> invariant extraction -> implementation -> mutation testing -> checkpoint.

Omega: 0.95 for the proposed decision shape.

Lambda: Owner acceptance only after independent archive and novel mutation verification.
