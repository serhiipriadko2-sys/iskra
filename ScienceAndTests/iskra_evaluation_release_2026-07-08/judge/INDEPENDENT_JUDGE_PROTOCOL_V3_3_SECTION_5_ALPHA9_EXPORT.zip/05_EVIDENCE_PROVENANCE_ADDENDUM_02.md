---
title: "Independent Judge Protocol v3.3 - Section 5 Enforcement Addendum 02"
version: "v3.3-alpha.8"
section: 5
status: "PROPOSED / OWNER REVIEW"
doc_type: "evidence_provenance_enforcement_addendum"
supersedes_enforcement: "05_EVIDENCE_PROVENANCE_ADDENDUM_01.md"
source_audit: "review/SECTION5_ALPHA7_OWNER_REVIEW_AUDIT.md"
source_patch: "review/SECTION5_ALPHA8_REQUIRED_PATCH.yaml"
created: "2026-07-18"
---

# Section 5 Enforcement Addendum 02 - alpha.8

## 1. Purpose

This addendum repairs the residual gap between the Section 5 evidence ontology and the executable validator. It does not change the ontology's central chain:

```text
Source -> Content -> Evidence -> Observation -> Claim -> Judgment -> Result -> Verdict
```

It strengthens the condition under which the validator may emit `provenance_complete=true`.

## 2. Governing invariant

For every score-bearing judgment, there must exist at least one complete, typed, currently eligible path from bounded content and ACTIVE evidence through an eligible observation and an epistemically scorable claim to the judgment. Every load-bearing ancestor on that path must remain eligible. A direct active decoy cannot sanitize an ineligible transitive ancestor.

```text
eligible content
-> ACTIVE evidence
-> eligible observation
-> scorable claim
-> score-bearing judgment
```

Derived evidence adds an additional ancestry obligation:

```text
eligible input evidence
-> DERIVED_FROM + DerivationRecord + ACTIVE method/version
-> ACTIVE derived evidence
-> observation -> claim -> judgment
```

## 3. URI and path classification

Remote references are recognized only by an explicit allowlist. Local-capable or unsupported schemes are rejected.

Allowed remote schemes in alpha.8:

```text
http https ftp s3 gs ipfs urn
```

Rejected classes include:

```text
file smb nfs data javascript unknown schemes
UNC/protocol-relative references
absolute POSIX paths
Windows drive paths
root escape via ..
percent-encoded traversal or local URI syntax
NUL-containing references
```

Canonical failure:

```text
EV-F35 UNSAFE_LOCAL_URI
```

The validator does not fetch remote content. A remote reference marked `VERIFIED` receives an explicit limitation warning because local hash reproduction did not occur in this validator run.

## 4. Derivation-aware lifecycle closure

`DERIVED_FROM` participates in transitive support ancestry. An ACTIVE derived evidence object cannot be score-bearing if any declared load-bearing input is not ACTIVE.

Canonical failures:

```text
EV-F36 INACTIVE_DERIVATION_ANCESTOR
EV-F42 ORPHAN_DERIVATION_EDGE
EV-F46 METHOD_VERSION_MISMATCH
```

The following equality is required:

```text
DerivationRecord.input_evidence_refs
= DERIVED_FROM input edges
= declared output lineage
```

## 5. Observation and claim eligibility propagation

A score-bearing judgment cannot bypass the epistemic state of its ancestors.

Blocking observation states:

```text
CONFLICTED
UNSCORABLE
NOT_OBSERVED
```

`PARTIAL` blocks a load-bearing claim and also blocks a judgment when no fully `OBSERVED` support remains.

Canonical failure:

```text
EV-F37 OBSERVATION_STATUS_NOT_PROPAGATED
```

Epistemically nonscorable claim states include:

```text
qualification: UNKNOWN | REFUTED | CONFLICTED
support_status: INSUFFICIENT_EVIDENCE | NOT_EVALUATED | REFUTED | CONFLICTED
```

A judgment is not score eligible when all supporting claims are nonscorable, or when any load-bearing supporting claim is nonscorable.

Canonical failure:

```text
EV-F38 NONSCORABLE_CLAIM_FEEDS_SCORE
```

## 6. Transitive material redaction

Material redaction is evaluated over the full evidence ancestry of each score-bearing claim and judgment, not only over direct `judgment.evidence_refs`.

Canonical failure:

```text
EV-F39 TRANSITIVE_MATERIAL_REDACTION
```

A decoy ACTIVE evidence object cannot hide a material-redacted ancestor.

## 7. Additional self-audit hardening

The alpha.8 repair loop found additional contract gaps not listed in the Owner patch. They are included because they are load-bearing for the same provenance-completeness claim.

```text
EV-F40 INELIGIBLE_ACTIVE_EVIDENCE
EV-F41 CONTENT_INTEGRITY_INCONSISTENT
EV-F42 ORPHAN_DERIVATION_EDGE
EV-F43 REDACTED_CONTENT_WITHOUT_RECORD
EV-F44 EDGE_EVIDENCE_MISSING
EV-F45 LIFECYCLE_EDGE_INCONSISTENT
EV-F46 METHOD_VERSION_MISMATCH
```

### EV-F40

An evidence object cannot remain ACTIVE while a mandatory trust dimension is explicitly failed, irrelevant, expired, methodologically failed, or insufficient for the claim. Confirmatory use applies stricter dimension requirements.

### EV-F41

ACTIVE evidence cannot rely on content whose integrity state is `HASH_MISMATCH` or `UNAVAILABLE`. Evidence-level integrity cannot contradict content-level integrity.

### EV-F42

Every evidence-to-evidence `DERIVED_FROM` edge requires a matching DerivationRecord.

### EV-F43

Every content artifact with `integrity_status=REDACTED` requires a RedactionRecord.

### EV-F44

Every `edge.evidence_refs` entry must resolve to a real evidence object.

### EV-F45

`SUPERSEDES` and `REVOKES` edges must agree with the target lifecycle state and cannot form cycles.

### EV-F46

A derivation record's `method_version` must match the referenced method record.

## 8. Provenance-complete semantics

`provenance_complete=true` means only that the machine-checkable structural and eligibility invariants implemented in this validator passed for the supplied graph. It does not mean:

- semantic truth was established;
- relevance was inferred from free text;
- an external URI was fetched;
- a human judgment was correct;
- a score or winner was computed;
- empirical validity or publication readiness was established.

The report must continue to state:

```yaml
truth_determined: false
scores_emitted: false
winner_selected: false
```

## 9. Acceptance gate

Alpha.8 is eligible for Owner review only if:

1. the alpha.7 ZIP hash remains unchanged;
2. Sections 0-4 remain byte-identical;
3. all original tests pass;
4. all 23 prior invalid fixtures remain rejected;
5. all 11 alpha.6 bypass fixtures remain rejected;
6. all 5 alpha.7 residual mutations are rejected by EV-F35..EV-F39;
7. all self-audit hardening fixtures are rejected by EV-F40..EV-F46;
8. the valid fixture remains VALID with `provenance_complete=true`;
9. JSON/YAML parsing, Python compilation, manifest verification and ZIP integrity pass;
10. no cache artifacts or symlinks enter the export.

## 10. Governance status

```yaml
alpha6: PROPOSED_CHECKPOINT_IMMUTABLE
alpha7: PROPOSED_CHECKPOINT_WITH_RESIDUAL_FINDINGS
alpha8: PROPOSED_OWNER_REVIEW
section5_owner_acceptance: PENDING
section6_exploratory_draft: ALLOWED
section6_canonical_commit: BLOCKED
```

## Delta D Omega Lambda

Delta: Alpha.8 replaces fixture-specific closure with a typed ancestry and eligibility invariant.

D: Owner mutation findings -> graph closure repair -> self-audit -> expanded tests -> proposed checkpoint.

Omega: 0.95 for structural repair; semantic and empirical validity are not claimed.

Lambda: independent Owner rerun of the final alpha.8 archive and novel mutation pass.
