---
title: "Section 5 alpha.8 Validator Repair Report"
version: "v3.3-alpha.8"
status: "PROPOSED / OWNER REVIEW"
source_audit: "review/SECTION5_ALPHA7_OWNER_REVIEW_AUDIT.md"
source_patch: "review/SECTION5_ALPHA8_REQUIRED_PATCH.yaml"
created: "2026-07-18"
---

# Section 5 alpha.8 repair report

## Verdict

```yaml
section_5_alpha8:
  ontology: PRESERVED
  owner_findings_repaired: PASS_CANDIDATE
  self_audit_hardening: PASS_CANDIDATE
  original_regression_suite: PASS
  known_alpha6_mutations: PASS
  alpha7_residual_mutations: PASS
  neighboring_mutations: PASS
  alpha6_checkpoint_preserved: PASS
  alpha7_checkpoint_preserved: PASS
  sections_0_4_preserved: PASS
  owner_acceptance: PENDING
  canonical_section_6_transition: BLOCKED
```

## Owner findings

| Finding | Canonical repair | Regression evidence |
|---|---|---|
| A7-F01 | explicit remote allowlist; local-capable and unsupported schemes rejected | `file_uri_absolute_is_invalid` -> `EV-F35` |
| A7-F02 | `DERIVED_FROM` added to lifecycle ancestry; active derived output requires active inputs | revoked input -> `EV-F36` |
| A7-F03 | observation state propagates into judgment eligibility | conflicted observation -> `EV-F37` |
| A7-F04 | UNKNOWN/REFUTED/insufficient claims cannot be sole score support | unknown-only claim -> `EV-F38` |
| A7-F05 | material redaction evaluated over transitive evidence ancestry | redaction plus decoy -> `EV-F39` |

## Self-discovered repairs

A second and third contract-to-code pass found additional violations that shared the same right-to-assert boundary:

| Code | Repair |
|---|---|
| EV-F40 | ACTIVE evidence rejects explicitly failed/irrelevant/expired/insufficient trust dimensions |
| EV-F41 | ACTIVE evidence cannot contradict content integrity state |
| EV-F42 | every evidence derivation edge requires a DerivationRecord |
| EV-F43 | REDACTED content requires a RedactionRecord |
| EV-F44 | edge evidence references must resolve |
| EV-F45 | lifecycle edges must match target status and remain acyclic |
| EV-F46 | derivation method version must match the method registry |

## URI mutation matrix

Allowed structural remote schemes:

```text
http https ftp s3 gs ipfs urn
```

Rejected:

```text
file smb nfs data javascript gopher/unknown
UNC/protocol-relative
POSIX absolute
Windows drive
single, double and deeply percent-encoded traversal
```

The validator does not fetch allowed remote references. A separate collector and digest receipt are required for semantic or confirmatory use.

## Executable results

```yaml
pytest: PASS
tests: 65 passed
subtests: 5 passed
valid_fixture:
  status: VALID
  provenance_complete: true
invalid_fixtures:
  total: 40
  rejected: 40
known_alpha6_bypasses:
  total: 11
  rejected_with_expected_code: 11
owner_alpha7_residual_mutations:
  total: 5
  rejected_with_expected_code: 5
self_audit_physical_mutations:
  total: 7
  rejected_with_expected_code: 7
neighboring_physical_mutations:
  total: 5
  rejected: 5
python_compile: PASS
```

The suite now tests both physical fixtures and dynamic matrices for URI schemes, nested percent encoding, observation states and nonscorable claim states.

## Validator authority boundary

The alpha.8 validator still does not:

- infer observations from free text;
- decide semantic truth or relevance;
- fetch remote content;
- resolve substantive conflict;
- compute Q/S/A/R/G or C100;
- select a winner;
- establish inter-rater reliability;
- claim publication or production validity.

Its report retains:

```yaml
truth_determined: false
scores_emitted: false
winner_selected: false
```

## Repository and live boundaries

```yaml
github:
  alpha8_in_repository: false
  writes: 0
supabase:
  evaluation_schema_observed: false
  writes: 0
implementation_maturity:
  local_artifact: true
  merged: false
  deployed: false
  invoked_live: false
  verified_live: false
```

## Checkpoint preservation

```yaml
alpha6_zip:
  bytes: 241899
  sha256: b20a3af023694c5072747af7801a82f30c9515e16e4de8d4f6f22c5c49f8f7c2
  unchanged: true
alpha7_zip:
  bytes: 300210
  sha256: 466843467ab81141c63c530dfd45c8d7068f83b98ae0b688efba36427e7fa429
  unchanged: true
sections_0_4:
  byte_preservation: PASS
```

## Residual limits

1. Real-world evidence completeness cannot be proven from a declared graph alone.
2. Remote content collection and digest reproduction remain external operations.
3. Semantic relevance and entailment remain judge/human-method responsibilities.
4. Unicode confusable IDs and resource-exhaustion limits need Section 7 hardening.
5. Cryptographic attestations and append-only storage enforcement remain Sections 8-9 dependencies.
6. Reliability, adjudication and disagreement remain Section 6 dependencies.
7. Empirical calibration and generalization remain Section 10 dependencies.

## Governance

```yaml
alpha6: PROPOSED_CHECKPOINT_IMMUTABLE
alpha7: PROPOSED_CHECKPOINT_WITH_RESIDUAL_FINDINGS
alpha8: PROPOSED_OWNER_REVIEW
section5_owner_acceptance: PENDING
section6_exploratory_draft: ALLOWED
section6_canonical_commit: BLOCKED
```

## Delta D Omega Lambda

Delta: Alpha.8 enforces a reusable provenance-eligibility closure instead of only rejecting known fixtures.

D: Owner audit -> graph invariant -> schema/registry/validator -> physical and dynamic mutations -> packaging.

Omega: 0.95 for structural and executable readiness; semantic and empirical validity are not claimed.

Lambda: independent Owner verification of the final archive and a fresh neighboring-mutation pass.
