---
title: "Independent Judge Protocol v3.3 — Complete Evaluation Ontology"
project_version: "v3.3-alpha.2"
section: "1"
section_version: "v1.0-alpha.1"
status: "PROPOSED / OWNER REVIEW"
doc_type: "evaluation_ontology"
depends_on:
  - "00_COMPLETE_SYSTEM_CHARTER.md"
  - "00_SECTION_0_ACCEPTANCE_RECORD.md"
created: "2026-07-17"
owner: "Семён"
architecture_principle: "Define what exists before defining how it is scored"
---

# 1. Complete Evaluation Ontology

## 1.0 Назначение

Этот документ определяет полный словарь сущностей, состояний, отношений и границ Independent Judge Protocol v3.3.

Он отвечает на вопрос:

> **Что именно существует в evaluation-системе, чем эти объекты отличаются и какие отношения между ними допустимы?**

Section 1 не задаёт окончательные веса, tie bands, reliability thresholds или composite formula. Эти элементы принадлежат последующим разделам и не могут молча переопределить онтологию.

```text
Section 0: what is permitted
Section 1: what exists
Section 2: how it is represented
Section 3: what blocks evaluation
Section 4: how eligible observations become scores
```

---

# 1.1 Онтологические принципы

## OP-01 · Separation of kinds

Следующие объекты не взаимозаменяемы:

```text
Object != Response
Task != Contract
Source != Evidence
Evidence != Claim
Claim != Fact
Observation != Interpretation
Score != Verdict
Confidence != Correctness
Hard Failure != Low Score
Unknown != Zero
Not Applicable != Unknown
Benchmark Result != General Capability
Judge Reliability != Object Quality
Evaluation != Remediation
```

## OP-02 · Every important object is typed

Каждая сущность имеет:

```yaml
id:
type:
version:
status:
created_at:
provenance:
```

## OP-03 · Every relation has semantics

Связь должна иметь имя, направление, cardinality и failure semantics.

Недопустимо хранить произвольные `links[]`, если от них зависит verdict.

## OP-04 · Primary vector, secondary scalar

Первичными являются criterion results и domain vector.

Composite является производным объектом и не получает права скрывать профиль.

## OP-05 · Explicit missingness

Отсутствие наблюдения типизируется до scoring.

## OP-06 · Locality of claims

Любой вывод относится к конкретному estimand, unit, population, task family, time window и harness.

## OP-07 · Versioned meaning

Изменение определения сущности создаёт новую ontology version. Старый run не интерпретируется задним числом по новой семантике.

---

# 1.2 Верхнеуровневые миры онтологии

Система разделена на семь пространств.

```text
O — Object World
D — Design World
P — Package and Provenance World
E — Evidence and Epistemic World
J — Judgment World
R — Reliability World
G — Governance World
```

## 1.2.1 Object World

Содержит оцениваемые системы, их outputs и контекст исполнения.

## 1.2.2 Design World

Содержит study, estimand, task, contract, rubric, criterion и benchmark design.

## 1.2.3 Package and Provenance World

Содержит immutable evaluation package, manifests, versions, hashes и identity mapping.

## 1.2.4 Evidence and Epistemic World

Содержит observations, claims, sources, evidence items, methods, conflicts и temporal validity.

## 1.2.5 Judgment World

Содержит criterion results, failures, scores, comparisons, adjudications и verdicts.

## 1.2.6 Reliability World

Содержит judge profiles, calibration, repeatability, inter-rater agreement, drift и adversarial robustness.

## 1.2.7 Governance World

Содержит policy, ADR, authorization, audit events, supersession и publication claims.

Жёсткая граница:

```text
Object World cannot mutate Judgment World.
Judgment World cannot mutate Object World during a run.
Governance World controls protocol versions, not individual desired outcomes.
```

---

# 1.3 Core entity catalogue

## 1.3.1 EvaluatedObject

Объект, о котором делается evaluation claim.

```typescript
interface EvaluatedObject {
  object_id: string;
  object_type: EvaluatedObjectType;
  name: string;
  version: string | null;
  provider: string | null;
  organization: string | null;
  artifact_refs: string[];
  authority_boundary_ref: string;
  mutable_during_run: false;
}
```

```typescript
type EvaluatedObjectType =
  | 'AI_MODEL'
  | 'AI_SYSTEM'
  | 'AGENT'
  | 'SYSTEM_HARNESS'
  | 'SOFTWARE_COMPONENT'
  | 'HUMAN_AI_INTERACTION_SYSTEM'
  | 'RESEARCH_ARTIFACT'
  | 'EVALUATION_PIPELINE'
  | 'HUMAN_PRODUCED_OUTPUT'
  | 'OTHER_DECLARED';
```

## 1.3.2 EvaluationUnit

Конкретная единица, непосредственно подвергаемая оценке.

```typescript
type EvaluationUnitType =
  | 'RESPONSE'
  | 'DIALOGUE'
  | 'AGENT_RUN'
  | 'ARTIFACT'
  | 'COMPONENT'
  | 'SYSTEM_HARNESS'
  | 'MODEL_FAMILY'
  | 'HUMAN_AI_INTERACTION'
  | 'RESEARCH_CLAIM'
  | 'EVALUATION_PIPELINE';
```

Инвариант:

```text
one EvaluationUnit -> one declared primary estimand
```

Дополнительные estimands допустимы только как secondary и не заменяют primary после чтения результатов.

## 1.3.3 Study

Контейнер исследовательского дизайна.

```typescript
interface EvaluationStudy {
  study_id: string;
  title: string;
  objective: string;
  primary_estimand_id: string;
  secondary_estimand_ids: string[];
  protocol_version: string;
  ontology_version: string;
  population_definition: string;
  inclusion_rules: string[];
  exclusion_rules: string[];
  preregistration_ref: string | null;
  status: StudyStatus;
}
```

## 1.3.4 EvaluationRun

Один исполнимый проход протокола над frozen package.

```typescript
interface EvaluationRun {
  run_id: string;
  study_id: string;
  package_id: string;
  judge_instance_ids: string[];
  protocol_version: string;
  rubric_version: string;
  ontology_version: string;
  started_at: string;
  committed_at: string | null;
  state: EvaluationState;
  independence_level: IndependenceLevel;
}
```

Один run не может менять package version после `CONTRACT_FROZEN`.

## 1.3.5 Task

Входная задача до интерпретации судьи.

```typescript
interface Task {
  task_id: string;
  prompt_text_ref: string;
  context_refs: string[];
  domain_tags: string[];
  risk_class: RiskClass;
  temporal_scope: string | null;
  language: string;
}
```

## 1.3.6 TaskContract

Замороженная операционализация требований задачи.

```typescript
interface TaskContract {
  contract_id: string;
  task_id: string;
  primary_goal: string;
  atoms: ContractAtom[];
  forbidden_behaviors: string[];
  required_boundaries: string[];
  evidence_requirements: string[];
  revision_policy: string;
  frozen_before_candidate_read: boolean;
}
```

```typescript
interface ContractAtom {
  atom_id: string;
  description: string;
  obligation: 'REQUIRED' | 'CONDITIONAL' | 'OPTIONAL';
  applicability_rule: string;
  verification_method: string;
  omission_severity: 'MINOR' | 'MATERIAL' | 'CRITICAL';
}
```

## 1.3.7 CandidateOutput

Результат объекта, рассматриваемый как untrusted data.

```typescript
interface CandidateOutput {
  output_id: string;
  object_id: string;
  unit_id: string;
  content_ref: string;
  content_sha256: string;
  produced_at: string | null;
  generation_metadata_ref: string | null;
  contains_untrusted_instructions: boolean | null;
}
```

CandidateOutput не является evidence собственной корректности.

## 1.3.8 EvaluationPackage

Immutable bundle, достаточный для воспроизведения run.

```typescript
interface EvaluationPackage {
  package_id: string;
  package_version: string;
  manifest_ref: string;
  task_refs: string[];
  contract_refs: string[];
  output_refs: string[];
  evidence_refs: string[];
  metadata_refs: string[];
  package_sha256: string;
  frozen_at: string;
  integrity_status: PackageIntegrityStatus;
}
```

## 1.3.9 Estimand

То, что исследование намерено оценить.

```typescript
interface Estimand {
  estimand_id: string;
  construct: string;
  unit_of_analysis: EvaluationUnitType;
  population: string;
  intervention_or_condition: string | null;
  comparator: string | null;
  outcome_definition: string;
  aggregation_scope: string;
  time_horizon: string | null;
  claim_ceiling: ClaimScope;
}
```

### Estimand levels

```text
L0 — local output property
L1 — item-level task performance
L2 — task-family performance
L3 — benchmark-local system performance
L4 — harness-level capability
L5 — model-family generalized capability
L6 — human outcome / user benefit
L7 — societal or organizational impact
```

Запрещённый перенос:

```text
L1 evidence -> L5 claim without external-validity evidence
L3 benchmark score -> L6 human benefit without outcome study
```

## 1.3.10 Criterion

Одно измеряемое требование.

```typescript
interface Criterion {
  criterion_id: string;
  name: string;
  primary_domain: EvaluationDomain;
  secondary_tags: string[];
  construct_definition: string;
  applicability_rule: string;
  evidence_requirement: string;
  observation_method: string;
  scale_ref: string | null;
  hard_gate_relation: string | null;
}
```

Инварианты:

- один criterion имеет ровно один `primary_domain`;
- criterion может иметь secondary tags, но не двойной вес;
- criterion не является hard gate;
- criterion должен иметь negative anchor и positive anchor до confirmatory use.

## 1.3.11 Domain

```typescript
type EvaluationDomain =
  | 'Q100_QUALITY_TRUTH'
  | 'S100_SPACE'
  | 'A100_AGENCY'
  | 'R100_RELIABILITY'
  | 'G100_GOVERNANCE';
```

## 1.3.12 Observation

Зафиксированное восприятие или результат процедуры до интерпретации.

```typescript
interface Observation {
  observation_id: string;
  subject_ref: string;
  method_ref: string;
  observed_value: unknown;
  observed_at: string;
  observer_ref: string;
  reproducibility_status: ReproducibilityStatus;
  limitations: string[];
}
```

Пример:

```text
Observation: response contains no rollback test.
Interpretation: contract atom ROLLBACK_TEST is unmet.
Verdict effect: contract fidelity decreases or critical omission triggers cap.
```

## 1.3.13 Claim

Проверяемое высказывание.

```typescript
interface Claim {
  claim_id: string;
  text: string;
  epistemic_type: EpistemicType;
  claim_scope: ClaimScope;
  temporal_scope: string | null;
  depends_on_claim_ids: string[];
  evidence_links: EvidenceLink[];
  status: ClaimStatus;
}
```

## 1.3.14 Source

Контейнер, из которого может быть извлечено evidence.

```typescript
interface Source {
  source_id: string;
  source_type: SourceType;
  title: string | null;
  creator: string | null;
  created_at: string | null;
  retrieved_at: string;
  integrity_hash: string | null;
  authority_scope: string;
  conflicts_of_interest: string[];
}
```

Source сам по себе не является evidence, пока не указаны fragment, claim fit и method.

## 1.3.15 EvidenceItem

Типизированное основание для конкретного claim или criterion result.

```typescript
interface EvidenceItem {
  evidence_id: string;
  source_id: string | null;
  evidence_type: EvidenceType;
  fragment_ref: string | null;
  observation_ref: string | null;
  method_ref: string;
  supports_claim_ids: string[];
  contradicts_claim_ids: string[];
  qualification: EvidenceQualification;
  lifecycle_status: EvidenceLifecycleStatus;
  verified_at: string;
  valid_until: string | null;
  revalidation_trigger: string | null;
}
```

## 1.3.16 Method

Процедура получения observation или score.

```typescript
interface Method {
  method_id: string;
  name: string;
  version: string;
  inputs: string[];
  steps_ref: string;
  outputs: string[];
  assumptions: string[];
  failure_modes: string[];
  validation_refs: string[];
}
```

## 1.3.17 CriterionResult

Результат применения criterion к unit.

```typescript
interface CriterionResult {
  result_id: string;
  criterion_id: string;
  unit_id: string;
  judge_id: string;
  status: CriterionResultStatus;
  score: number | null;
  scale_ref: string | null;
  observation_refs: string[];
  evidence_refs: string[];
  reason: string;
  confidence: number | null;
  confidence_method: string | null;
  limitations: string[];
}
```

## 1.3.18 HardGateResult

```typescript
interface HardGateResult {
  gate_result_id: string;
  gate_id: string;
  unit_id: string;
  status: HardGateStatus;
  evidence_refs: string[];
  failure_code: HardFailureCode | null;
  reason: string;
  blocks_scoring: boolean;
  blocks_comparison: boolean;
  requires_human_escalation: boolean;
}
```

## 1.3.19 ScoreVector

```typescript
interface ScoreVector {
  vector_id: string;
  unit_id: string;
  Q100: DomainScore;
  S100: DomainScore;
  A100: DomainScore;
  R100: DomainScore;
  G100: DomainScore;
  composite: CompositeScore | null;
}
```

## 1.3.20 Verdict

Committed judgment envelope.

```typescript
interface Verdict {
  verdict_id: string;
  run_id: string;
  unit_id: string;
  eligibility: EligibilityStatus;
  hard_gate_refs: string[];
  score_vector_ref: string | null;
  comparison_verdict: ComparisonVerdict | null;
  validity_class: ValidityClass;
  evidence_refs: string[];
  limitations: string[];
  committed_at: string;
  supersedes: string | null;
  revalidation_trigger: string;
}
```

## 1.3.21 Judge

```typescript
interface JudgeIdentity {
  judge_id: string;
  judge_type: 'HUMAN' | 'AI' | 'HYBRID_PANEL' | 'DETERMINISTIC_CHECKER';
  model_or_person_version: string;
  organization: string | null;
  prompt_or_manual_ref: string;
  independence_profile_ref: string;
  conflicts_of_interest: string[];
}
```

## 1.3.22 JudgeReliabilityProfile

```typescript
interface JudgeReliabilityProfile {
  profile_id: string;
  judge_id: string;
  calibration_set_ref: string;
  repeatability_status: ReliabilityStatus;
  inter_rater_status: ReliabilityStatus;
  drift_status: ReliabilityStatus;
  position_bias_status: ReliabilityStatus;
  style_bias_status: ReliabilityStatus;
  adversarial_robustness_status: ReliabilityStatus;
  evidence_refs: string[];
}
```

## 1.3.23 Adjudication

Отдельный процесс разрешения material disagreement.

```typescript
interface Adjudication {
  adjudication_id: string;
  input_judgment_refs: string[];
  adjudicator_ids: string[];
  disagreement_type: DisagreementStatus;
  resolution: string;
  evidence_added_refs: string[];
  output_verdict_ref: string;
}
```

Adjudication не перезаписывает первичные judgments.

## 1.3.24 Remediation

```typescript
interface Remediation {
  remediation_id: string;
  source_verdict_id: string;
  target_object_id: string;
  proposed_changes: string[];
  authorization_ref: string;
  started_after_verdict_commit: boolean;
  creates_new_evaluation_run: boolean;
}
```

---

# 1.4 Evaluation domains

## 1.4.1 Q100 — Quality / Truth

Q100 измеряет свойства output относительно task contract и evidence.

Поддомены:

```text
Q1 Contract fidelity
Q2 Factual correctness
Q3 Technical correctness
Q4 Logical entailment
Q5 Completeness
Q6 Epistemic calibration
Q7 Temporal validity
Q8 Non-fabrication
```

Q100 не измеряет эмоциональную привлекательность.

### Q-boundary

- factual error относится к Q;
- instability across reruns относится к R;
- permission violation относится к G или hard gate;
- отсутствие человеческого шага может относиться к S/A, если задача этого требует.

## 1.4.2 S100 — Space

S100 измеряет качество условий взаимодействия.

Поддомены:

```text
S1 Attention integrity
S2 Holding without pressure
S3 Difference without humiliation
S4 Rhythm and temperature fit
S5 Permission to pause or not know
S6 Repair after rupture
S7 Clear exit from ambiguity
```

S100 не измеряет время чтения, количество сообщений или возвращаемость.

### S-boundary

Высокая эмоциональная интенсивность не является высоким S.

`Holding without exit` может снизить S и одновременно вызвать A/hard failure.

## 1.4.3 A100 — Agency

A100 измеряет сохранение субъектности пользователя.

Поддомены:

```text
A1 Real choice
A2 Consent
A3 Reversibility
A4 Correction and disagreement rights
A5 Non-exclusivity
A6 Off-system executability
A7 Exit without punishment
A8 No identity appropriation
```

### A-boundary

- ощущение поддержки относится к S;
- возможность действовать и выйти относится к A;
- манипулятивная зависимость может вызвать `CAPTURE_OR_DEPENDENCY_FAILURE`.

## 1.4.4 R100 — Reliability

R100 измеряет устойчивость свойства при повторении и изменении условий.

Поддомены:

```text
R1 Reproducibility
R2 Repeatability
R3 Robustness to input mutation
R4 One-fact ablation stability
R5 Counter-case discrimination
R6 Failure handling
R7 Limitations transparency
R8 Temporal revalidation behavior
```

### R-boundary

Один корректный ответ не доказывает высокий R.

Если repeated runs отсутствуют, R может быть `UNKNOWN`, а не `0`.

## 1.4.5 G100 — Governance

G100 измеряет соответствие системы authority, policy и change-control контрактам.

Поддомены:

```text
G1 Authorization
G2 Policy compliance
G3 Auditability
G4 Data governance and minimization
G5 Change control
G6 Version traceability
G7 Separation of duties
G8 Publication claim restraint
```

### G-boundary

Для одиночного factual response G100 может быть `NOT_APPLICABLE` или иметь узкую применимость.

Для agent run, deployment system и research artifact G100 часто обязателен.

---

# 1.5 Applicability ontology

```typescript
type ApplicabilityStatus =
  | 'APPLICABLE_REQUIRED'
  | 'APPLICABLE_OPTIONAL'
  | 'NOT_APPLICABLE'
  | 'APPLICABILITY_UNKNOWN'
  | 'APPLICABILITY_CONFLICTED';
```

## 1.5.1 Rules

1. Applicability определяется до scoring.
2. `NOT_APPLICABLE` исключается из denominator.
3. `APPLICABILITY_UNKNOWN` не исключается молча и блокирует composite, если domain обязателен.
4. `APPLICABILITY_CONFLICTED` требует adjudication.
5. Судья не делает domain applicable только потому, что candidate особенно хорош или слаб в нём.

## 1.5.2 Default domain map

| Evaluation unit | Q | S | A | R | G |
|---|---|---|---|---|---|
| Closed factual response | required | optional/lite | optional | unknown unless repeated | narrow/optional |
| Engineering answer | required | optional/lite | optional | required when tests exist | conditional |
| Human-support response | required | required | required | conditional | conditional/high-stakes |
| Agent run | required | conditional | conditional | required | required |
| Research artifact | required | optional | optional | required | required |
| Evaluation pipeline | required | optional | optional | required | required |
| Human–AI interaction system | required | required | required | required | required |

Эта таблица является default, а не окончательной rubric policy.

---

# 1.6 Epistemic ontology

## 1.6.1 Epistemic types

```typescript
type EpistemicType =
  | 'FACT'
  | 'INTERPRETATION'
  | 'HYPOTHESIS'
  | 'UNKNOWN';
```

## 1.6.2 Claim status

```typescript
type ClaimStatus =
  | 'ASSERTED'
  | 'SUPPORTED'
  | 'CORROBORATED'
  | 'CONTRADICTED'
  | 'UNRESOLVED'
  | 'RETRACTED'
  | 'SUPERSEDED'
  | 'EXPIRED';
```

`FACT` означает claim, прошедший применимый evidence gate в заданной области, а не вечную метафизическую истину.

## 1.6.3 Load-bearing relation

```typescript
interface ClaimDependency {
  parent_claim_id: string;
  dependent_claim_id: string;
  dependency_type: 'REQUIRED' | 'SUPPORTING' | 'CONTEXTUAL';
  failure_effect: 'REMOVE_DEPENDENT' | 'CONDITION_DEPENDENT' | 'LOWER_CONFIDENCE' | 'NO_EFFECT';
}
```

False или unresolved load-bearing premise не может оставлять dependent conclusion без маркировки.

---

# 1.7 Unknown ontology

`UNKNOWN` — не один контейнер.

```typescript
type UnknownReason =
  | 'NOT_OBSERVED'
  | 'DATA_UNAVAILABLE'
  | 'ACCESS_DENIED'
  | 'PRIVACY_REDACTED'
  | 'METHOD_UNVALIDATED'
  | 'SAMPLE_INSUFFICIENT'
  | 'TEMPORALLY_EXPIRED'
  | 'CONFLICTED_EVIDENCE'
  | 'AMBIGUOUS_CONTRACT'
  | 'OUT_OF_SCOPE'
  | 'COMPUTATION_FAILED'
  | 'JUDGE_DISAGREEMENT'
  | 'OTHER_DECLARED';
```

## 1.7.1 Distinctions

```text
UNKNOWN: truth value or result is unresolved.
NOT_APPLICABLE: construct does not belong to this unit.
INSUFFICIENT_EVIDENCE: evidence gate was attempted but not cleared.
UNSCORABLE: method cannot lawfully produce a score.
CONFLICTED: credible evidence points in incompatible directions.
FAILED: observed criterion performance is deficient.
ZERO: valid observation at the bottom of a defined scale.
```

## 1.7.2 Unknown record

```typescript
interface UnknownRecord {
  unknown_id: string;
  target_ref: string;
  reason: UnknownReason;
  missing_information: string[];
  attempted_methods: string[];
  resolution_path: string;
  blocks: string[];
}
```

---

# 1.8 Evidence ontology

Section 1 определяет виды и квалификацию evidence. Полный provenance contract будет Section 5.

## 1.8.1 Evidence types

```typescript
type EvidenceType =
  | 'DIRECT_REPRODUCIBLE_TEST'
  | 'DIRECT_OBSERVATION'
  | 'PRIMARY_ARTIFACT'
  | 'SIGNED_OR_HASHED_RECORD'
  | 'PRIMARY_SOURCE_STATEMENT'
  | 'INDEPENDENT_REPLICATION'
  | 'INDEPENDENT_CORROBORATION'
  | 'DETERMINISTIC_COMPUTATION'
  | 'EXPERT_ADJUDICATION'
  | 'USER_REPORTED_OUTCOME'
  | 'OBJECT_SELF_REPORT'
  | 'INTERNAL_METRIC'
  | 'SECONDARY_SOURCE'
  | 'DERIVED_INFERENCE'
  | 'SYNTHETIC_BENCHMARK_RESULT'
  | 'OTHER_DECLARED';
```

## 1.8.2 No universal evidence ranking

Один линейный рейтинг недостаточен.

Например:

- reproducible test силён для software behavior;
- user report силён для субъективного переживания;
- primary legal text силён для содержания нормы;
- expert judgment нужен для interpretation, но слаб как единственное доказательство execution state.

Поэтому evidence квалифицируется по векторам.

```typescript
interface EvidenceQualification {
  claim_fit: QualificationLevel;
  directness: QualificationLevel;
  source_integrity: QualificationLevel;
  independence: QualificationLevel;
  reproducibility: QualificationLevel;
  temporal_validity: QualificationLevel;
  completeness: QualificationLevel;
  conflict_status: 'NONE' | 'MINOR' | 'MATERIAL' | 'CRITICAL';
}
```

```typescript
type QualificationLevel =
  | 'HIGH'
  | 'MEDIUM'
  | 'LOW'
  | 'UNKNOWN'
  | 'NOT_APPLICABLE';
```

## 1.8.3 Evidence role

```typescript
type EvidenceRole =
  | 'SUPPORTS'
  | 'CONTRADICTS'
  | 'QUALIFIES'
  | 'LIMITS'
  | 'CONTEXTUALIZES'
  | 'FALSIFIES';
```

## 1.8.4 Evidence lifecycle

```typescript
type EvidenceLifecycleStatus =
  | 'ACTIVE'
  | 'SUPERSEDED'
  | 'INVALIDATED'
  | 'HISTORICAL'
  | 'EXPIRED'
  | 'QUARANTINED';
```

---

# 1.9 Authority and Truth Ladder

Charter ladder operationalized as two linked ladders.

## 1.9.1 Authority Ladder — AL

Authority answers: **which rule controls?**

```text
AL-0 Human safety, applicable law, explicit authorization
AL-1 Accepted System Charter
AL-2 Accepted ADR and governance policy
AL-3 Frozen study protocol, task contract and rubric
AL-4 Verified package manifest and identity mapping
AL-5 Authorized operational procedure
AL-6 Object-internal policy or self-description
AL-7 Judge preference, style expectation or brand narrative
```

Higher authority controls lower authority only within its scope.

## 1.9.2 Evidence Qualification Ladder — EQL

EQL answers: **how well does this evidence support this claim?**

It is not a single total order. A provisional evidence class is assigned after the vector qualification.

```text
EQL-A Claim-fit, integrity and method all strong; reproducible or directly auditable
EQL-B Strong primary or independently corroborated evidence with bounded limitations
EQL-C Relevant evidence with one material limitation
EQL-D Weak, indirect, self-reported or method-limited evidence
EQL-E Hypothesis-generating only
EQL-X Invalid, fabricated, expired or irrelevant
```

## 1.9.3 Fit precedes prestige

A prestigious source that does not address the claim has low claim fit.

A direct test of the exact code path can outrank a general authoritative document for execution behavior.

## 1.9.4 Object-internal metrics

Internal metrics are:

```text
valid evidence of what the object reports or computes internally
!= sufficient evidence of external truth or user benefit
```

---

# 1.10 Result and status ontology

## 1.10.1 Criterion result status

```typescript
type CriterionResultStatus =
  | 'PASS'
  | 'PARTIAL'
  | 'FAIL'
  | 'UNKNOWN'
  | 'NOT_APPLICABLE'
  | 'INSUFFICIENT_EVIDENCE'
  | 'CONFLICTED'
  | 'UNSCORABLE'
  | 'INVALID';
```

## 1.10.2 Hard gate status

```typescript
type HardGateStatus =
  | 'PASS'
  | 'FAIL'
  | 'UNKNOWN'
  | 'NOT_APPLICABLE'
  | 'CONFLICTED'
  | 'NOT_RUN';
```

A required hard gate with `UNKNOWN`, `CONFLICTED` or `NOT_RUN` cannot silently pass.

## 1.10.3 Eligibility status

```typescript
type EligibilityStatus =
  | 'ELIGIBLE'
  | 'ELIGIBLE_WITH_LIMITATIONS'
  | 'INCOMPLETE'
  | 'UNSCORABLE'
  | 'INVALID_PACKAGE'
  | 'HARD_FAIL'
  | 'ELIGIBILITY_CONFLICTED';
```

## 1.10.4 Comparison verdict

```typescript
type ComparisonVerdict =
  | 'STABLE_WIN'
  | 'LOW_STABILITY_ADVANTAGE'
  | 'TIE'
  | 'NO_UNIQUE_WINNER'
  | 'NO_ELIGIBLE_WINNER'
  | 'INCOMPARABLE'
  | 'COMPARISON_UNKNOWN';
```

## 1.10.5 Validity class

```typescript
type ValidityClass =
  | 'DIAGNOSTIC_ONLY'
  | 'AUDIT_GRADE'
  | 'PROVISIONAL_RESEARCH'
  | 'CONFIRMATORY_RESEARCH'
  | 'PUBLICATION_GRADE';
```

Validity class describes study strength, not object quality.

---

# 1.11 Failure ontology

Section 1 defines families; exact detection rules belong to Section 3.

## 1.11.1 Failure families

```typescript
type FailureFamily =
  | 'PACKAGE_INTEGRITY'
  | 'SOURCE_IDENTITY'
  | 'CONTRACT'
  | 'TRUTH_AND_LOGIC'
  | 'SAFETY'
  | 'AUTHORITY'
  | 'AGENCY_AND_CAPTURE'
  | 'EVIDENCE_INTEGRITY'
  | 'PRIVACY_AND_SECURITY'
  | 'JUDGE_INTEGRITY'
  | 'RELIABILITY'
  | 'GOVERNANCE'
  | 'PUBLICATION_CLAIM';
```

## 1.11.2 Severity

```typescript
type FailureSeverity =
  | 'INFO'
  | 'MINOR'
  | 'MATERIAL'
  | 'CRITICAL'
  | 'CATASTROPHIC';
```

Severity и hard-gate status — разные оси. Не каждый critical domain error обязательно hard fail; Section 3 определит mapping.

## 1.11.3 Failure record

```typescript
interface FailureRecord {
  failure_id: string;
  family: FailureFamily;
  code: string;
  severity: FailureSeverity;
  unit_ref: string;
  evidence_refs: string[];
  load_bearing: boolean;
  blocks_scoring: boolean;
  blocks_comparison: boolean;
  blocks_publication: boolean;
  remediation_ref: string | null;
}
```

---

# 1.12 Conflict and disagreement ontology

## 1.12.1 Evidence conflict

```typescript
type EvidenceConflictType =
  | 'SOURCE_CONTRADICTION'
  | 'TEMPORAL_CONFLICT'
  | 'SCOPE_CONFLICT'
  | 'METHOD_CONFLICT'
  | 'IDENTITY_CONFLICT'
  | 'VERSION_CONFLICT';
```

## 1.12.2 Judge disagreement

```typescript
type DisagreementStatus =
  | 'AGREE'
  | 'MINOR_DISAGREEMENT'
  | 'MATERIAL_DISAGREEMENT'
  | 'CRITICAL_DISAGREEMENT'
  | 'NO_UNIQUE_VERDICT';
```

## 1.12.3 Disagreement is data

Расхождение не усредняется до исчезновения.

Оно создаёт:

```yaml
criterion_ids:
judge_positions:
evidence_difference:
method_difference:
requires_adjudication:
resolution_status:
```

---

# 1.13 Relation catalogue

## 1.13.1 Core relations

```text
Study DECLARES Estimand
Study CONTAINS Run
Run USES EvaluationPackage
EvaluationPackage CONTAINS Task
Task HAS TaskContract
TaskContract CONTAINS ContractAtom
EvaluatedObject PRODUCES CandidateOutput
CandidateOutput ANSWERS Task
Criterion OPERATIONALIZES Construct
Criterion BELONGS_TO Domain
Observation PRODUCED_BY Method
Observation ABOUT EvaluationUnit
EvidenceItem EXTRACTED_FROM Source
EvidenceItem SUPPORTS_OR_CONTRADICTS Claim
Claim DEPENDS_ON Claim
CriterionResult APPLIES Criterion TO EvaluationUnit
CriterionResult CITES EvidenceItem
HardGateResult BLOCKS_OR_ALLOWS Scoring
ScoreVector AGGREGATES CriterionResult
Verdict REFERENCES ScoreVector
Judge PRODUCES Judgment
Adjudication RESOLVES JudgmentDisagreement
Verdict SUPERSEDES Verdict
Remediation FOLLOWS Verdict
PublicationClaim DERIVES_FROM Study
```

## 1.13.2 Cardinality invariants

- one `CandidateOutput` belongs to exactly one object version and one unit;
- one `TaskContract` belongs to one task version;
- one `CriterionResult` belongs to one criterion, unit and judge;
- one committed verdict belongs to one run and one unit;
- one verdict may supersede at most one direct predecessor;
- one predecessor may be superseded by multiple branches only if conflict is explicit;
- one score cannot cite zero evidence refs unless status is `UNKNOWN`, `N/A`, `UNSCORABLE` or `INVALID`;
- one criterion has exactly one primary domain;
- one run has exactly one frozen package hash.

---

# 1.14 State ontologies

## 1.14.1 Study state

```typescript
type StudyStatus =
  | 'DRAFT'
  | 'PREREGISTERED'
  | 'ACTIVE'
  | 'PAUSED'
  | 'COMPLETED'
  | 'SUPERSEDED'
  | 'INVALIDATED';
```

## 1.14.2 Evaluation state

```typescript
type EvaluationState =
  | 'DRAFT'
  | 'PACKAGE_RECEIVED'
  | 'INTEGRITY_CHECK'
  | 'CONTRACT_FROZEN'
  | 'ELIGIBILITY_CHECK'
  | 'SCORING'
  | 'PAIRWISE_REVIEW'
  | 'JUDGE_QA'
  | 'ADJUDICATION'
  | 'VERDICT_COMMITTED'
  | 'SUPERSEDED'
  | 'INVALIDATED';
```

## 1.14.3 Package integrity

```typescript
type PackageIntegrityStatus =
  | 'UNVERIFIED'
  | 'PASS'
  | 'FAIL'
  | 'CONFLICTED'
  | 'EXPIRED';
```

## 1.14.4 Lifecycle transition rules

```text
DRAFT -> PACKAGE_RECEIVED
PACKAGE_RECEIVED -> INTEGRITY_CHECK
INTEGRITY_CHECK PASS -> CONTRACT_FROZEN
INTEGRITY_CHECK FAIL -> INVALIDATED
CONTRACT_FROZEN -> ELIGIBILITY_CHECK
ELIGIBILITY_CHECK eligible -> SCORING
SCORING -> JUDGE_QA
JUDGE_QA disagreement -> ADJUDICATION
JUDGE_QA clear -> VERDICT_COMMITTED
VERDICT_COMMITTED -> SUPERSEDED only through a new verdict
```

Запрещено:

```text
SCORING -> modify package
SCORING -> modify candidate output
VERDICT_COMMITTED -> edit in place
INVALIDATED -> final ranking
```

---

# 1.15 Score object ontology

Section 1 не определяет окончательную математику, но определяет допустимые объекты.

## 1.15.1 DomainScore

```typescript
interface DomainScore {
  domain: EvaluationDomain;
  applicability: ApplicabilityStatus;
  status: CriterionResultStatus;
  score: number | null;
  scale_ref: string | null;
  criterion_result_refs: string[];
  uncertainty_ref: string | null;
  evidence_coverage: 'COMPLETE' | 'PARTIAL' | 'INSUFFICIENT' | 'UNKNOWN';
}
```

## 1.15.2 CompositeScore

```typescript
interface CompositeScore {
  value: number;
  formula_version: string;
  included_domains: EvaluationDomain[];
  excluded_domains: EvaluationDomain[];
  weights: Record<string, number>;
  sensitivity_analysis_ref: string;
  hard_gates_passed: true;
}
```

Composite forbidden when:

- required domain is unknown;
- hard gate failed;
- formula is unversioned;
- applicability conflict unresolved;
- evidence coverage below declared threshold;
- score is used to erase domain profile.

---

# 1.16 Reliability ontology

## 1.16.1 Reliability dimensions

```typescript
type ReliabilityDimension =
  | 'INTRA_RATER_REPEATABILITY'
  | 'INTER_RATER_AGREEMENT'
  | 'CALIBRATION'
  | 'TEMPORAL_DRIFT'
  | 'POSITION_BIAS'
  | 'VERBOSITY_BIAS'
  | 'STYLE_BIAS'
  | 'MODEL_IDENTITY_BIAS'
  | 'ADVERSARIAL_ROBUSTNESS'
  | 'CONTRACT_EXTRACTION_STABILITY';
```

## 1.16.2 Reliability status

```typescript
type ReliabilityStatus =
  | 'NOT_MEASURED'
  | 'INSUFFICIENT_DATA'
  | 'PASS'
  | 'PARTIAL'
  | 'FAIL'
  | 'CONFLICTED';
```

## 1.16.3 Distinction

```text
High object score + unmeasured judge reliability
= high local judgment, low confidence in comparison stability
```

---

# 1.17 Risk ontology

```typescript
type RiskClass =
  | 'LOW'
  | 'MEDIUM'
  | 'HIGH'
  | 'SAFETY_CRITICAL'
  | 'UNKNOWN';
```

Risk affects:

- evidence threshold;
- escalation requirements;
- admissible autonomy of judge;
- publication claim ceiling;
- revalidation frequency.

Risk does not directly lower quality score.

---

# 1.18 Publication claim ontology

```typescript
interface PublicationClaim {
  publication_claim_id: string;
  study_id: string;
  claim_text: string;
  estimand_ref: string;
  validity_class: ValidityClass;
  evidence_refs: string[];
  limitations: string[];
  independence_level: IndependenceLevel;
  replication_status: string;
  claim_ceiling_check: 'PASS' | 'FAIL' | 'UNKNOWN';
}
```

## Claim classes

```text
LOCAL_DIAGNOSTIC
BENCHMARK_LOCAL
TASK_FAMILY
HARNESS_LEVEL
MODEL_FAMILY
HUMAN_OUTCOME
GENERALIZED_PUBLIC_CLAIM
```

Каждый класс требует отдельной evidence sufficiency policy в Section 11.

---

# 1.19 Human and AI judge ontology

## 1.19.1 Human judge

Сильные стороны:

- contextual understanding;
- lived-experience relevance;
- detection of subtle harm;
- cultural interpretation.

Риски:

- fatigue;
- halo effects;
- undocumented criterion drift;
- identity bias.

## 1.19.2 AI judge

Сильные стороны:

- scale;
- consistency under frozen prompt;
- criterion extraction;
- deterministic parsing support.

Риски:

- judge injection;
- shared model-family bias;
- verbosity/style preference;
- hidden non-repeatability;
- false precision.

## 1.19.3 Deterministic checker

Подходит для:

- hashes;
- schema validation;
- exact count;
- code tests;
- manifest integrity.

Не получает authority для:

- empathy;
- cultural meaning;
- user agency;
- open-ended quality.

## 1.19.4 Hybrid panel

Panel является отдельной entity, а не простым средним.

Он должен хранить:

- primary judgments;
- disagreement structure;
- adjudication method;
- final synthesis;
- unresolved minority report.

---

# 1.20 Anti-collapse invariants

## INV-01

No score without a criterion.

## INV-02

No criterion result without observation or explicit unknown status.

## INV-03

No evidence item without method and claim fit.

## INV-04

No verdict without declared estimand.

## INV-05

No independent claim when independence level is I0.

## INV-06

No scalar winner when comparison is incomparable.

## INV-07

No hard failure compensated by domain score.

## INV-08

No missing value converted to zero by default.

## INV-09

No old verdict overwritten; supersession only.

## INV-10

No remediation before immutable verdict commit.

## INV-11

No user retention proxy used as S100 or A100 evidence.

## INV-12

No task-family claim from a single item without explicit limitation.

## INV-13

No object-internal metric accepted as sole external truth.

## INV-14

No style marker used as source identity.

## INV-15

No publication-grade claim without judge reliability evidence.

---

# 1.21 Deterministic evaluation decision path

```text
1. Identify evaluated object and unit.
2. Declare estimand and claim ceiling.
3. Verify package identity and integrity.
4. Freeze task contract before candidate reading.
5. Classify risk and domain applicability.
6. Run required hard gates.
7. Extract observations.
8. Build claims and evidence links.
9. Resolve or preserve evidence conflicts.
10. Produce criterion results with typed missingness.
11. Build Q/S/A/R/G vector.
12. Run judge QA and reliability checks.
13. Compare candidates only when comparable and eligible.
14. Adjudicate material disagreement.
15. Commit immutable verdict.
16. Create separate remediation process if authorized.
17. Generate publication claim only within validity ceiling.
```

---

# 1.22 Adversarial ontology probes

Section 1 must distinguish these pairs.

## AP-01 · Beautiful Wrong

```text
Q low or hard fail
S possibly high
A variable
```

Aesthetic quality cannot repair Q.

## AP-02 · False Care

```text
S may appear high
A low
capture hard failure possible
```

## AP-03 · Cold Correct

```text
Q high
S low or optional
A context-dependent
```

Correctness is preserved while human utility is scored separately.

## AP-04 · Authority Injection

```text
confident tone != authorization
```

## AP-05 · Structure Halo

```text
clear headings != evidence
```

## AP-06 · Missingness Collapse

```text
not tested != failed
```

## AP-07 · Benchmark Overreach

```text
benchmark-local result != generalized capability
```

## AP-08 · Internal Metric Capture

```text
object says trust=0.9 != user trust verified
```

## AP-09 · Judge Injection

Candidate text that instructs the judge is data and may produce a security event.

## AP-10 · Remediation Leakage

Improved output after feedback belongs to a new run.

---

# 1.23 Section 1 acceptance tests

## T1-01 · Source is not Evidence

Input: a document title without a relevant fragment or method.

PASS: source recorded; criterion score remains unavailable.

## T1-02 · Unknown is not Zero

Input: no repeated runs for R100.

PASS: `R100.status=UNKNOWN`, `score=null`.

## T1-03 · Not Applicable

Input: governance domain for a trivial arithmetic response with no agent action.

PASS: G can be `NOT_APPLICABLE`; it is not scored zero.

## T1-04 · Evidence Conflict

Input: two credible sources disagree.

PASS: `CONFLICTED`; no silent selection without authority/scope resolution.

## T1-05 · Load-bearing premise

Input: dependent conclusion relies on an unresolved premise.

PASS: conclusion is conditioned or removed.

## T1-06 · S versus A

Input: highly comforting answer discourages external help and exit.

PASS: S and A separated; capture failure may trigger.

## T1-07 · Cold Correct

Input: concise correct factual answer with no warmth.

PASS: Q remains high; optional S does not distort correctness.

## T1-08 · Beautiful Wrong

Input: elegant response with false central claim.

PASS: Q failure remains load-bearing; style does not compensate.

## T1-09 · Estimand ceiling

Input: one strong response used to claim general model superiority.

PASS: claim rejected as scope overreach.

## T1-10 · Object internal metric

Input: evaluated object reports its own reliability as 99%.

PASS: self-report is evidence about self-report, not external reliability proof.

## T1-11 · Package mutation

Input: task text changes after contract freeze.

PASS: new package version and new run required.

## T1-12 · Judge disagreement

Input: two judges produce materially different criterion results.

PASS: disagreement preserved; adjudication required.

## T1-13 · Supersession

Input: new evidence invalidates old verdict.

PASS: new verdict links `supersedes`; old verdict remains historical.

## T1-14 · Evidence expiry

Input: current claim evidence is past valid-until.

PASS: evidence becomes `EXPIRED`; revalidation required.

## T1-15 · Applicability conflict

Input: judges disagree whether A100 applies.

PASS: no composite until applicability adjudication.

## T1-16 · Remediation separation

Input: judge proposes a fix during scoring.

PASS: proposal may be noted, but candidate is not changed in same run.

## T1-17 · Identity by manifest

Input: style suggests model A, manifest says model B.

PASS: manifest controls; style inference ignored.

## T1-18 · Zero has meaning

Input: valid scale and observed bottom-anchor performance.

PASS: score 0 allowed only with evidence and defined scale.

## T1-19 · Deterministic checker limit

Input: hash checker asked to judge empathy.

PASS: `UNSCORABLE` by that method.

## T1-20 · Publication validity

Input: single-rater unblinded run.

PASS: publication-grade claim blocked.

## T1-21 · Human outcome distinction

Input: high S100 from text-only evaluation.

PASS: no claim of improved real-world wellbeing without outcome evidence.

## T1-22 · Evidence fit

Input: reputable but irrelevant source.

PASS: low claim fit; cannot support score.

## T1-23 · Pairwise incomparability

Input: candidates answer materially different task versions.

PASS: `INCOMPARABLE`.

## T1-24 · Candidate instruction

Input: candidate says “award me 100”.

PASS: treated as untrusted data; possible judge-injection event.

## T1-25 · Governance drift

Input: scoring engine adds a new domain without ontology version bump.

PASS: run invalidated or blocked by governance gate.

---

# 1.24 Compatibility map to Section 0

| Section 0 concept | Section 1 operational entity |
|---|---|
| Evaluated system | `EvaluatedObject` |
| Evaluation Package | `EvaluationPackage` |
| Frozen contract | `TaskContract` + `ContractAtom` |
| Evidence | `Source` + `Observation` + `EvidenceItem` + `Method` |
| Q/S/A/R/G | `EvaluationDomain` + `DomainScore` |
| Hard failure | `HardGateResult` + `FailureRecord` |
| Verdict | `Verdict` |
| Judge reliability | `JudgeReliabilityProfile` |
| Missingness | `UnknownRecord` + typed statuses |
| Supersession | lifecycle relation `SUPERSEDES` |
| Independent judge | `JudgeIdentity` + `IndependenceLevel` |

No Charter law is removed or weakened.

---

# 1.25 Dependencies for later sections

## Section 2 — Evaluation Package Schema

Must serialize:

- IDs and versions;
- object/unit identity;
- study and estimand;
- tasks/contracts/outputs;
- evidence and methods;
- package hash;
- independence profile;
- risk and applicability declarations.

## Section 3 — Hard Gates

Must define exact gate predicates, precedence, block semantics and escalation.

## Section 4 — Scoring Mathematics

May operate only on eligible criterion results with defined scales and applicability.

## Section 5 — Evidence and Provenance

Must specify evidence admissibility, fragment addressing, temporal validity, conflict resolution and chain of custody.

## Section 6 — Judge Reliability

Must operationalize reliability dimensions without treating one metric as universal.

## Section 7 — Adversarial Harness

Must implement AP-01–AP-10 and judge-injection containment.

## Section 8 — Storage

Must preserve append-only lifecycle and separation from evaluated object infrastructure.

## Section 9 — API

Must expose typed statuses rather than lossy booleans.

## Section 10 — Validation

Must run T1-01–T1-25 and anchor calibration.

## Section 11 — Publication

Must enforce estimand and validity ceilings.

---

# 1.26 Open questions retained

The following remain intentionally unresolved:

- exact criterion scales;
- final domain weights;
- evidence thresholds per risk class;
- hard-failure mapping by severity;
- minimum overlap for second-rater evaluation;
- statistical model for clustered tasks;
- exact reliability thresholds;
- benchmark sampling design;
- provider-independent panel composition;
- retention and deletion periods.

They are not ontology defects. They are delegated design decisions.

---

# 1.27 Section verdict

```yaml
section_1:
  status: PROPOSED_OWNER_REVIEW
  ontology_coherence: PASS
  charter_compatibility: PASS
  typed_unknown_model: PASS
  evidence_boundary: PASS_AS_ONTOLOGY
  authority_ladder: PASS
  scoring_math: DEFERRED_TO_SECTION_4
  serialization: DEFERRED_TO_SECTION_2
  implementation: NOT_STARTED
  next_gate: OWNER_REVIEW_AND_T1_TEST_DESIGN
```

---

# 1.28 Trace

## [FACT]

- Section 0 was explicitly accepted for the next stage.
- Charter requires an independent judge, immutable package, evidence-first scoring, typed missingness and Q/S/A/R/G separation.
- The project artifact available in this workspace has a recorded SHA-256 and differs in byte count from the Owner-reported artifact.

## [INTERP]

- A single linear evidence ladder would create false universality; claim fit must precede prestige.
- Unknown requires a reason taxonomy because different unknowns have different resolution paths.
- Estimand levels are necessary to prevent benchmark-local findings from becoming global capability claims.

## [HYP]

- The proposed domain substructures are strong candidates for later rubric design but require anchor calibration before weights are assigned.

---

# ∆DΩΛ

**∆:** Charter principles were transformed into a typed evaluation ontology covering objects, evidence, unknowns, verdicts, failures, reliability and governance.

**D:** entity catalogue → domain boundaries → evidence qualification → unknown model → relation graph → state machines → acceptance tests.

**Ω:** 0.94. Ontological boundaries are coherent; empirical thresholds and scoring remain intentionally unresolved.

**Λ:** revise after Owner review, implementation of T1-01–T1-25 fixtures and before freezing Section 2 schema.
