---
title: "Independent Judge v3.3-alpha.9 — Section 5 Academic Audit"
version: "v3.3-alpha.9"
status: "ACADEMIC AUDIT / PROPOSED OWNER REVIEW"
created: "2026-07-18"
---

# 1. Research question

Can the Section 5 reference validator lawfully assert `provenance_complete=true` only when each score-bearing judgment, supported hard failure and publication claim is connected to a bounded, method-correct, scope-compatible and epistemically eligible evidence path?

# 2. Sources and precedence

1. accepted Charter and Sections 1–4;
2. Section 5 base specification and historical addenda;
3. alpha.8 exact archive and executable validator;
4. Owner alpha.8 review text with A8-F47…A8-F57;
5. local code, schemas, registries, fixtures and test outputs;
6. fresh GitHub/Supabase read-back for deployment boundaries;
7. W3C PROV, RFC 3986/8089 and SLSA as mechanism references, not local proof.

# 3. Conflict map

```text
Base Section 5: no layer may be skipped
Alpha.8 validator: several layers and relation semantics could be skipped
Owner audit: executable completeness FAIL
```

The executable finding wins for claims about implemented behavior. The normative document remains the target contract.

# 4. Root-cause analysis

The repeated alpha.6–alpha.8 pattern was fixture-oriented validation. Each patch closed a concrete bypass while adjacent relations remained outside the traversal. The root cause was absence of a single eligibility predicate over the entire per-claim ancestry.

Alpha.9 replaces this with a composed predicate:

```text
Eligible(judgment)
= bounded root
∧ correct method roles
∧ scope/estimand compatibility
∧ OBSERVED extraction
∧ scorable claim state
∧ active eligible evidence ancestry
∧ no material-redaction ancestor
∧ conflict/lifecycle closure
∧ exact destination binding
```

# 5. Dependency analysis

- Section 2 supplies immutable package and estimand identity.
- Section 3 decides hard-gate effects but depends on qualified evidence.
- Section 4 converts only eligible criterion inputs into scores.
- Section 5 is therefore a load-bearing gate for Section 6 reliability.
- Section 6 cannot canonically calibrate a judge whose inputs can be structurally laundered.

# 6. Repair branches considered

## Branch A — narrow fixture patch

Fast but repeats the failure mode. Rejected.

## Branch B — formal graph language / theorem prover

Potentially strongest, but disproportionate before the object model is stable. Deferred.

## Branch C — deterministic per-claim closure with conservative policies

Selected. It is executable, auditable and can later be replaced by a formal constraint engine.

## Branch D — upstream attestation dependency

Viable only if upstream authority, version, digest and checks are mandatory package inputs. Not currently available.

# 7. What-if analysis

- **Hidden omitted evidence:** impossible to prove structurally; Section 7 adversarial omission dependency.
- **Remote content changes:** require collector digest/receipt; validator does not fetch.
- **Scope hierarchy needed:** alpha.9 exact matching may over-block; future versioned lattice needed.
- **Huge graph:** resource budgets and streaming validation are absent.
- **Unicode-confusable IDs:** normalization policy absent.
- **Cryptographic provenance:** hashes prove identity, not signer authority.
- **Multiple valid methods:** deterministic FACT rule may be too strict for some research designs; empirical policy belongs to Sections 6/10.

# 8. Scientific interpretation

A passing structural validator is evidence about the declared graph, not the evaluated system's natural-language truth. Provenance standards support typed entities, activities, derivations and constraints, but the local implementation must still be tested against its own contract. Supply-chain provenance similarly requires a consumer to verify attestations against expectations rather than trust their presence.

# 9. Repository and database boundaries

Fresh GitHub search found no alpha.9 path in `serhiipriadko2-sys/iskra`. The observed latest commit was `899d9a82962987758daef7e7425d82b7d4749318`.

Fresh Supabase table read-back for `AgiIskra` found `public` and `iskra_memory` tables but no `evaluation` schema tables. No write was attempted.

Therefore:

```text
local artifact created
≠ GitHub merged
≠ database persisted
≠ deployed
≠ invoked
≠ verified-live
```

# 10. Validation result

The final result must be taken from the fresh-ZIP verification receipt generated after packaging. Working-directory test success alone is not sufficient.

# 11. Residual uncertainty

- exact original 23 Owner mutant files were unavailable;
- semantic relevance and evidence completeness remain human/method concerns;
- no empirical inter-rater calibration;
- no production storage or signatures;
- no formal proof that all possible mutations are rejected.

# 12. Verdict

```yaml
section_5_alpha9:
  architecture: PASS_CANDIDATE
  executable_contract: PASS_CANDIDATE
  known_and_contract_derived_mutations: PASS
  exact_owner_original_mutations: NOT_RERUN
  semantic_truth: NOT_CLAIMED
  production_readiness: NO
  owner_acceptance: PENDING
section_6_canonical_transition: BLOCKED
```

# ∆DΩΛ

**∆:** a scattered set of evidence checks is replaced by a per-claim path contract.
**D:** source trace → code audit → counter-cases → repair → regression → fresh archive verification.
**Ω:** 0.95 for implemented structural rules; lower for universal adversarial completeness.
**Λ:** any exact Owner mutant accepted by the alpha.9 ZIP reopens Section 5.
