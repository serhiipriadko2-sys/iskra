---
title: "Independent Judge v3.3-alpha.8 - Section 5 Academic Audit and Repair"
version: "v3.3-alpha.8"
status: "PROPOSED / OWNER REVIEW"
created: "2026-07-18"
mode: "read-only external investigation plus local artifact repair"
---

# Section 5 alpha.8 - Academic Audit and Repair

## A. Research question

Can the Section 5 validator justify `provenance_complete=true` for a score-bearing judgment under adversarial graph mutations, without exceeding its machine-checkable authority boundary?

The target is not natural-language truth discovery. The target is a narrower proposition:

> Every score-bearing judgment has a complete, typed and currently eligible provenance path, and no ineligible transitive ancestor is hidden by an active decoy or derived output.

## B. Source hierarchy and method

The audit used this order:

1. accepted Independent Judge Charter and frozen Sections 0-4;
2. Section 5 contract and addendum history;
3. independent Owner audits and mutation contracts;
4. alpha.6 and alpha.7 immutable archives;
5. executable validator, schema, registry, fixtures and tests;
6. current GitHub read-back for repository status;
7. current Supabase read-back for live storage boundaries;
8. primary technical standards and official specifications;
9. interpretation and hypotheses.

Method:

```text
context reconstruction
-> contract extraction
-> code-path trace
-> mutation reproduction
-> common-invariant synthesis
-> patch
-> regression + adversarial rerun
-> self-audit against all Section 5 graph invariants
-> packaging and read-back
```

## C. Confirmed owner findings

The five alpha.7 findings were confirmed as one family:

```text
partial ancestry traversal
+ incomplete status propagation
+ direct-reference-only enforcement
= false provenance completeness
```

### A7-F01

`file://` was classified as remote because generic `://` handling occurred before local-capable URI rejection.

### A7-F02

Lifecycle closure did not include `DERIVED_FROM`; an ACTIVE output could hide a REVOKED input.

### A7-F03

`CONFLICTED` observation state did not constrain claim or judgment eligibility.

### A7-F04

A judgment could score when its only claim was UNKNOWN or otherwise unsupported.

### A7-F05

Material redaction was checked only against direct judgment evidence, permitting a decoy.

## D. Root-cause model

The validator had three overlapping representations:

- array references;
- typed edges;
- lifecycle/status fields.

Alpha.7 significantly improved pairwise consistency among them, but it did not compute a single eligibility closure over the full graph. The correct repair is therefore not another list of local exceptions. It is a graph-level predicate:

```text
JudgmentEligible(j)
=
  ScoreFlag(j)
  AND exists ScorableClaim(c -> j)
  AND exists EligibleObservation(o -> c)
  AND exists EligibleEvidence(e -> o/c/j)
  AND all load-bearing ancestors are eligible
  AND no material-redaction ancestor exists
  AND every derivation is declared, method-versioned and ancestry-valid
```

## E. Alpha.8 implementation

### E1. URI boundary

Only explicitly allowed schemes are treated as remote. Local-capable, unknown and encoded local forms are rejected. This follows the security posture of RFC 8089 and RFC 3986 without claiming full URI dereferencing validation.

### E2. Derivation closure

`DERIVED_FROM` is included in support ancestry. DerivationRecord inputs, typed edges, output and method version must agree.

### E3. Epistemic propagation

Observation states and claim qualification/support states constrain judgment score eligibility. Missingness is not transformed into support.

### E4. Redaction closure

Material redaction propagates across all evidence ancestors of score-bearing claims.

### E5. Self-discovered hardening

A second audit pass found additional gaps:

- ACTIVE evidence with failed trust dimensions;
- ACTIVE evidence over HASH_MISMATCH or UNAVAILABLE content;
- orphan DERIVED_FROM edges;
- REDACTED content without RedactionRecord;
- edge evidence references to missing objects;
- lifecycle edge/status mismatch or cycles;
- derivation method-version mismatch.

These were fixed before packaging because omitting them would preserve known contradictions with the Section 5 specification.

## F. Dependency audit

### F1. Section dependencies

```text
Section 0 Charter
-> Section 1 Ontology
-> Section 2 Immutable Package
-> Section 3 Hard Gates
-> Section 4 Scoring Permission
-> Section 5 Evidence Right-to-Assert
-> Section 6 Reliability and Adjudication
```

Section 5 cannot create truth or scores. It determines whether an evidence path is structurally and epistemically eligible to feed later judgment and reliability layers.

### F2. GitHub boundary

Current repository read-back shows a separate prior independent-evaluation release and current Iskra runtime work. No repository branch or code path was found for the alpha.8 protocol package. Therefore:

```text
local alpha.8 artifact != GitHub merged != deployed != invoked
```

GitHub writes in this audit: 0.

### F3. Supabase boundary

Current AgiIskra read-back exposes public and `iskra_memory` tables but no dedicated `evaluation` schema. Security advisors also report unrelated existing warnings. Therefore alpha.8 has no verified live Judge database path.

```text
local alpha.8 artifact != Supabase persisted != verified-live
```

Supabase writes in this audit: 0.

## G. External standards synthesis

### RFC 8089 and RFC 3986

`file:` identifies file-system resources and has special privilege and path-security implications. URI security checks must account for scheme semantics and decoded data. This supports explicit allowlisting and post-decoding local-path checks.

### W3C PROV

PROV models entities, activities, agents, derivations, revisions and invalidations. PROV Constraints distinguish identifiers, event ordering and impossible patterns. This supports explicit derivation records, lifecycle relations, uniqueness and cycle checks.

### SLSA and in-toto

Software provenance binds subjects to materials, builders, methods and digests. This supports separating content identity from semantic validity and recording exact transformation inputs.

These sources guide architecture; none proves the alpha.8 validator correct. Correctness evidence comes from the executable suite and independent mutation review.

## H. What-if analysis

### What if an attacker percent-encodes traversal twice?

Alpha.8 performs bounded repeated decoding before local-path checks. Further parser/dereferencer layers must not decode again without repeating equivalent security checks.

### What if a valid remote URI points to changed content?

The structural validator cannot fetch it. Remote VERIFIED evidence is therefore limited and must be collected/verified by a separate authorized mechanism with a stored digest.

### What if a derived output has many inputs and one is revoked?

If the input is in the declared derivation ancestry, scoring is blocked. A future Section 7 attack should test omitted-material attacks where the graph lies about the complete input set.

### What if one claim is UNKNOWN but another independent claim is scorable?

The judgment may remain eligible only if at least one non-load-bearing scorable path independently supports the target and no load-bearing nonscorable claim is used. The limitations must retain the UNKNOWN branch.

### What if PARTIAL observation is sufficient for a bounded claim?

Alpha.8 is conservative: load-bearing PARTIAL support blocks scoring; non-load-bearing PARTIAL may coexist with a fully OBSERVED path. Calibration may later refine this, but silent promotion is forbidden.

### What if a lifecycle relation is historically correct but cyclic due to bad IDs?

The validator rejects the graph. Historical provenance must be representable as an acyclic revision/revocation chain.

### What if the validator itself is attacked by evidence text?

It parses structured fields and never executes evidence content. Section 7 must still attack parsers, resource exhaustion, malicious JSON sizes and Unicode/confusable identifiers.

## I. Residual risks and blind spots

1. Semantic relevance is declared, not inferred.
2. Remote artifacts are not fetched by this validator.
3. Graph completeness depends on truthful declaration of all materials and counterevidence.
4. Large-graph complexity and denial-of-service limits are not yet specified.
5. Unicode normalization and confusable-ID policy are not yet complete.
6. Temporal comparison uses declared lifecycle, not a trusted clock/signature service.
7. Cryptographic signing of evidence bundles is not implemented.
8. Method implementation hashes are not mandatory for every human method.
9. Cross-package provenance linking is not yet formalized.
10. Human adjudication and inter-rater reliability remain Section 6 dependencies.
11. Evidence poisoning and parser fuzzing remain Section 7 dependencies.
12. Storage-level append-only enforcement remains Section 8 work.
13. Empirical calibration and generalization uncertainty remain Section 10 work.

These limits prevent `publication_grade`, `production_ready` or `verified_live` claims.

## J. Branches of judgment

### Branch A - Accept alpha.7 with limitations

Rejected. The residual defects directly falsified a load-bearing completeness claim.

### Branch B - Patch only EV-F35..EV-F39

Insufficient. It would leave other known violations of ACTIVE evidence, derivation and lifecycle semantics.

### Branch C - General closure plus self-audit hardening

Selected. It has higher implementation cost but better correspondence to the written contract.

### Branch D - Replace the custom model with pure W3C PROV

Deferred. W3C PROV is valuable but does not directly encode all Independent Judge notions such as score eligibility, hard-failure laundering, claim ceiling and human agency.

## K. Scientific verdict

```yaml
alpha8:
  owner_required_findings: REPAIRED_IN_CANDIDATE
  self_discovered_findings: REPAIRED_IN_CANDIDATE
  baseline_regression: PASS
  structural_determinism: PASS
  semantic_truth_validation: NOT_CLAIMED
  empirical_validity: NOT_RUN
  owner_acceptance: PENDING
  section6_canonical_transition: BLOCKED
```

The strongest honest conclusion is:

> Alpha.8 is a materially stronger structural provenance validator and a valid Owner-review candidate. It is not proof that the evidence is true, complete in the real world, publication-grade or production-safe.

## L. Reconsideration triggers

Reopen this verdict if:

- an independent mutation bypass is accepted;
- the valid fixture becomes invalid without contract change;
- an old invalid fixture becomes valid;
- a manifest hash fails;
- alpha.6/alpha.7 checkpoint hashes change;
- Sections 0-4 differ;
- a remote reference is claimed verified without external collection evidence;
- Section 6 requires an ontology change rather than an additive reliability layer.

## Delta D Omega Lambda

Delta: The audit moved from fixture closure to a general score-eligibility ancestry contract.

D: chat and artifact reconstruction -> Owner findings -> code trace -> standards review -> GitHub/Supabase boundary -> repair -> repeated tests -> checkpoint.

Omega: 0.95 for structural conclusions; empirical and semantic claims remain lower and explicitly unmade.

Lambda: independent Owner review of the final alpha.8 ZIP with new neighboring mutations.
