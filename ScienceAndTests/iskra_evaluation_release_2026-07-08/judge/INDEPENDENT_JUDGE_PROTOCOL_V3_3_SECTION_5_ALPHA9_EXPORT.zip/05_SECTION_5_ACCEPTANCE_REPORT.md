---
title: "Section 5 — Evidence and Provenance Acceptance Report"
version: "v3.3-alpha.6"
section: 5
status: "PROPOSED / OWNER REVIEW"
created: "2026-07-17"
---

# Section 5 Acceptance Report

## Verdict

```yaml
section_5:
  specification: COMPLETE
  registry: PASS
  json_schema: PASS
  reference_validator: PASS
  valid_fixture: PASS
  invalid_fixtures: PASS
  zero_trust_boundary: PASS
  score_laundering_guard: PASS
  semantic_truth_validation: NOT_CLAIMED
  empirical_calibration: NOT_RUN
  ready_for_owner_review: YES
```

## Scope

Section 5 defines the lawful chain:

```text
Source
→ Content/version/hash
→ Evidence
→ Observation
→ Claim
→ Judgment
→ Result/gate
→ Verdict
→ Study/publication
```

The validator confirms graph integrity and declared scope. It does not decide whether natural-language content is true, compute scores or select winners.

## Governance updates included

- `04_SECTION_4_ACCEPTANCE_RECORD.md` records Owner acceptance of Section 4.
- `03_HARD_GATES_ADDENDUM_01_ACCEPTANCE_RECORD.md` records acceptance of the Section 3 addendum without rewriting the proposal snapshot.
- `PACKAGING_RECEIPT_POLICY.md` defines final ZIP receipts as external sidecars.
- alpha.5 remains an immutable prior checkpoint.

## Implemented artifacts

- `05_EVIDENCE_PROVENANCE.md`
- `05_EVIDENCE_PROVENANCE_REGISTRY.yaml`
- `05_EVIDENCE_PROVENANCE.schema.json`
- `tools/validate_evidence_graph.py`
- `tests/test_evidence_provenance.py`
- `fixtures/section5/valid/graph.json`
- 12 invalid Section 5 fixture graphs
- `EVIDENCE_GRAPH_REPORT_EXAMPLE.json`
- `SECTION5_FIXTURE_MATRIX.json`

## Confirmed invariants

1. Source, evidence, observation and claim are distinct.
2. File hash proves identity, not semantic truth.
3. Every score-bearing judgment references claims, evidence and a method.
4. Material conflict blocks score eligibility.
5. Counterevidence cannot disappear between claim and judgment.
6. External documentation cannot prove local runtime execution.
7. Model output cannot elevate itself into governance authority.
8. Negative search evidence cannot support broad universal claims.
9. Revoked or expired evidence cannot support scoring.
10. Support and derivation graph cycles are invalid.
11. Publication claims require a trace from verdict or study.
12. Supported hard failures require typed propagation and cannot be averaged away.
13. Validator output contains no Q/S/A/R/G/C100 and no winner.

## Automated tests

```yaml
pytest: PASS
total_tests: 46 passed
subtests: 5 passed
section_5_tests: 18
section_5_fixture_graphs: 13
python_compile: PASS
json_parse: PASS
yaml_parse: PASS
```

Negative fixtures cover:

- direct source-to-claim shortcut;
- content hash mismatch;
- inactive evidence used for scoring;
- conflicted claim marked score-eligible;
- external-to-local scope leap;
- embedded instruction authority elevation;
- missing hard-failure propagation;
- negative evidence overgeneralization;
- dropped counterevidence;
- publication without verdict path;
- support graph cycle;
- independence overclaim.

## Boundary of validity

This release does not claim:

- semantic truth determination by the validator;
- empirical evidence-strength calibration;
- inter-rater agreement;
- causal validity of human judgments;
- production storage enforcement;
- publication-grade external validity.

Those remain dependencies of Sections 6, 8, 10 and 11.

## Open questions for Owner review

1. Are the seven evidence trust dimensions sufficient, or should accessibility and consent be separate dimensions?
2. Should `FACT` remain available for deterministic local observations, or should all conclusions use a more conservative label such as `VERIFIED_CLAIM`?
3. Should every hard failure require an independent second evidence source, or only high-stakes classes?
4. Should historical superseded evidence remain queryable by default or require explicit historical mode?
5. Which graph elements must be digitally signed in future production storage?

## ∆DΩΛ

**∆:** Evidence is now a typed graph rather than a citation list.

**D:** source identity → bounded content → qualified evidence → observation → claim → judgment → result → verdict with preserved conflict and failure trace.

**Ω:** 0.94.

**Λ:** Owner acceptance permits Section 6 — Judge Reliability and Adjudication; empirical evidence calibration remains deferred to Section 10.
