# Section 5 alpha.9 — Independent Owner Review Guide

## Required intake

Verify the exact ZIP bytes and SHA-256 shown in the external sidecar receipt. Do not substitute the working directory.

## Minimal commands

```bash
unzip -t INDEPENDENT_JUDGE_PROTOCOL_V3_3_SECTION_5_ALPHA9_EXPORT.zip
sha256sum INDEPENDENT_JUDGE_PROTOCOL_V3_3_SECTION_5_ALPHA9_EXPORT.zip
python -m pytest -q tests
python tools/run_alpha9_mutation_matrix.py
python tools/validate_evidence_graph.py \
  fixtures/section5/valid/graph.json \
  --schema 05_EVIDENCE_PROVENANCE.schema.json \
  --registry 05_EVIDENCE_PROVENANCE_REGISTRY.yaml \
  --root fixtures/section5/valid
```

## Required checks

1. all manifest payload files exist and match size/hash;
2. valid fixture is `VALID` with `provenance_complete=true`;
3. every invalid fixture is `INVALID` with `provenance_complete=false`;
4. original Owner 23-case suite is rerun if available;
5. Sections 0–4 are byte-identical to alpha.8;
6. current ZIP sidecar remains external;
7. no cache artifacts, symlinks or unsafe ZIP members;
8. validator still emits no scores, truth verdict or winner.

## Acceptance semantics

A passing review may accept Section 5 as the structural provenance contract. It must not claim semantic truth validation, publication-grade reliability or production deployment.
