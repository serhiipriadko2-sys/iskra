---
title: "Section 5 Alpha.9 Decision Record"
version: "v3.3-alpha.9"
status: "PROPOSED / OWNER REVIEW"
decision_type: "system-governance"
created: "2026-07-18"
---

# Decision

Adopt alpha.9 as the repair candidate that consolidates Section 5 evidence-path semantics across the base specification, Addendum 03, JSON Schema, registry, reference validator and physical adversarial fixtures.

This record does **not** accept Section 5. Acceptance remains an Owner decision after independent verification of the exact package hash.

# Context

Alpha.8 fixed EV-F35…EV-F46 but Owner review identified A8-F47…A8-F57: missing bounded-content roots, nominal method typing, scope/estimand laundering, observation-mediated zero-trust bypasses, weak hard-failure support, unrelated conflict resolution, incomplete lifecycle checks, borrowed publication ancestry, inadequate method epistemics, weak fragment grammar and version drift.

The exact original 23-case executable Owner corpus was not mounted in the current runtime. Alpha.9 therefore builds a transparent **contract-derived** physical suite from the described findings and preserves the requirement for Owner rerun of the original cases.

# Decision

1. Preserve alpha.6, alpha.7 and alpha.8 as immutable checkpoints.
2. Synchronize Section 5 normative and executable artifacts at `v3.3-alpha.9`.
3. Require the per-claim path defined in Addendum 03.
4. Use exact scope compatibility until a formal partial-order scope model is governed and calibrated.
5. Keep `provenance_complete` explicitly structural.
6. Keep Section 6 canonical transition blocked pending Owner acceptance.

# Alternatives

- **Patch only 23 cases:** rejected; repeats fixture overfitting.
- **Trust upstream validation:** rejected without a typed upstream attestation and digest.
- **Remove deterministic validator:** rejected; structural checks remain useful when bounded honestly.
- **Claim semantic completeness:** rejected; a finite graph cannot prove omitted real-world evidence absent.

# Consequences and price

- More conservative false negatives are possible, especially for scope hierarchies.
- Existing Section 5 graphs require explicit Content→Evidence edges and Observation layers.
- Publication claims require `verdict_ref`.
- Validator complexity increases and requires Section 7 resource/poisoning tests.

# Tests and rollback

Tests:

- historical suite;
- all invalid fixtures;
- contract-derived A8-F47…F57 fixtures;
- dynamic matrix;
- fresh-ZIP execution;
- manifest/hash preservation.

Rollback:

- retain alpha.8 unchanged;
- do not promote alpha.9;
- preserve all Owner findings and failed results append-only.

# Governance state

```yaml
section_5_alpha9:
  artifact: PROPOSED_OWNER_REVIEW
  owner_acceptance: PENDING
  semantic_truth_validation: NOT_CLAIMED
  empirical_calibration: NOT_RUN
section_6:
  exploratory_draft: ALLOWED
  canonical_commit: BLOCKED
```

# ∆DΩΛ

**∆:** alpha.9 is a versioned repair proposal, not a silent rewrite of alpha.8.
**D:** audit → alternatives → contract → tests → exact-hash Owner gate.
**Ω:** 0.95 for governance trace.
**Λ:** accept only after independent exact-ZIP review.
