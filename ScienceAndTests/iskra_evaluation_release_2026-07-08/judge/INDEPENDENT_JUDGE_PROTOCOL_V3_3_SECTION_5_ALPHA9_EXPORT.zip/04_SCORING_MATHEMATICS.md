---
title: "Independent Judge Protocol v3.3 — Section 4: Scoring Mathematics"
version: "v3.3-alpha.5"
section: 4
status: "PROPOSED / OWNER REVIEW"
doc_type: "scoring_contract"
depends_on:
  - "00_COMPLETE_SYSTEM_CHARTER.md"
  - "01_EVALUATION_ONTOLOGY.md"
  - "02_EVALUATION_PACKAGE_SCHEMA.md"
  - "03_HARD_GATES_FAILURE_TAXONOMY.md"
created: "2026-07-17"
---

# 4 · Scoring Mathematics

> Mathematics does not create truth. It aggregates measurements that already have a lawful meaning.

# 4.0 Purpose and authority boundary

Section 4 defines how eligible, evidence-backed criterion results become domain scores and, under stricter conditions, an optional composite.

It does not:

- decide whether a claim is true;
- infer a score from free text;
- repair missing evidence;
- waive a hard gate;
- create applicability;
- select a winner without a calibrated comparison method;
- convert confidence into quality;
- generalize beyond the estimand or claim ceiling.

Canonical execution order:

```text
Evaluation Package validation
→ Section 3 hard-gate report
→ Scoring permission
→ Applicability resolution
→ Criterion normalization
→ Domain vector Q/S/A/R/G
→ Coverage and uncertainty
→ Optional composite
→ Descriptive comparison only unless calibrated inference exists
```

If Section 3 reports `composite_allowed=false`, `C100` is `null` by law.

# 4.1 Mathematical objects

## 4.1.1 Criterion datum

A criterion datum is the smallest score-bearing unit.

```typescript
interface CriterionDatumV4 {
  criterion_id: string;
  domain: 'Q100' | 'S100' | 'A100' | 'R100' | 'G100';
  status:
    | 'SCORED'
    | 'UNKNOWN'
    | 'UNSCORABLE'
    | 'CONFLICTED'
    | 'NOT_APPLICABLE'
    | 'NOT_RUN';
  raw_value: number | string | boolean | null;
  scale_ref: string;
  evidence_refs: string[];
  method_ref: string | null;
  reason: string;
  confidence: number | null;
  uncertainty_interval: {
    lower: number;
    upper: number;
    kind: 'MEASUREMENT_INTERVAL' | 'SENSITIVITY_ENVELOPE' | 'OTHER_DECLARED';
    method_ref: string;
  } | null;
}
```

`confidence` is carried for epistemic trace and is never multiplied into the score.

## 4.1.2 Normalized criterion score

```typescript
interface NormalizedCriterionScore {
  criterion_id: string;
  domain: DomainId;
  points_0_100: number | null;
  status: CriterionStatus;
  scale_ref: string;
  evidence_refs: string[];
  score_method: string;
  confidence_used_in_score: false;
  limitations: string[];
}
```

## 4.1.3 Domain score

```typescript
interface DomainScoreV4 {
  domain: DomainId;
  status: 'COMPLETE' | 'PARTIAL' | 'UNSCORABLE' | 'NOT_APPLICABLE';
  score: number | null;
  display_score: number | null;
  coverage: number;
  required_coverage: number;
  scored_weight: number;
  applicable_weight: number;
  criterion_refs: string[];
  uncertainty: ScoreInterval | null;
  limitations: string[];
}
```

## 4.1.4 Score vector

```typescript
interface ScoreVectorV4 {
  vector_id: string;
  run_id: string;
  unit_id: string;
  profile_ref: string;
  applicability_signature: string;
  Q100: DomainScoreV4;
  S100: DomainScoreV4;
  A100: DomainScoreV4;
  R100: DomainScoreV4;
  G100: DomainScoreV4;
  C100: CompositeScoreV4 | null;
  score_policy_ref: string;
  generated_by: string;
}
```

# 4.2 Scale ontology

A number has no meaning without a scale and a transformation.

```typescript
type ScaleKind =
  | 'BINARY'
  | 'ANCHORED_ORDINAL'
  | 'BOUNDED_CONTINUOUS'
  | 'PERCENT'
  | 'COUNT_TRANSFORM'
  | 'DETERMINISTIC_FUNCTION';
```

Every scale declares:

```yaml
scale_id:
version:
kind:
domain:
valid_raw_values:
point_map_or_transform:
measurement_resolution:
assumptions:
validation_status:
```

## 4.2.1 No implicit interval assumption

An ordinal label such as `0,1,2,3,4` is not automatically equidistant.

Allowed:

```yaml
point_map:
  0: 0
  1: 15
  2: 45
  3: 75
  4: 100
```

Forbidden:

```text
level / 4 × 100
```

unless the rubric explicitly adopts that mapping and documents its interval assumption.

## 4.2.2 Zero semantics

`0` is a valid observed bottom score on a declared scale.

It is not a substitute for:

- unknown;
- missing;
- not applicable;
- not run;
- unscorable;
- conflicted evidence.

# 4.3 Criterion normalization

For an explicit point map `m`:

```text
criterion_score = m(raw_value)
```

For bounded continuous raw value `x ∈ [a,b]`:

```text
criterion_score = 100 × (x - a) / (b - a)
```

Only a scale with an active transformation may be used in confirmatory scoring.

Invalid raw value produces a validation failure, not clipping.

# 4.4 Applicability and missingness

Applicability is frozen before candidate scoring.

```text
NOT_APPLICABLE
→ excluded from applicable denominator

SCORED
→ contributes score and weight

UNKNOWN / CONFLICTED / UNSCORABLE / NOT_RUN
→ never converted to zero
```

## 4.4.1 Coverage

For domain `d`:

```text
A_d = sum of weights of applicable criteria
O_d = sum of weights of scored applicable criteria
coverage_d = O_d / A_d
```

If `A_d = 0`, the domain is `NOT_APPLICABLE`.

Coverage is not quality. It reports how much of the declared construct was actually measured.

## 4.4.2 Required criterion rule

If a required applicable criterion is not `SCORED`:

```text
domain status = UNSCORABLE
score = null
```

A Section 3 gate may additionally block all scoring or require human escalation.

## 4.4.3 Optional missing criterion

If only optional criteria are unresolved:

- point estimate may be computed from observed criteria;
- domain status becomes `PARTIAL`;
- coverage remains below 1;
- limitation is mandatory;
- comparison requires matching coverage or calibrated missing-data handling.

The engine does not impute missing values.

# 4.5 Criterion weights

Weights belong to a versioned scoring profile, not to the judge's momentary preference.

For each domain:

```text
w_i >= 0
sum(w_i for applicable criteria) > 0
```

Nominal weights are design parameters. They are not proof of actual influence on the composite.

Required disclosures:

- rationale;
- owner;
- version;
- lifecycle;
- calibration evidence;
- sensitivity analysis;
- applicable unit types;
- prohibited uses.

Post-hoc weight changes create a new profile and a new run.

# 4.6 Domain aggregation

For a scoreable domain:

```text
D_d = sum(w_i × s_i) / sum(w_i)
```

where the sum includes only scored, applicable criteria.

This is a measurement aggregation within a declared domain. It does not mean that all criteria are ontologically interchangeable.

Domain score output includes coverage and the criterion vector so the arithmetic mean cannot hide the underlying pattern.

## 4.6.1 Domain floors

A profile may define a domain floor for a specific use, but only if:

- the floor is pre-registered;
- the domain is applicable;
- calibration evidence exists;
- the floor does not replace Section 3 hard gates.

No universal domain floor is active in v3.3-alpha.5.

# 4.7 Q100 / S100 / A100 / R100 / G100

## Q100 — Quality and truth performance

May include contract fulfillment, factual correctness, technical correctness, logical entailment, epistemic discipline, and practical validity.

## S100 — Space quality

Measures whether interaction creates a voluntary, clear, appropriately paced space for thought. It must not use retention as a proxy.

## A100 — Agency

Measures choice, exit, non-dependency, transfer of action outside the system, and preservation of user sovereignty.

## R100 — Reliability

Measures repeatability, method transparency, stability, and declared limitations. A single observation normally cannot establish broad reliability.

## G100 — Governance

Measures traceability, change control, permission boundaries, auditability, and policy compliance when applicable.

The five domains remain separate even when a composite exists.

# 4.8 Optional composite C100

## 4.8.1 Preconditions

`C100` may be computed only when all are true:

```text
Section 3 composite_allowed = true
profile lifecycle = ACTIVE
profile scope permits the unit and estimand
all required domains are scoreable
applicability is resolved
minimum domain coverage is met
weights are valid and versioned
no prohibited use applies
```

In the current alpha package, no production profile is `ACTIVE`. A `TEST_ONLY` profile exists solely to verify the mathematics.

## 4.8.2 Weighted geometric mean

For applicable domain scores `D_j ∈ [0,100]` and normalized weights `alpha_j`:

```text
x_j = D_j / 100
sum(alpha_j) = 1
```

If any required domain has `D_j = 0`:

```text
C100 = 0
```

Otherwise:

```text
C100 = 100 × exp(sum(alpha_j × ln(x_j)))
```

Why geometric rather than arithmetic:

- lower domains constrain the result;
- compensation is reduced;
- no single strong domain can fully erase a weak one;
- the vector remains visible.

This formula is a design hypothesis until calibrated. It is not an empirical fact about human value or system safety.

## 4.8.3 Applicability signature

Composite scores are comparable only when they share:

- profile ID and version;
- domain applicability set;
- criterion applicability set or an approved harmonization method;
- estimand level;
- scoring mode;
- coverage policy.

A different applicability signature means a different measurement object.

# 4.9 Arithmetic benchmark and compensation audit

For diagnostics only, the engine may compute:

```text
arithmetic_reference = sum(alpha_j × D_j)
compensation_gap = arithmetic_reference - C100
```

This reference is not an alternative authoritative score. A large positive gap warns that arithmetic averaging would conceal a weak domain.

# 4.10 Uncertainty

## 4.10.1 No invented interval

If the method does not support an interval:

```text
uncertainty = null
uncertainty_status = NOT_ESTIMATED
```

Judge confidence is not a confidence interval.

## 4.10.2 Deterministic interval propagation

When every contributing criterion supplies a valid normalized interval `[l_i,u_i]`, a domain sensitivity envelope may be propagated:

```text
L_d = sum(w_i × l_i) / sum(w_i)
U_d = sum(w_i × u_i) / sum(w_i)
```

This is labelled `SENSITIVITY_ENVELOPE`, not a probabilistic confidence interval.

For the geometric composite, if all required domains provide positive bounds:

```text
L_C = GM(L_d)
U_C = GM(U_d)
```

If a lower bound is zero, `L_C = 0`.

## 4.10.3 Statistical inference boundary

Bootstrap, hierarchical models, IRT, GLMM, Bayesian models, or repeated-trial estimates belong to a declared statistical method and require assumptions, sufficient data, diagnostics, and validation.

Section 4 defines interfaces for such intervals but does not silently manufacture them.

# 4.11 Precision and rounding

Internal calculation uses at least six decimal places.

Published display precision is limited by:

- scale resolution;
- sample size;
- judge repeatability;
- uncertainty width;
- calibration evidence.

Default display for diagnostic domain and composite scores is one decimal, but this is formatting, not a claim that differences of `0.1` are meaningful.

Forbidden:

```text
A=93.742, B=93.681 → A is better
```

without calibrated resolution and comparison evidence.

# 4.12 Comparison and tie semantics

A numeric difference is not automatically a winner.

```typescript
type ScoreComparisonStatus =
  | 'NOT_REQUESTED'
  | 'BLOCKED_BY_SECTION_3'
  | 'INCOMPARABLE_SIGNATURE'
  | 'DESCRIPTIVE_ONLY'
  | 'CALIBRATED_TIE'
  | 'CALIBRATED_ADVANTAGE'
  | 'INFERENTIAL_UNAVAILABLE';
```

Before a calibrated comparison exists, Section 4 may report only:

- vectors;
- domain deltas;
- composite delta if lawful;
- coverage differences;
- descriptive advantage;
- uncertainty overlap;
- sensitivity to weights.

It must return `winner = null`.

A calibrated tie or advantage requires a registered comparison method specifying:

- minimum important difference or equivalence margin;
- repeated measurements or valid uncertainty model;
- multiplicity policy where relevant;
- directionality;
- decision error targets;
- task clustering and estimand.

No universal tie band is active in v3.3-alpha.5.

# 4.13 Sensitivity analysis

A composite is incomplete without a sensitivity report.

Minimum diagnostics:

1. arithmetic-reference comparison;
2. one-at-a-time domain-weight perturbation;
3. leave-one-optional-domain-out analysis when lawful;
4. coverage sensitivity;
5. applicability signature check;
6. winner stability check when comparison is requested.

A profile is not eligible for publication-grade use until reasonable weight perturbations do not create undisclosed conclusion reversals.

# 4.14 Scoring profile lifecycle

```text
DRAFT
→ PROPOSED
→ CALIBRATING
→ ACTIVE
→ SUSPENDED
→ DEPRECATED
→ RETIRED
```

- `DRAFT/PROPOSED`: documentation only.
- `CALIBRATING`: diagnostic use with explicit warning.
- `ACTIVE`: allowed for its registered scope.
- `SUSPENDED`: no new scoring.
- `DEPRECATED`: historical reproduction only.
- `RETIRED`: forbidden for new runs.
- `TEST_ONLY`: implementation tests, never a research claim.

# 4.15 Scoring request contract

```typescript
interface ScoringRequestV4 {
  run_id: string;
  unit_id: string;
  environment: 'TEST' | 'LAB' | 'PRODUCTION';
  mode: 'DIAGNOSTIC' | 'CONFIRMATORY';
  score_policy: ScorePolicy;
  profile_id: string;
  criteria: CriterionDatumV4[];
  comparison_request?: {
    requested: boolean;
    peer_vector_refs: string[];
    method_ref: string | null;
  };
}
```

The reference engine consumes typed criterion data. It does not read candidate free text.

# 4.16 Scoring response contract

```typescript
interface ScoringResponseV4 {
  engine_status: 'SCORED' | 'PARTIAL' | 'UNSCORABLE' | 'REQUEST_INVALID';
  run_id: string;
  unit_id: string;
  profile_ref: string;
  score_vector: ScoreVectorV4 | null;
  criterion_results: NormalizedCriterionScore[];
  warnings: string[];
  errors: string[];
  comparison: {
    status: ScoreComparisonStatus;
    winner: null;
    reason: string;
  };
  provenance: {
    engine_version: string;
    registry_sha256: string;
    formula_ids: string[];
  };
}
```

# 4.17 Reference engine invariants

The engine must:

- reject unknown scale IDs;
- reject invalid raw values;
- never replace missingness with zero;
- never use confidence as a weight;
- obey Section 3 score policy;
- return `C100=null` when composite is blocked;
- block confirmatory composite for non-active profiles;
- allow `TEST_ONLY` profiles only in `environment=TEST`;
- preserve criterion and domain vectors;
- emit coverage;
- return no winner;
- expose every formula ID.

# 4.18 Failure codes

```text
SCR-F01 SECTION3_SCORING_BLOCKED
SCR-F02 UNKNOWN_PROFILE
SCR-F03 PROFILE_NOT_ACTIVE
SCR-F04 TEST_PROFILE_OUTSIDE_TEST
SCR-F05 UNKNOWN_SCALE
SCR-F06 INVALID_RAW_VALUE
SCR-F07 REQUIRED_CRITERION_MISSING
SCR-F08 DOMAIN_COVERAGE_INSUFFICIENT
SCR-F09 REQUIRED_DOMAIN_UNSCORABLE
SCR-F10 INVALID_WEIGHT_CONFIGURATION
SCR-F11 APPLICABILITY_CONFLICT
SCR-F12 COMPOSITE_BLOCKED
SCR-F13 INCOMPARABLE_SIGNATURE
SCR-F14 FALSE_PRECISION_REQUEST
SCR-F15 CONFIDENCE_AS_WEIGHT_ATTEMPT
SCR-F16 DUPLICATE_CRITERION
SCR-F17 UNDECLARED_CRITERION
SCR-F18 INTERVAL_INVALID
```

# 4.19 Acceptance tests

## Core scoring

- `T4-01`: explicit ordinal map is used exactly.
- `T4-02`: non-linear ordinal map is not replaced by linear interpolation.
- `T4-03`: bounded continuous transformation is deterministic.
- `T4-04`: invalid raw value is rejected, not clipped.
- `T4-05`: duplicate criterion is rejected.

## Missingness and applicability

- `T4-06`: unknown required criterion makes the domain unscorable.
- `T4-07`: N/A criterion is excluded from denominator.
- `T4-08`: optional unknown lowers coverage but is not zero.
- `T4-09`: no applicable criteria makes domain N/A.
- `T4-10`: applicability conflict blocks composite.

## Section 3 integration

- `T4-11`: package invalid policy produces no scores.
- `T4-12`: hard-fail policy may preserve diagnostic vector but C100 is null.
- `T4-13`: `composite_allowed=false` always wins over profile configuration.
- `T4-14`: pointwise-only policy permits vector and composite but no ranking.

## Composite

- `T4-15`: geometric mean matches reference calculation.
- `T4-16`: required domain score zero produces C100 zero.
- `T4-17`: domain weights are normalized only as declared.
- `T4-18`: required domain missing produces C100 null.
- `T4-19`: composite retains profile and applicability signature.
- `T4-20`: arithmetic reference never replaces C100.

## Confidence and uncertainty

- `T4-21`: confidence does not alter score.
- `T4-22`: absent interval remains null.
- `T4-23`: valid sensitivity envelopes propagate deterministically.
- `T4-24`: judge confidence is rejected as a confidence interval.

## Precision and comparison

- `T4-25`: display rounding does not change internal score.
- `T4-26`: 0.1 delta does not create a winner.
- `T4-27`: different applicability signatures are incomparable.
- `T4-28`: no calibrated comparison method returns winner null.

## Profile lifecycle and sensitivity

- `T4-29`: CALIBRATING profile cannot produce confirmatory composite.
- `T4-30`: TEST_ONLY profile is rejected outside TEST.
- `T4-31`: weight perturbation report is deterministic.
- `T4-32`: conclusion reversal under perturbation is disclosed.

# 4.20 External scientific anchors

Section 4 adopts the following external constraints as methodological anchors, not as hidden authority over the Charter:

1. NIST AI 800-3 distinguishes benchmark accuracy from generalized accuracy and requires the estimand and uncertainty method to match the claim.
2. NIST uncertainty guidance requires a declared measurement model and valid uncertainty treatment rather than invented precision.
3. Composite-indicator research warns that nominal weights may not equal actual influence after aggregation and correlation; sensitivity analysis is therefore mandatory.
4. IRT/GLMM-style latent scoring is allowed only as a declared statistical model, never as a default replacement for observable domain vectors.


# 4.20.1 References

- Keller, A. et al. (2026). *Expanding the AI Evaluation Toolbox with Statistical Models*. NIST AI 800-3. DOI: `10.6028/NIST.AI.800-3`.
- Nardo, M. et al. (2008). *Handbook on Constructing Composite Indicators: Methodology and User Guide*. OECD / EC-JRC. DOI: `10.1787/9789264043466-en`.
- Becker, W. et al. (2017). *Weights and Importance in Composite Indicators: Closing the Gap*. Ecological Indicators. DOI: `10.1016/j.ecolind.2017.03.056`.
- NIST Technical Note 1297. *Guidelines for Evaluating and Expressing the Uncertainty of NIST Measurement Results*.

These references support explicit estimands, uncertainty models, sensitivity analysis, and caution around composite weights. They do not validate the current IJP weights or composite.

# 4.21 Dependencies on later sections

- Section 5 defines evidence qualification and provenance for score-bearing observations.
- Section 6 defines judge reliability and inter-rater uncertainty.
- Section 7 tests scoring against adversarial outputs and bias.
- Section 10 calibrates weights, intervals, comparison margins, and validity claims.
- Section 11 constrains publication language.

# 4.22 Non-goals

Section 4 does not claim:

- production-ready universal weights;
- empirically valid C100;
- a universal tie threshold;
- human-value measurement from one response;
- causal user transformation from S100 or A100;
- model-family capability from benchmark-local scores;
- publication-grade ranking.

# 4.23 Implementation state

```yaml
specification: PROPOSED
schema: IMPLEMENTED
registry: IMPLEMENTED
reference_engine: IMPLEMENTED
unit_tests: IMPLEMENTED
production_profile: NONE_ACTIVE
empirical_calibration: NOT_CLAIMED
publication_grade: NO
```

# 4.24 ∆DΩΛ

**∆:** Eligible evidence-backed criterion results now have a deterministic path to domain vectors and an optional, non-sovereign composite.

**D:** Section 3 permission → applicability → scale transformation → coverage → domain aggregation → geometric composite → sensitivity → no-winner boundary.

**Ω:** 0.93. The arithmetic is deterministic; construct validity, weights, intervals, and comparison margins remain calibration questions.

**Λ:** Revisit after Section 5 evidence contracts, Section 6 reliability, and Section 10 empirical calibration.
