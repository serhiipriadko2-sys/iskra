# Independent Judge v3.3-alpha.6 — Section 5 Owner Review Audit

## Verdict

```yaml
section_5:
  specification: PASS_WITH_FINDINGS
  archive_integrity: PASS
  manifest_integrity: PASS
  alpha5_preservation: PASS
  declared_test_suite: PASS
  adversarial_mutation_suite: FAIL
  reference_validator: REVISE
  owner_acceptance: NOT_GRANTED
  canonical_transition_to_section_6: BLOCKED
```

## Verified intake

- ZIP bytes: `241899`
- ZIP SHA-256: `b20a3af023694c5072747af7801a82f30c9515e16e4de8d4f6f22c5c49f8f7c2`
- ZIP integrity: `PASS`
- Files in ZIP: `126`
- Manifest payload entries: `124/124` present, size/hash matched
- Alpha.5 payload preservation: `84/84` byte-identical
- Pytest: `46 passed, 5 subtests passed`
- JSON parse: `64`
- YAML parse: `5`
- Cache artifacts: `0`
- Symlinks: `0`

## Reproduced validator bypasses

All following modified graphs were accepted as `VALID` by `tools/validate_evidence_graph.py`:

1. `unsafe_relative_path` — `content_ref: ../outside.txt` with `VERIFIED` integrity.
2. `revoked_claim_support_active_judgment_decoy` — observation and claim depend on revoked evidence, while judgment names an unrelated active evidence object.
3. `missing_observation_claim_judgment_edges` — mandatory semantic provenance edges removed while array references remain.
4. `publication_study_without_verdict_ancestry` — publication descends from a study with no verdict-to-study edge.
5. `publication_from_orphan_study` — result, verdict and verdict-to-study ancestry removed; orphan study still publishes.
6. `duplicate_edge_id` — duplicate edge identifier accepted.
7. `duplicate_method_id` — conflicting duplicate method identifier accepted and silently overwritten in the in-memory index.
8. `resolved_conflict_dangling_resolution` — resolved conflict references a nonexistent resolution claim and no resolution method.
9. `derivation_without_incoming_edge` — declared derivation has no matching `DERIVED_FROM` provenance edge.
10. `unsupported_empty_hard_failure` — `SUPPORTED` hard failure with empty claim/evidence lists accepted when a nominal propagation record exists.
11. `orphan_hard_failure_propagation` — propagation record references a nonexistent failure.

## Load-bearing findings

### F5-01 — Lifecycle enforcement can be bypassed

**Severity:** HIGH

`REVOKED`, `EXPIRED`, `CORRUPTED` or `SUPERSEDED` evidence is rejected only when directly named in `judgment.evidence_refs`. It may still support an observation and claim, while an unrelated active object is placed in the judgment.

Required correction: validate lifecycle across the full transitive support path and require judgment evidence to be provenance-connected to its claims.

### F5-02 — `provenance_complete` is not actually proven

**Severity:** HIGH

The validator checks field references and edge legality independently, but does not require the declared observation/claim/judgment references to have matching edges. It can therefore emit:

```yaml
status: VALID
provenance_complete: true
```

for an incomplete evidence graph.

Required correction: construct and validate a typed path for every score-bearing judgment.

### F5-03 — Publication ancestry rule is incomplete

**Severity:** HIGH

`validate_publication_paths()` treats both `VERDICT` and `STUDY` as valid starting nodes. An orphan study can therefore support publication without any verdict ancestry.

Required correction: every publication claim must have a path beginning at at least one allowed verdict; a study alone is not sufficient.

### F5-04 — Hard-failure evidence and propagation are underconstrained

**Severity:** HIGH

A supported hard failure may have no claims or evidence. Propagation records need not reference an existing failure or concrete destination node. This undermines both false-failure prevention and score-laundering traceability.

Required correction: non-empty active claim/evidence references, canonical gate/effect anchors, source failure existence, destination node reference and path validation.

### F5-05 — Unsafe local reference is silently treated as non-local

**Severity:** MEDIUM-HIGH

`safe_local_path()` returns `None` for both remote references and invalid local paths. `validate_content()` then silently skips verification. A traversal-style reference such as `../outside.txt` can therefore pass.

Required correction: distinguish `REMOTE_REF` from `INVALID_LOCAL_REF`; reject traversal, absolute and escaped-root paths with a canonical error.

### F5-06 — Global identity and resolution invariants are incomplete

**Severity:** MEDIUM

Unique IDs are enforced only for graph nodes. Edge, method, conflict, derivation, redaction, failure and propagation identities are not globally checked. Resolved conflicts and derivations are not required to link to valid resolution/derivation paths.

## Minimum patch gate

Before Owner acceptance, add at least these canonical errors/tests:

```yaml
required_errors:
  - EV-F26 UNSAFE_CONTENT_REF
  - EV-F27 INACTIVE_TRANSITIVE_SUPPORT
  - EV-F28 DECLARED_REF_WITHOUT_EDGE
  - EV-F29 PUBLICATION_WITHOUT_VERDICT_ANCESTRY
  - EV-F30 DUPLICATE_RECORD_ID
  - EV-F31 INVALID_CONFLICT_RESOLUTION
  - EV-F32 DERIVATION_EDGE_MISSING
  - EV-F33 HARD_FAILURE_WITHOUT_QUALIFIED_SUPPORT
  - EV-F34 ORPHAN_HARD_FAILURE_PROPAGATION
```

Required regression fixtures:

```text
unsafe_relative_path
revoked_claim_support_active_judgment_decoy
missing_observation_claim_judgment_edges
publication_from_orphan_study
duplicate_edge_id
duplicate_method_id
resolved_conflict_dangling_resolution
derivation_without_incoming_edge
unsupported_empty_hard_failure
orphan_hard_failure_propagation
```

## Governance disposition

Preserve `v3.3-alpha.6` as an immutable proposed checkpoint. Build a successor (`v3.3-alpha.7` recommended) containing the fixes, a Section 5 decision record/ADR, updated manifest/receipt, and a rerun of both the original suite and the adversarial mutation suite.

Section 6 may be developed only as a non-canonical draft until Section 5 is accepted.
