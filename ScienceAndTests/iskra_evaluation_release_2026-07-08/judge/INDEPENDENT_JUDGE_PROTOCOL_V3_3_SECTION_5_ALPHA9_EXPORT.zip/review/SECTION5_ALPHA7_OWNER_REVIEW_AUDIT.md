# Independent Judge v3.3-alpha.7 — Section 5 Owner Review Audit

Date: 2026-07-18
Mode: independent archive, executable and adversarial verification
Artifact: `INDEPENDENT_JUDGE_PROTOCOL_V3_3_SECTION_5_ALPHA7_EXPORT.zip`

## 1. Archive verification

```yaml
bytes: 300210
sha256: 466843467ab81141c63c530dfd45c8d7068f83b98ae0b688efba36427e7fa429
zip_integrity: PASS
files_total: 162
payload_manifest_entries: 160
manifest_hashes: 160/160 PASS
manifest_extras:
  - PROJECT_MANIFEST_v3.3-alpha.7.json
  - RECEIPT_SECTION_5_ALPHA7.json
```

The alpha.6 checkpoint remains unchanged:

```yaml
bytes: 241899
sha256: b20a3af023694c5072747af7801a82f30c9515e16e4de8d4f6f22c5c49f8f7c2
status: PASS
```

No Section 0–4 preservation mismatch was observed.

## 2. Declared execution verification

```yaml
pytest: PASS
result: 51 passed, 5 subtests passed
python_compile: PASS
valid_fixture: VALID
section5_invalid_fixtures: 23/23 rejected
known_owner_mutations: 11/11 rejected
```

The stated alpha.6 repairs are real for the exact declared fixtures.

## 3. Extended mutation findings

### A7-F01 — `file://` absolute local reference accepted

Mutation:

```text
content_ref = file:///etc/passwd
integrity_status = VERIFIED
```

Observed result:

```yaml
status: VALID
provenance_complete: true
errors: []
```

Cause: `classify_content_ref()` treats any string containing `://` as remote after checking only a small allowed-scheme set. A `file://` URI therefore bypasses the invalid-local branch.

Severity: MEDIUM-HIGH

### A7-F02 — Revoked derivation input is hidden by an active derived output

Mutation:

```text
REVOKED E-IN
  └─ DERIVED_FROM → ACTIVE E-DER
                       └─ supports observation/claim/judgment
```

The `DerivationRecord` and `DERIVED_FROM` edge are complete and schema-valid.

Observed result:

```yaml
status: VALID
provenance_complete: true
errors: []
```

Cause: transitive lifecycle traversal does not include `DERIVED_FROM`, and derivation validation does not require active inputs.

This directly contradicts the alpha.7 claim that any inactive load-bearing ancestor blocks scoring.

Severity: HIGH

### A7-F03 — Conflicted observation feeds a supported FACT and score

Mutation:

```yaml
observation.status: CONFLICTED
claim.qualification: FACT
claim.support_status: SUPPORTED
judgment.score_eligible: true
```

Observed result:

```yaml
status: VALID
provenance_complete: true
errors: []
```

Cause: observation status is not propagated into claim or judgment eligibility.

Severity: HIGH

### A7-F04 — UNKNOWN claim can be the sole basis of a score-bearing judgment

Mutation:

```yaml
claim.qualification: UNKNOWN
claim.support_status: NOT_EVALUATED
claim.load_bearing: false
judgment.status: SUPPORTED
judgment.score_eligible: true
```

Observed result:

```yaml
status: VALID
provenance_complete: true
errors: []
```

Cause: judgment eligibility blocks conflicted claims, but not UNKNOWN, REFUTED, or insufficient/not-evaluated claims when `load_bearing=false`.

Severity: HIGH

### A7-F05 — Material redaction hidden behind active judgment decoy

Mutation:

```text
MATERIAL redacted content
→ E-TEST
→ claim

E-DECOY
→ same claim
→ judgment.evidence_refs
```

Observed result:

```yaml
status: VALID_WITH_LIMITATIONS
provenance_complete: true
errors: []
warnings:
  - EV-W05 INDEPENDENCE_UNKNOWN:E-DECOY
```

Cause: material-redaction enforcement checks only direct `judgment.evidence_refs`, not all evidence ancestors of its claims.

This bypasses the Section 5 requirement that material privacy redaction blocks a dependent score.

Severity: HIGH

## 4. Claim verification verdict

| User claim | Verdict |
|---|---|
| ZIP hash, size, count, integrity | VERIFIED |
| Manifest hashes | VERIFIED |
| Alpha.6 preservation | VERIFIED |
| 51 tests + 5 subtests | VERIFIED |
| Known 11 mutations rejected | VERIFIED |
| F5-02 declared-edge closure for known fixtures | VERIFIED |
| F5-03 publication ancestry for known fixtures | VERIFIED |
| F5-04 known hard-failure cases | VERIFIED |
| F5-06 duplicate/conflict/derivation known cases | VERIFIED |
| Full transitive lifecycle closure | FALSE |
| Unsafe local reference closure | PARTIAL |
| `provenance_complete=true` only for complete eligible paths | FALSE |
| Section 5 acceptance readiness | NOT VERIFIED |

## 5. Governance disposition

```yaml
v3.3-alpha.6:
  status: PROPOSED_CHECKPOINT
  immutable: true

v3.3-alpha.7:
  known_repair_suite: PASS
  extended_adversarial_suite: FAIL
  owner_acceptance: WITHHELD
  status: PROPOSED_CHECKPOINT_WITH_RESIDUAL_FINDINGS

section_6:
  exploratory_draft: ALLOWED
  canonical_commit: BLOCKED
```

## 6. Required alpha.8 patch

1. Reject all local-capable URI schemes (`file`, UNC, unsupported schemes) instead of treating generic `://` as remote.
2. Include `DERIVED_FROM` lineage in lifecycle closure and block active derived evidence with inactive load-bearing inputs.
3. Propagate `CONFLICTED`, `UNSCORABLE`, `NOT_OBSERVED`, and material `PARTIAL` observations into claim/judgment eligibility.
4. Forbid score eligibility when the only supporting claims are `UNKNOWN`, `REFUTED`, `INSUFFICIENT_EVIDENCE`, or `NOT_EVALUATED`.
5. Apply material-redaction blocking transitively to all evidence ancestors of score-bearing claims.
6. Add the five mutations as physical negative fixtures and rerun original and extended suites.

## 7. Final verdict

```yaml
archive_integrity: PASS
known_repair_execution: PASS
extended_enforcement: FAIL
section_5_owner_acceptance: NOT_GRANTED
production_readiness: NO
section_6_canonical_transition: BLOCKED
```

## Delta D Omega Lambda

Delta: Alpha.7 closes the reported alpha.6 bypasses but not the full invariants those cases represented.

D: archive verification -> declared suite PASS -> novel mutation pass -> five accepted invalid paths -> alpha.8 gate.

Omega: 0.99 archive integrity; 0.98 declared repair reproduction; 0.58 acceptance readiness.

Lambda: preserve alpha.7 -> patch lifecycle, eligibility, redaction and URI classification -> rerun expanded suite -> owner review.
