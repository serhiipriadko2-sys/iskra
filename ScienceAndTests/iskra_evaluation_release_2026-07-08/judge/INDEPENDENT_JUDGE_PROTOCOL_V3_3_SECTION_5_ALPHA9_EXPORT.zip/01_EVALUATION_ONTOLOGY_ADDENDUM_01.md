---
title: Independent Judge Protocol v3.3 — Evaluation Ontology Addendum 01
version: v3.3-alpha.3
section: 1-addendum-01
status: ACCEPTED_WITH_SECTION_1_REVIEW
created_at: 2026-07-17
supersedes: null
amends: 01_EVALUATION_ONTOLOGY.md
---

# Evaluation Ontology Addendum 01

This addendum clarifies three ontology areas without rewriting the accepted Section 1 artifact.

# A. Formal Evaluation Object Graph

```text
EvaluatedObject
  ├─ HAS_VERSION → ObjectVersion
  └─ IS_TARGET_OF → Study

Study
  ├─ DECLARES → Estimand [1 primary, 0..n secondary]
  ├─ DEFINES → Population
  ├─ CONTAINS → EvaluationRun [1..n]
  └─ USES → StudyProtocol

EvaluationRun
  ├─ USES → EvaluationPackage [exactly 1 sealed version]
  ├─ INVOKES → JudgeInstance [1..n]
  ├─ PRODUCES → CriterionResult [0..n]
  ├─ PRODUCES → HardGateResult [1..n required gates]
  └─ COMMITS → Verdict [0..1 active, append-only lineage]

EvaluationPackage
  ├─ BINDS → EvaluatedObjectVersion [1..n]
  ├─ BINDS → Estimand [exactly 1 primary for the run]
  ├─ CONTAINS → Task [1..n]
  ├─ CONTAINS → TaskContract [exactly 1 active contract per task]
  ├─ CONTAINS → CandidateOutput [1..n per evaluation unit]
  ├─ REFERENCES → EvidenceItem [0..n]
  ├─ REFERENCES → Method [1..n when scoring is expected]
  └─ DECLARES → Risk / Applicability / Independence profiles

TaskContract
  └─ CONTAINS → ContractAtom [1..n]

CandidateOutput
  └─ IS_TREATED_AS → UntrustedData

Observation
  ├─ OBSERVES → CandidateOutput or other EvaluationUnit
  ├─ USES → Method
  └─ MAY_SUPPORT → Claim

EvidenceItem
  ├─ DERIVES_FROM → Source
  ├─ SUPPORTS | REFUTES | CONTEXTUALIZES → Claim
  └─ HAS → EvidenceQualification

Criterion
  ├─ OPERATIONALIZES → Construct
  ├─ BELONGS_TO → Domain [exactly 1 primary]
  └─ HAS_LIFECYCLE → CriterionLifecycleRecord

CriterionResult
  ├─ APPLIES → Criterion
  ├─ TO → EvaluationUnit
  ├─ CITES → EvidenceItem [unless typed unknown/N/A/invalid]
  └─ CONTRIBUTES_TO → ScoreVector [only if eligible]

Verdict
  ├─ SUMMARIZES → GateResults + ScoreVector + Unknowns
  ├─ IS_LIMITED_BY → ValidityClass + ClaimCeiling
  └─ MAY_BE_SUPERSEDED_BY → Verdict

GovernanceRecord
  ├─ AUTHORIZES → Protocol/Rubric/Schema version
  └─ RECORDS → Revision, suspension, deprecation or rollback
```

## Graph invariants

1. A run uses exactly one sealed package identity.
2. A package binds one primary estimand for each run.
3. A task has one active frozen contract in a package version.
4. A criterion result cannot exist without criterion, evaluation unit and judge identity.
5. A verdict cannot exist without completed package integrity and required hard-gate states.
6. Remediation is outside this graph until the verdict is committed.

# B. Criterion Lifecycle

```typescript
type CriterionLifecycleStatus =
  | 'DRAFT'
  | 'PROPOSED'
  | 'CALIBRATING'
  | 'ACTIVE'
  | 'SUSPENDED'
  | 'DEPRECATED'
  | 'RETIRED';
```

## Allowed transitions

```text
DRAFT -> PROPOSED
PROPOSED -> CALIBRATING
CALIBRATING -> ACTIVE
ACTIVE -> SUSPENDED
SUSPENDED -> ACTIVE
ACTIVE -> DEPRECATED
SUSPENDED -> DEPRECATED
DEPRECATED -> RETIRED
```

Exceptional transitions:

```text
PROPOSED -> RETIRED
CALIBRATING -> RETIRED
```

## Forbidden transitions

```text
RETIRED -> ACTIVE
DEPRECATED -> ACTIVE
ACTIVE -> DRAFT
```

A retired or deprecated criterion may remain in historical run records. It cannot be silently substituted in an active rubric.

## Lifecycle record

```typescript
interface CriterionLifecycleRecord {
  criterion_id: string;
  criterion_version: string;
  status: CriterionLifecycleStatus;
  effective_from: string | null;
  effective_until: string | null;
  calibration_refs: string[];
  governance_ref: string;
  superseded_by: string | null;
  reason: string;
}
```

## Confirmatory-use gate

A criterion is eligible for confirmatory scoring only when:

- status is `ACTIVE`;
- positive and negative anchors exist;
- observation method is defined;
- scale semantics are defined;
- applicability rule is testable;
- evidence requirement is specified;
- calibration evidence meets the study protocol.

Otherwise the criterion is exploratory, unknown or not run.

# C. Evaluation versus Study Boundary

## Evaluation

An evaluation is a bounded measurement of a specific evaluation unit under a frozen package and explicit estimand.

```text
Evaluation question:
“How did this object/output perform under this contract in this run?”
```

## Study

A study is a research design that aggregates one or more evaluation runs to answer a broader, preregistered or explicitly declared research question.

```text
Study question:
“What can these runs support about the declared population and estimand?”
```

## Non-equivalence

```text
one evaluation result
≠ one study conclusion
≠ general system capability
```

## Boundary rules

1. Evaluation may produce a local verdict.
2. Study may aggregate local verdicts only using its declared design.
3. Study-level claims must not exceed the primary estimand claim ceiling.
4. Exploratory post-hoc findings remain labeled exploratory.
5. A package is run input; a study protocol is design authority.
6. Repeating one package many times does not automatically expand the population definition.

# D. Compatibility

This addendum is compatible with:

- LAW-01 Immutable Evaluation Package;
- LAW-14 Frozen Task Contract;
- LAW-20 Judge Reliability Is a Separate Object;
- Section 1 relation catalogue;
- Section 1 estimand hierarchy;
- Section 1 lifecycle and governance rules.

# E. Acceptance tests

## T1A-01 · One package per run

A run references two mutable package versions.

**PASS:** invalid.

## T1A-02 · Criterion activation

A `DRAFT` criterion is used in confirmatory scoring.

**PASS:** blocked or exploratory only.

## T1A-03 · Study overreach

One local evaluation is used to claim model-family capability.

**PASS:** claim ceiling failure.

## T1A-04 · Historical criterion

A deprecated criterion appears in an old run.

**PASS:** preserved historically; not rewritten.

## T1A-05 · Remediation leakage

Object is modified before the verdict is committed.

**PASS:** run invalidated or independence downgraded.

## ∆DΩΛ

**∆:** object relationships, criterion lifecycle and Evaluation/Study separation became explicit.

**D:** addendum preserves accepted Section 1 and supplies serialization requirements for Section 2.

**Ω:** 0.95.

**Λ:** revise if JSON Schema implementation reveals cardinality or lifecycle ambiguity.
